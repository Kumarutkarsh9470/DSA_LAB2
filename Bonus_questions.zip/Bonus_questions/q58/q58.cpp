#include <bits/stdc++.h>
using namespace std;

/*
    q58.cpp

    Given a BST and Q queries, each query is a range [L, R].
    For each query we consider the entire BST and define:

        floor(L)  = largest key <= L      (if such a node exists)
        ceil(R)   = smallest key >= R     (if such a node exists)

    For this query, the "special nodes" are:
        - the node with key floor(L), if it exists
        - the node with key ceil(R),  if it exists

    A node can be both floor and ceil if floor(L) == ceil(R).

    For each query we output:

        count floorVal ceilVal

    where:
        count    = number of DISTINCT nodes among {floor, ceil}
                   (so 0, 1, or 2),
        floorVal = key of floor(L) or -1 if it does not exist,
        ceilVal  = key of ceil(R)  or -1 if it does not exist.

    Input format (BST):

        N
        val1 left1 right1
        ...
        valN leftN rightN
        Q
        L1 R1
        ...
        LQ RQ

        - Nodes are 1-based.
        - val_i  : integer key of node i.
        - left_i : index of left child  (0 if NULL)
        - right_i: index of right child (0 if NULL)
        - It is guaranteed to represent a valid BST.

    Approach:

        1) Find root (the only node that is never listed as a child).
        2) Inorder traverse to get sorted vector<int> vals of length N.
        3) For each query [L, R]:
           - floor:
                it = upper_bound(vals.begin, vals.end, L);
                if (it != begin) floorVal = *(--it)
           - ceil:
                it = lower_bound(vals.begin, vals.end, R);
                if (it != end)  ceilVal = *it
           - count how many distinct existing values we have.
*/

struct Node {
    long long val;
    int left;
    int right;
};

void inorderTraversal(const vector<Node> &tree, int root, vector<long long> &out) {
    if (root == 0) return;
    inorderTraversal(tree, tree[root].left, out);
    out.push_back(tree[root].val);
    inorderTraversal(tree, tree[root].right, out);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;

    vector<Node> tree(N + 1);
    vector<int> isChild(N + 1, 0);

    for (int i = 1; i <= N; ++i) {
        cin >> tree[i].val >> tree[i].left >> tree[i].right;
        if (tree[i].left  != 0) isChild[tree[i].left]  = 1;
        if (tree[i].right != 0) isChild[tree[i].right] = 1;
    }

    int root = 1;
    for (int i = 1; i <= N; ++i) {
        if (!isChild[i]) {
            root = i;
            break;
        }
    }

    // Inorder traversal -> sorted keys (BST property)
    vector<long long> vals;
    vals.reserve(N);
    inorderTraversal(tree, root, vals);

    int Q;
    cin >> Q;

    while (Q--) {
        long long L, R;
        cin >> L >> R;

        long long floorVal = -1;
        long long ceilVal  = -1;
        bool hasFloor = false, hasCeil = false;

        // floor(L): largest value <= L
        auto it = upper_bound(vals.begin(), vals.end(), L);
        if (it != vals.begin()) {
            --it;
            floorVal = *it;
            hasFloor = true;
        }

        // ceil(R): smallest value >= R
        it = lower_bound(vals.begin(), vals.end(), R);
        if (it != vals.end()) {
            ceilVal = *it;
            hasCeil = true;
        }

        int count = 0;
        if (hasFloor) count++;
        if (hasCeil && (!hasFloor || ceilVal != floorVal)) count++;

        if (!hasFloor) floorVal = -1;
        if (!hasCeil)  ceilVal  = -1;

        cout << count << ' ' << floorVal << ' ' << ceilVal << '\n';
    }

    return 0;
}
