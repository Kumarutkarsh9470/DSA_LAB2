#include <bits/stdc++.h>
using namespace std;

/*
    q65 – Top-k differences from two max-heaps

    Problem:
        Given two max-heaps A and B (we simply receive their elements),
        consider all N*M pairwise differences (a - b) for a in A, b in B.
        We want to extract the k largest differences **without**
        generating all N^2 differences explicitly.

    Idea:
        Let arrays:
            A_sorted:  A's elements sorted descending.
            B_sorted:  B's elements sorted ascending.

        For difference:
            a - b  (a large, b small) is maximized when:
                - a is large  -> A_sorted descending
                - b is small  -> B_sorted ascending

        Define
            C[i] = A_sorted[i]
            D[j] = -B_sorted[j]   (since b small => -b large)
        Then:
            a - b = C[i] + D[j].

        Now the problem is "top-k sums of two sorted arrays in O(k log k)",
        which is standard:

            1. Put (i=0, j=0, value = C[0] + D[0]) into a max-heap.
            2. Repeatedly extract the largest pair (i, j) and push its
               neighbors (i+1, j) and (i, j+1) if within bounds and
               not already visited.
            3. Each pop gives next largest difference.

        Complexity:
            - We push at most 2k states and pop k times.
            - Each push/pop is O(log k).
            => Overall O(k log k) time and O(k) extra space.

    Input format:
        n m k
        a0 a1 ... a(n-1)   (elements of heap A, any order)
        b0 b1 ... b(m-1)   (elements of heap B, any order)

    Output format:
        Let P = min(k, n*m).
        First line : P
        Second line: P numbers = k largest differences in non-increasing order.

    Notes:
        - If n == 0 or m == 0, there are no differences, we print "0" and exit.
*/

struct State {
    long long val; // C[i] + D[j] = a - b
    int i, j;
    bool operator<(const State& other) const {
        return val < other.val;   // for max-heap
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    long long k;
    if (!(cin >> n >> m >> k)) {
        return 0;
    }

    vector<long long> A(n), B(m);
    for (int i = 0; i < n; ++i) cin >> A[i];
    for (int j = 0; j < m; ++j) cin >> B[j];

    if (n == 0 || m == 0 || k <= 0) {
        cout << 0 << "\n";
        return 0;
    }

    // Sort A descending (max to min)
    sort(A.begin(), A.end(), greater<long long>());

    // Sort B ascending (min to max) – good for difference a - b
    sort(B.begin(), B.end());

    // C = A, D[j] = -B[j]
    vector<long long> C = A;
    vector<long long> D(m);
    for (int j = 0; j < m; ++j) D[j] = -B[j];

    // Priority queue over (C[i] + D[j], i, j)
    priority_queue<State> pq;

    // Track visited (i, j) to avoid duplicates
    struct PairHash {
        size_t operator()(const pair<int,int> &p) const {
            return (static_cast<size_t>(p.first) << 32) ^ static_cast<size_t>(p.second);
        }
    };
    unordered_set<pair<int,int>, PairHash> used;
    used.reserve((size_t)min<long long>(k * 2, (long long)n * m) + 5);

    // Start from (0,0)
    pq.push({C[0] + D[0], 0, 0});
    used.insert({0, 0});

    long long totalPairs = 1LL * n * m;
    long long need = min(k, totalPairs);
    vector<long long> ans;
    ans.reserve((size_t)need);

    while (!pq.empty() && (long long)ans.size() < need) {
        State cur = pq.top();
        pq.pop();
        int i = cur.i;
        int j = cur.j;
        long long diff = C[i] + D[j];      // = A_sorted[i] - B_sorted[j]
        ans.push_back(diff);

        // Neighbor (i+1, j)
        if (i + 1 < n) {
            pair<int,int> p(i + 1, j);
            if (used.find(p) == used.end()) {
                used.insert(p);
                pq.push({C[i + 1] + D[j], i + 1, j});
            }
        }
        // Neighbor (i, j+1)
        if (j + 1 < m) {
            pair<int,int> p(i, j + 1);
            if (used.find(p) == used.end()) {
                used.insert(p);
                pq.push({C[i] + D[j + 1], i, j + 1});
            }
        }
    }

    cout << ans.size() << "\n";
    for (size_t idx = 0; idx < ans.size(); ++idx) {
        if (idx) cout << ' ';
        cout << ans[idx];
    }
    cout << "\n";

    return 0;
}
