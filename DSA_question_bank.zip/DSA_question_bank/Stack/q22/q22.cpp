#include <bits/stdc++.h>
using namespace std;

// ==================== LEXER ==================== //

struct Token {
    enum Type { NUMBER, OP, LPAREN, RPAREN, WORD, END } type;
    double value;     // for NUMBER
    string text;      // for OP and WORD

    Token(Type t = END) : type(t), value(0) {}
};

class Lexer {
    string s;
    size_t pos;

public:
    explicit Lexer(const string &input) : s(input), pos(0) {}

    bool eof() const { return pos >= s.size(); }

    Token next() {
        skipSpaces();
        if (eof()) return Token(Token::END);

        char c = s[pos];

        // Number (integer or floating)
        if (isdigit(c) || c == '.') {
            size_t start = pos;
            while (pos < s.size() &&
                   (isdigit(s[pos]) || s[pos] == '.')) {
                ++pos;
            }
            double val = stod(s.substr(start, pos - start));
            Token t(Token::NUMBER);
            t.value = val;
            return t;
        }

        // Parentheses
        if (c == '(') {
            ++pos;
            return Token(Token::LPAREN);
        }
        if (c == ')') {
            ++pos;
            return Token(Token::RPAREN);
        }

        // Word (letters only): def, left, right, etc.
        if (isalpha(c)) {
            size_t start = pos;
            while (pos < s.size() && isalpha(s[pos]))
                ++pos;
            string w = s.substr(start, pos - start);
            Token t(Token::WORD);
            t.text = w;
            return t;
        }

        // Otherwise treat as single-character operator
        // (non-alphanumeric, non-space, non-paren).
        ++pos;
        Token t(Token::OP);
        t.text = string(1, c);
        return t;
    }

private:
    void skipSpaces() {
        while (pos < s.size() && isspace(static_cast<unsigned char>(s[pos])))
            ++pos;
    }
};

// Simple token stream wrapper to support peek/get
class TokenStream {
    Lexer lex;
    Token current;
    bool hasCurrent;

public:
    explicit TokenStream(const string &input) : lex(input), hasCurrent(false) {}

    Token peek() {
        if (!hasCurrent) {
            current = lex.next();
            hasCurrent = true;
        }
        return current;
    }

    Token get() {
        if (!hasCurrent) {
            current = lex.next();
        }
        hasCurrent = false;
        return current;
    }
};

// ==================== OPERATOR TABLE ==================== //

struct OpInfo {
    int precedence;
    bool rightAssoc;
    function<double(double,double)> func;
};

using OpTable = unordered_map<string, OpInfo>;

// ==================== PARSER / EVALUATOR ==================== //

double parseExpression(TokenStream &ts, OpTable &ops, int minPrec = 0); // fwd

// Parse primary: number, parenthesized expression, or def-expression
double parsePrimary(TokenStream &ts, OpTable &ops) {
    Token t = ts.get();

    if (t.type == Token::NUMBER) {
        return t.value;
    }

    if (t.type == Token::LPAREN) {
        double val = parseExpression(ts, ops, 0);
        Token closing = ts.get();
        if (closing.type != Token::RPAREN) {
            throw runtime_error("Expected ')'");
        }
        return val;
    }

    if (t.type == Token::WORD) {
        // "def" introduces a custom operator definition
        string w = t.text;
        for (auto &ch : w) ch = tolower(ch);

        if (w != "def") {
            throw runtime_error("Unexpected word: " + t.text +
                                " (only 'def' allowed here)");
        }

        // def <op-symbol> <precedence> <assoc> ( expression )

        Token opTok = ts.get();
        if (opTok.type != Token::OP)
            throw runtime_error("Expected operator symbol after 'def'");
        string opSym = opTok.text;  // single-char operator

        Token precTok = ts.get();
        if (precTok.type != Token::NUMBER)
            throw runtime_error("Expected numeric precedence after operator");
        int prec = static_cast<int>(precTok.value);

        Token assocTok = ts.get();
        if (assocTok.type != Token::WORD)
            throw runtime_error("Expected associativity (left/right or L/R)");
        string assoc = assocTok.text;
        for (auto &ch : assoc) ch = tolower(ch);
        bool rightAssoc;
        if (assoc == "left" || assoc == "l")
            rightAssoc = false;
        else if (assoc == "right" || assoc == "r")
            rightAssoc = true;
        else
            throw runtime_error("Associativity must be 'left' or 'right'");

        Token lpar = ts.get();
        if (lpar.type != Token::LPAREN)
            throw runtime_error("Expected '(' starting def-expression body");

        // Create a local operator table extending current one
        OpTable localOps = ops;

        // For simplicity, all custom operators behave as addition.
        OpInfo info;
        info.precedence = prec;
        info.rightAssoc = rightAssoc;
        info.func = [](double a, double b) { return a + b; };

        localOps[opSym] = info;

        // Evaluate body expression with this extended operator table
        double val = parseExpression(ts, localOps, 0);

        Token rpar = ts.get();
        if (rpar.type != Token::RPAREN)
            throw runtime_error("Expected ')' ending def-expression body");

        return val;
    }

    throw runtime_error("Unexpected token where primary expected");
}

// Precedence-climbing expression parser with dynamic operators
double parseExpression(TokenStream &ts, OpTable &ops, int minPrec) {
    double lhs = parsePrimary(ts, ops);

    while (true) {
        Token next = ts.peek();
        if (next.type != Token::OP) break;

        auto it = ops.find(next.text);
        if (it == ops.end()) break;  // unknown operator ends expression

        int prec = it->second.precedence;
        bool rightAssoc = it->second.rightAssoc;

        if (prec < minPrec) break;

        // consume operator
        ts.get();

        int nextMinPrec = rightAssoc ? prec : prec + 1;
        double rhs = parseExpression(ts, ops, nextMinPrec);

        lhs = it->second.func(lhs, rhs);
    }

    return lhs;
}

// ==================== MAIN ==================== //

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string line;
    if (!getline(cin, line)) {
        return 0;
    }

    // Default operator table: +, -, *, /
    OpTable ops;

    ops["+"] = {10, false, [](double a, double b){ return a + b; }};
    ops["-"] = {10, false, [](double a, double b){ return a - b; }};
    ops["*"] = {20, false, [](double a, double b){ return a * b; }};
    ops["/"] = {20, false, [](double a, double b){
        if (b == 0.0) throw runtime_error("Division by zero");
        return a / b;
    }};

    try {
        TokenStream ts(line);
        double result = parseExpression(ts, ops, 0);

        Token leftover = ts.peek();
        if (leftover.type != Token::END) {
            throw runtime_error("Unexpected tokens after end of expression");
        }

        cout << fixed << setprecision(10) << result << "\n";
    } catch (const exception &ex) {
        cerr << "Error: " << ex.what() << "\n";
        return 1;
    }

    return 0;
}
