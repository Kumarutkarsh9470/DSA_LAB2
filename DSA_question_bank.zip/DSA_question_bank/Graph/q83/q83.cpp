#include <bits/stdc++.h>
using namespace std;

/*
    q83 – Graph compression by node groups + Floyd–Warshall on groups

    We have a large graph with N nodes, each assigned to one of G groups.
    Nodes in the same group share the same local connectivity pattern,
    so distances depend only on groups, not on individual nodes.

    Idea:
        - Compress the graph into a "group graph" of size G:
            * vertices = groups
            * edge (A -> B) weight = minimum weight among all edges
              (u -> v) with group[u] = A, group[v] = B.
        - Run Floyd–Warshall on this G x G matrix to get all-pairs
          shortest paths between groups.
        - To answer a query for nodes s, t:
              gs = group[s]
              gt = group[t]
              distance(s, t) = distGroup[gs][gt]
          (0 if s == t and groups allow, or unreachable if INF).

    Input:
        N M G Q
        group[0..N-1]
        M lines: u v w
        Q lines: s t

    Output:
        Q lines: shortest distance from s to t, or -1 if unreachable.
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int N, M, G, Q;
    if (!(cin >> N >> M >> G >> Q)) {
        return 0;
    }

    vector<int> group(N);
    for (int i = 0; i < N; ++i) {
        cin >> group[i];
        if (group[i] < 0 || group[i] >= G) {
            // basic clamp / ignore invalid, but input is assumed valid
            group[i] = max(0, min(G-1, group[i]));
        }
    }

    const long long INF = (1LL << 60);

    // Initialize compressed adjacency (group graph)
    vector< vector<long long> > dist(G, vector<long long>(G, INF));
    for (int i = 0; i < G; ++i) dist[i][i] = 0;  // zero on diagonal

    // Read edges and compress them
    for (int i = 0; i < M; ++i) {
        int u, v;
        long long w;
        cin >> u >> v >> w;
        if (u < 0 || u >= N || v < 0 || v >= N) continue;

        int gu = group[u];
        int gv = group[v];
        if (w < dist[gu][gv]) {
            dist[gu][gv] = w; // keep the minimum weight between groups
        }
    }

    // Floyd–Warshall on group graph
    for (int k = 0; k < G; ++k) {
        for (int i = 0; i < G; ++i) {
            if (dist[i][k] == INF) continue;
            for (int j = 0; j < G; ++j) {
                if (dist[k][j] == INF) continue;
                long long nd = dist[i][k] + dist[k][j];
                if (nd < dist[i][j]) {
                    dist[i][j] = nd;
                }
            }
        }
    }

    // Answer queries
    while (Q--) {
        int s, t;
        cin >> s >> t;
        if (s < 0 || s >= N || t < 0 || t >= N) {
            cout << -1 << "\n";
            continue;
        }

        int gs = group[s];
        int gt = group[t];

        long long ans = dist[gs][gt];

        if (s == t) {
            // same node: distance is always 0
            ans = 0;
        }

        if (ans >= INF / 2) {
            cout << -1 << "\n"; // unreachable
        } else {
            cout << ans << "\n";
        }
    }

    return 0;
}
