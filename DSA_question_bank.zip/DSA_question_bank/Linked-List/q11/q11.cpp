#include <bits/stdc++.h>
using namespace std;

// Node for multilevel list: next + child
class Node {
public:
    int data;
    Node *next;
    Node *child;

    Node(int x) {
        data = x;
        next  = nullptr;
        child = nullptr;
    }
};

/*
    Flatten a multilevel linked list into a single level,
    using LEVEL-ORDER (BFS) traversal, but with a ZIG-ZAG rule:

    - Level 0 (top level) : left-to-right (forward)
    - Level 1             : right-to-left (reversed)
    - Level 2             : left-to-right
    - ...

    "Maintain relative ordering within levels" means:
    for each level we take all nodes of that level in their
    natural list order, then either keep that list as is
    (even levels) or reverse the entire level order (odd levels),
    and finally concatenate levels.

    The transformation is done IN-PLACE:
    we only rearrange `next` pointers and set all `child = nullptr`.
*/
Node* flattenZigZag(Node *head) {
    if (head == nullptr) return nullptr;

    // For BFS we store HEADS of each sublist of a level.
    queue<Node*> q;
    q.push(head);

    // Result sequence of nodes in final order.
    vector<Node*> order;

    // Similar to zigZagList: flag toggles direction per level.
    bool leftToRight = true;   // level 0 = even

    while (!q.empty()) {
        int levelCount = q.size();

        // Collect all nodes of this level first.
        vector<Node*> levelNodes;

        while (levelCount--) {
            Node *listHead = q.front();
            q.pop();

            // Traverse this horizontal list.
            for (Node *curr = listHead; curr != nullptr; curr = curr->next) {
                levelNodes.push_back(curr);

                // Enqueue child list heads for the *next* level.
                if (curr->child != nullptr) {
                    q.push(curr->child);
                }
            }
        }

        // If this is an odd level, reverse node order of this level.
        if (!leftToRight) {
            reverse(levelNodes.begin(), levelNodes.end());
        }

        // Append this level's nodes to global order.
        order.insert(order.end(), levelNodes.begin(), levelNodes.end());

        // Flip direction for next level (zig-zag behaviour).
        leftToRight = !leftToRight;
    }
    int n = (int)order.size();
    for (int i = 0; i < n; ++i) {
        order[i]->child = nullptr;
        if (i + 1 < n) {
            order[i]->next = order[i + 1];
        } else {
            order[i]->next = nullptr;
        }
    }

    return (n == 0 ? nullptr : order[0]);
}
void printList(Node *head) {
Node *curr = head;
while (curr != nullptr) {
cout << curr->data << " ";
curr = curr->next;
}
cout << "\n";
}
int main() {
Node *head = new Node(1);
head->next = new Node(2);
head->next->next = new Node(3);
head->child = new Node(4);
head->child->next = new Node(5);
head->next->child = new Node(6);
head->child->child = new Node(7);
head->child->child->next = new Node(8);
cout << "Flattened zig-zag list:\n";
Node *flat = flattenZigZag(head);
printList(flat);         
return 0;
}
