#include <bits/stdc++.h>
using namespace std;

// ------------------------------------------------------------
// Swap-based insertion sort (standard version)
// Counts array writes (assignments).
// Each swap does 3 array writes.
// ------------------------------------------------------------
long long insertionSwap(vector<int> a) {
    int n = (int)a.size();
    long long writes = 0;

    for (int i = 1; i < n; ++i) {
        int j = i;
        while (j > 0 && a[j] < a[j - 1]) {
            // swap a[j], a[j-1]
            int tmp = a[j];
            a[j] = a[j - 1];  writes++;   // write #1
            a[j - 1] = tmp;   writes++;   // write #2
            // tmp was just a local variable; its writes don't count.
            // But a classic swap has 3 assignments to the array if
            // using a temp array cell; here only 2 because tmp is local.
            // We will treat this as 2 writes (actual array writes).
            j--;
        }
    }
    return writes;
}

// ------------------------------------------------------------
// Shift-based insertion sort (optimized version)
// For each position i:
//   - store a[i] in key (not counted as an array write),
//   - find correct insertion position pos,
//   - shift a[pos..i-1] right by one element,
//   - write key to a[pos].
// Counts only writes to the array.
// ------------------------------------------------------------
long long insertionShift(vector<int> a) {
    int n = (int)a.size();
    long long writes = 0;

    for (int i = 1; i < n; ++i) {
        int key = a[i];        // not counted (read only)
        int j = i - 1;

        // Find position where key should be inserted.
        while (j >= 0 && a[j] > key) {
            j--;
        }
        int pos = j + 1;

        // Shift elements a[pos..i-1] to the right by one.
        for (int k = i - 1; k >= pos; --k) {
            a[k + 1] = a[k];
            writes++;          // one array write per shift
        }

        // Place key at its position.
        a[pos] = key;
        writes++;              // one write for key
    }
    return writes;
}

// ------------------------------------------------------------
// Helpers to build datasets with various "sortedness" levels
// ------------------------------------------------------------

// Fill v with random integers in [minVal, maxVal].
void makeRandomArray(vector<int>& v, int n, mt19937& rng,
                     int minVal = -1000000, int maxVal = 1000000) {
    uniform_int_distribution<int> dist(minVal, maxVal);
    v.resize(n);
    for (int i = 0; i < n; ++i) v[i] = dist(rng);
}

// Take base array and make "p% sorted" variant:
// We sort the first (p * n) elements, leaving the rest random.
vector<int> makePartiallySorted(const vector<int>& base, double fractionSorted) {
    int n = (int)base.size();
    vector<int> v = base;
    int prefix = (int)(fractionSorted * n + 0.5);   // round to nearest
    prefix = max(0, min(n, prefix));
    sort(v.begin(), v.begin() + prefix);
    return v;
}

// ------------------------------------------------------------
// Experiment driver
// ------------------------------------------------------------
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    const int N = 1000;          // array size
    const int TRIALS = 100;      // number of datasets per scenario

    mt19937 rng(123456);         // fixed seed for reproducibility

    // Accumulators for total writes.
    long long totalSwapRandom = 0,   totalShiftRandom = 0;
    long long totalSwap25 = 0,      totalShift25 = 0;
    long long totalSwap50 = 0,      totalShift50 = 0;
    long long totalSwap75 = 0,      totalShift75 = 0;

    for (int t = 0; t < TRIALS; ++t) {
        vector<int> base;
        makeRandomArray(base, N, rng);

        // Different levels of initial ordering.
        vector<int> arrRandom = base;
        vector<int> arr25     = makePartiallySorted(base, 0.25);
        vector<int> arr50     = makePartiallySorted(base, 0.50);
        vector<int> arr75     = makePartiallySorted(base, 0.75);

        // For each scenario, run both algorithms on identical data.
        // Random
        totalSwapRandom  += insertionSwap(arrRandom);
        totalShiftRandom += insertionShift(arrRandom);

        // 25% sorted
        totalSwap25  += insertionSwap(arr25);
        totalShift25 += insertionShift(arr25);

        // 50% sorted
        totalSwap50  += insertionSwap(arr50);
        totalShift50 += insertionShift(arr50);

        // 75% sorted
        totalSwap75  += insertionSwap(arr75);
        totalShift75 += insertionShift(arr75);
    }

    auto printStats = [&](const string& label,
                          long long sSwap, long long sShift) {
        cout << "=== " << label << " ===\n";
        cout << "Total trials: " << TRIALS << "\n";
        cout << "Swap-based writes : " << sSwap << "\n";
        cout << "Shift-based writes: " << sShift << "\n";
        cout << "Difference (swap - shift): "
             << (sSwap - sShift) << "\n";
        cout << "Average per trial - swap : "
             << (double)sSwap / TRIALS << "\n";
        cout << "Average per trial - shift: "
             << (double)sShift / TRIALS << "\n\n";
    };

    cout << "Array size: " << N << "\n\n";

    printStats("Random (0% sorted)",   totalSwapRandom, totalShiftRandom);
    printStats("25% sorted prefix",    totalSwap25,     totalShift25);
    printStats("50% sorted prefix",    totalSwap50,     totalShift50);
    printStats("75% sorted prefix",    totalSwap75,     totalShift75);

    return 0;
}
