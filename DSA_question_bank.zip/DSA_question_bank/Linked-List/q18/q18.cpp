#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int x) : data(x), next(nullptr) {}
};

// Build list from vector
Node* buildList(const vector<int>& a) {
    if (a.empty()) return nullptr;
    Node* head = new Node(a[0]);
    Node* tail = head;
    for (size_t i = 1; i < a.size(); ++i) {
        tail->next = new Node(a[i]);
        tail = tail->next;
    }
    return head;
}

// Print list
void printList(Node* head) {
    Node* cur = head;
    bool first = true;
    while (cur) {
        if (!first) cout << " ";
        cout << cur->data;
        first = false;
        cur = cur->next;
    }
    cout << "\n";
}

/*
    Rearrange list so that all "twin" pairs whose sum == T
    become adjacent, while preserving the relative order
    of such pairs.

    Twin definition for even-length list of size n:
        node i and node j are twins if j = n-1-i
    (0-based index)
*/
Node* rearrangeTwins(Node* head, int T) {
    if (!head) return head;

    // Step 1: dump all nodes into an array for random access
    vector<Node*> nodes;
    for (Node* cur = head; cur != nullptr; cur = cur->next) {
        nodes.push_back(cur);
    }

    int n = (int)nodes.size();
    if (n % 2 != 0) {
        // Problem statement assumes even length;
        // if not, we just return unchanged.
        return head;
    }

    // twin index mapping
    vector<int> twinIdx(n);
    for (int i = 0; i < n; ++i) {
        twinIdx[i] = n - 1 - i;
    }

    // Step 2: identify twin pairs whose sum == T
    // We only need to check the first half; the twin on the other side
    // shares the same pairId.
    vector<int> pairId(n, -1);
    int pairCount = 0;

    for (int i = 0; i < n / 2; ++i) {
        int j = twinIdx[i];
        if (nodes[i]->data + nodes[j]->data == T) {
            pairId[i] = pairId[j] = pairCount;
            ++pairCount;
        }
    }

    if (pairCount == 0) {
        // No affected pairs; list unchanged
        return head;
    }

    // Step 3: build new order of nodes
    vector<Node*> newOrder;
    newOrder.reserve(n);

    vector<bool> pairPlaced(pairCount, false);
    vector<bool> indexUsed(n, false);

    for (int i = 0; i < n; ++i) {
        if (indexUsed[i]) continue;

        if (pairId[i] == -1) {
            // not in any targeted pair, keep in place relative to others
            newOrder.push_back(nodes[i]);
            indexUsed[i] = true;
        } else {
            int pid = pairId[i];
            if (!pairPlaced[pid]) {
                // first time seeing this pair (this is guaranteed to be
                // the left-side node since i < n/2 for first encounters)
                int j = twinIdx[i];

                newOrder.push_back(nodes[i]);
                newOrder.push_back(nodes[j]);

                indexUsed[i] = indexUsed[j] = true;
                pairPlaced[pid] = true;
            }
        }
    }

    // Step 4: relink nodes in new order
    for (int k = 0; k < (int)newOrder.size() - 1; ++k) {
        newOrder[k]->next = newOrder[k + 1];
    }
    newOrder.back()->next = nullptr;

    return newOrder[0];
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;   // even length is assumed

    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    int T;
    cin >> T;

    Node* head = buildList(a);
    head = rearrangeTwins(head, T);

    printList(head);

    return 0;
}
