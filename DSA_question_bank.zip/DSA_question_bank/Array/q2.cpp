/*  
Since, the question has condition that the subarray must have 0 in it as well , then the product will always be 0.
Hence, it reduces to checking whether 0 is present in it or not.If present, then the answer is 0 else -1.
*/
#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    for(int i=0;i<n;i++){
        if(arr[i] == 0){
            cout << 0 << endl;
            return 0;
        }
    }
    cout << -1 << endl;
}