#include <bits/stdc++.h>
using namespace std;

/*
   Doubly linked list node with an extra random pointer.
*/
struct Node {
    int data;
    Node *prev;
    Node *next;
    Node *random;

    Node(int x) : data(x), prev(nullptr), next(nullptr), random(nullptr) {}
};

/* Build a doubly linked list with random pointers from:
   - values[0..n-1]  -> node data
   - rndIdx[0..n-1]  -> index of random node for each node (-1 = null)
*/
Node* buildList(const vector<int> &values, const vector<int> &rndIdx) {
    int n = (int)values.size();
    if (n == 0) return nullptr;

    vector<Node*> nodes(n);
    for (int i = 0; i < n; ++i) {
        nodes[i] = new Node(values[i]);
    }

    // set prev/next
    for (int i = 0; i < n; ++i) {
        if (i > 0) nodes[i]->prev = nodes[i - 1];
        if (i + 1 < n) nodes[i]->next = nodes[i + 1];
    }

    // set random pointers
    for (int i = 0; i < n; ++i) {
        int ri = rndIdx[i];
        if (ri >= 0 && ri < n) {
            nodes[i]->random = nodes[ri];
        } else {
            nodes[i]->random = nullptr;
        }
    }

    return nodes[0];
}

/* Pretty-print a list showing index, data, and random-index.
   Mainly for demonstration/testing.
*/
void printList(Node* head, const string &title) {
    cout << title << "\n";

    vector<Node*> arr;
    for (Node *cur = head; cur != nullptr; cur = cur->next)
        arr.push_back(cur);

    unordered_map<Node*, int> idx;
    for (int i = 0; i < (int)arr.size(); ++i)
        idx[arr[i]] = i;

    cout << "Length = " << arr.size() << "\n";
    for (int i = 0; i < (int)arr.size(); ++i) {
        int r = -1;
        if (arr[i]->random != nullptr) {
            auto it = idx.find(arr[i]->random);
            if (it != idx.end()) r = it->second;
        }
        cout << "Node " << i
             << ": data=" << arr[i]->data
             << ", random=" << r << "\n";
    }
    cout << "----\n";
}

/*
   Clone a doubly linked list with random pointers.

   Technique: O(1) extra space (besides the cloned nodes), similar
   to the classic random-pointer singly list cloning:

   1) Interleave clone nodes after originals: O1C1O2C2...
   2) Set random for clones using original.random->next.
   3) Unweave the two lists, restoring the original and extracting clone.
*/
Node* cloneList(Node* head) {
    if (!head) return nullptr;

    // Step 1: interleave cloned nodes
    for (Node *cur = head; cur != nullptr; ) {
        Node *copy = new Node(cur->data);

        // Insert copy right after cur
        copy->next = cur->next;
        copy->prev = cur;
        if (cur->next) cur->next->prev = copy;
        cur->next = copy;

        cur = copy->next;   // move to next original
    }

    // Step 2: assign random pointers for cloned nodes
    for (Node *cur = head; cur != nullptr; cur = cur->next->next) {
        Node *copy = cur->next;
        if (cur->random) {
            copy->random = cur->random->next;  // its clone is right after original
        } else {
            copy->random = nullptr;
        }
    }

    // Step 3: separate the two lists and restore original prev/next
    Node *cloneHead = head->next;
    Node *origCur   = head;
    Node *cloneCur  = cloneHead;

    while (origCur) {
        // Restore original list's next/prev
        origCur->next = cloneCur->next;
        if (origCur->next) origCur->next->prev = origCur;

        // Fix clone list's next/prev
        if (origCur->next) {
            cloneCur->next = origCur->next->next;
        } else {
            cloneCur->next = nullptr;
        }
        if (cloneCur->next) cloneCur->next->prev = cloneCur;

        origCur = origCur->next;
        cloneCur = cloneCur->next;
    }

    // Head of clone should not point back to an original
    cloneHead->prev = nullptr;
    return cloneHead;
}

/*
   Reverse the doubly linked list in-place.

   We only swap next/prev of each node; random pointers stay exactly
   as they were, so all random relationships are preserved.
*/
Node* reverseDoublyList(Node* head) {
    Node *cur = head;
    Node *newHead = nullptr;

    while (cur) {
        Node *nextNode = cur->next;
        // Swap next and prev
        cur->next = cur->prev;
        cur->prev = nextNode;

        newHead = cur;      // last processed becomes new head
        cur = nextNode;
    }
    return newHead;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    vector<int> vals(n);
    for (int i = 0; i < n; ++i) cin >> vals[i];

    vector<int> rndIdx(n);
    for (int i = 0; i < n; ++i) cin >> rndIdx[i];  // -1 for null

    Node *head = buildList(vals, rndIdx);

    printList(head, "Original list");

    Node *cloneHead = cloneList(head);
    printList(cloneHead, "Cloned list");

    head = reverseDoublyList(head);
    printList(head, "Original list after in-place reversal");

    cloneHead = reverseDoublyList(cloneHead);
    printList(cloneHead, "Cloned list after in-place reversal");

    return 0;
}
