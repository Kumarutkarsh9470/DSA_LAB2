#include <bits/stdc++.h>
using namespace std;

/*
    Problem:

    For each node of a binary tree, calculate the sum of all cousin nodes:
      * cousins = nodes on the SAME LEVEL with a DIFFERENT parent.
    Additionally, the statement says we should only count cousins whose
    parent's level differs by at most K from this node's parent's level.

    In a proper tree, all nodes on the same level have their parents
    exactly one level above, so all such parents are on the same level.
    Hence the level difference between any two parents of same-level
    nodes is always 0, and the K condition is automatically satisfied
    for any K >= 0. Therefore, the standard cousin definition suffices.

    Assumed input format:

        n K
        value0 left0 right0
        value1 left1 right1
        ...
        value(n-1) left(n-1) right(n-1)

      * nodes are indexed 0..n-1
      * -1 for left/right means "no child"
      * node 0 is the root
      * K is kept for completeness but does not affect the result
        under the usual tree definition.

    Output:

        n space-separated integers:
          ans[0] ans[1] ... ans[n-1]
        where ans[i] is the sum of cousin nodes of node i.
*/

struct Node {
    long long val;
    int left;
    int right;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    long long K;
    if (!(cin >> n >> K) || n <= 0) {
        return 0;
    }

    vector<Node> tree(n);
    for (int i = 0; i < n; ++i) {
        long long v;
        int l, r;
        cin >> v >> l >> r;
        tree[i] = {v, l, r};
    }

    // BFS to compute level and parent of each node
    vector<int> parent(n, -1);
    vector<int> level(n, -1);
    queue<int> q;

    int root = 0;
    level[root] = 0;
    parent[root] = -1;
    q.push(root);

    int maxLevel = 0;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        int lv = level[u];
        maxLevel = max(maxLevel, lv);

        if (tree[u].left != -1) {
            int v = tree[u].left;
            parent[v] = u;
            level[v] = lv + 1;
            q.push(v);
        }
        if (tree[u].right != -1) {
            int v = tree[u].right;
            parent[v] = u;
            level[v] = lv + 1;
            q.push(v);
        }
    }

    // For each level:
    //   levelSum[L] = sum of all node values at level L
    //   levelParentSum[L][p] = sum of values of children of parent p at level L
    vector<long long> levelSum(maxLevel + 1, 0);
    vector< unordered_map<int, long long> > levelParentSum(maxLevel + 1);

    for (int i = 0; i < n; ++i) {
        int lv = level[i];
        if (lv < 0) continue; // should not happen in a connected tree

        levelSum[lv] += tree[i].val;
        if (parent[i] != -1) {
            levelParentSum[lv][parent[i]] += tree[i].val;
        }
    }

    // For each node, cousin sum:
    //   cousins at same level L but different parent.
    //   Since all parents of level-L nodes are on level L-1,
    //   parent's level difference is always 0 and hence <= K (for K >= 0).
    //   So result is simply: levelSum[L] - sum of children of its own parent on that level.
    vector<long long> ans(n, 0);

    for (int i = 0; i < n; ++i) {
        int lv = level[i];
        int p = parent[i];

        if (p == -1) {
            ans[i] = 0; // root has no cousins
            continue;
        }

        long long totalLevelSum = levelSum[lv];
        long long sameParentSum = 0;
        auto it = levelParentSum[lv].find(p);
        if (it != levelParentSum[lv].end()) {
            sameParentSum = it->second;
        }

        // All other nodes at this level (different parents) are cousins.
        ans[i] = totalLevelSum - sameParentSum;
    }

    // Output answers for all nodes in index order
    for (int i = 0; i < n; ++i) {
        if (i) cout << ' ';
        cout << ans[i];
    }
    cout << '\n';

    return 0;
}
