#include <bits/stdc++.h>
using namespace std;

/*
   Problem interpretation

   - There are N linked lists.
   - Nodes are connected in their own list by "next" pointers
     (standard singly linked list).
   - A node may also have ONE extra "cross" pointer that can point to any
     node in ANY list (or to nothing).
   - We want to:
       1. Serialize this structure (convert all pointers to indices),
       2. Deserialize it back (rebuild all pointers), and
       3. On the rebuilt structure, find the shortest path from a node
          in list X to a node in list Y following ANY pointers
          (next or cross). Pointers are directed.

   Assumed input format

       N
       L0 L1 ... L{N-1}               // lengths of each list
       // For each list and each node in that list (0-based position):
       //   cl cp     (cross-list index, cross-position)
       //   cl = -1 means "no cross pointer"
       // Order: list 0 nodes from pos 0..L0-1, then list 1, etc.
       (for i = 0..N-1)
         (for j = 0..Li-1)
           cl cp
       X posX Y posY                   // start node & target node
                                      // 0-based list and position indices

   Output

       If there is a path:
          length
          <l0:p0> <l1:p1> ... <lk:pk>  // nodes along the path
       else:
          NO PATH

   Length is the number of edges along the path
   (i.e., number of pointer hops).
*/

struct Node {
    int id;         // global id
    int listIdx;    // which list
    int pos;        // position within its list
    Node* next;
    Node* cross;
    Node(int _id, int _listIdx, int _pos)
        : id(_id), listIdx(_listIdx), pos(_pos), next(nullptr), cross(nullptr) {}
};

struct SNode {      // serialized form
    int id;
    int listIdx;
    int pos;
    int nextId;     // -1 if null
    int crossId;    // -1 if null
};

// serialize: pointers -> ids
vector<SNode> serialize(const vector<Node*>& allNodes) {
    vector<SNode> ser(allNodes.size());
    for (size_t i = 0; i < allNodes.size(); ++i) {
        Node* n = allNodes[i];
        ser[i].id = n->id;
        ser[i].listIdx = n->listIdx;
        ser[i].pos = n->pos;
        ser[i].nextId = n->next ? n->next->id : -1;
        ser[i].crossId = n->cross ? n->cross->id : -1;
    }
    return ser;
}

// deserialize: ids -> pointers
void deserialize(
    const vector<SNode>& ser,
    int N,
    const vector<int>& lens,
    vector<Node*>& allNodesOut,
    vector<vector<Node*>>& listsOut
) {
    int total = (int)ser.size();
    allNodesOut.assign(total, nullptr);
    listsOut.assign(N, {});
    for (int i = 0; i < N; ++i) listsOut[i].resize(lens[i], nullptr);

    // create node objects
    for (int i = 0; i < total; ++i) {
        const SNode& s = ser[i];
        Node* n = new Node(s.id, s.listIdx, s.pos);
        allNodesOut[s.id] = n;
        listsOut[s.listIdx][s.pos] = n;
    }

    // connect pointers
    for (int i = 0; i < total; ++i) {
        const SNode& s = ser[i];
        Node* n = allNodesOut[s.id];
        n->next = (s.nextId == -1) ? nullptr : allNodesOut[s.nextId];
        n->cross = (s.crossId == -1) ? nullptr : allNodesOut[s.crossId];
    }
}

// BFS to find shortest path using next / cross pointers
vector<int> shortestPath(Node* start, Node* target, int totalNodes) {
    vector<int> dist(totalNodes, -1);
    vector<int> prev(totalNodes, -1);
    queue<Node*> q;

    dist[start->id] = 0;
    q.push(start);

    while (!q.empty()) {
        Node* cur = q.front();
        q.pop();

        if (cur == target) break;

        auto relax = [&](Node* nxt) {
            if (!nxt) return;
            if (dist[nxt->id] == -1) {
                dist[nxt->id] = dist[cur->id] + 1;
                prev[nxt->id] = cur->id;
                q.push(nxt);
            }
        };

        relax(cur->next);
        relax(cur->cross);
    }

    if (dist[target->id] == -1) return {}; // no path

    // reconstruct path from target back to start
    vector<int> path;
    for (int v = target->id; v != -1; v = prev[v])
        path.push_back(v);
    reverse(path.begin(), path.end());
    return path;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;

    vector<int> lens(N);
    int total = 0;
    for (int i = 0; i < N; ++i) {
        cin >> lens[i];
        total += lens[i];
    }

    if (total == 0) {
        cout << "NO PATH\n";
        return 0;
    }

    // build initial nodes
    vector<Node*> allNodes(total, nullptr);
    vector<vector<Node*>> lists(N);

    int idCounter = 0;
    for (int i = 0; i < N; ++i) {
        lists[i].resize(lens[i], nullptr);
        for (int j = 0; j < lens[i]; ++j) {
            Node* n = new Node(idCounter, i, j);
            allNodes[idCounter] = n;
            lists[i][j] = n;
            ++idCounter;
        }
    }

    // set "next" pointers inside each list
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < lens[i]; ++j) {
            if (j + 1 < lens[i]) {
                lists[i][j]->next = lists[i][j + 1];
            } else {
                lists[i][j]->next = nullptr;
            }
        }
    }

    // read cross pointers
    // order: list 0 nodes (pos 0..L0-1), then list 1, etc.
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < lens[i]; ++j) {
            int cl, cp;
            cin >> cl >> cp;
            if (cl >= 0) {
                if (cl < 0 || cl >= N || cp < 0 || cp >= lens[cl]) {
                    cerr << "Invalid cross reference\n";
                    return 1;
                }
                lists[i][j]->cross = lists[cl][cp];
            } else {
                lists[i][j]->cross = nullptr;
            }
        }
    }

    int XL, Xpos, YL, Ypos;
    cin >> XL >> Xpos >> YL >> Ypos;

    if (XL < 0 || XL >= N || Xpos < 0 || Xpos >= lens[XL] ||
        YL < 0 || YL >= N || Ypos < 0 || Ypos >= lens[YL]) {
        cout << "NO PATH\n";
        return 0;
    }

    Node* startOrig = lists[XL][Xpos];
    Node* targetOrig = lists[YL][Ypos];

    // --- serialize then deserialize ---
    vector<SNode> serialized = serialize(allNodes);

    vector<Node*> allNodes2;
    vector<vector<Node*>> lists2;
    deserialize(serialized, N, lens, allNodes2, lists2);

    Node* start = lists2[XL][Xpos];
    Node* target = lists2[YL][Ypos];

    // compute shortest path on deserialized structure
    vector<int> path = shortestPath(start, target, total);

    if (path.empty()) {
        cout << "NO PATH\n";
    } else {
        int length = (int)path.size() - 1;
        cout << length << "\n";
        for (size_t i = 0; i < path.size(); ++i) {
            Node* n = allNodes2[path[i]];
            if (i) cout << ' ';
            cout << "<" << n->listIdx << ":" << n->pos << ">";
        }
        cout << "\n";
    }

    // clean up original nodes
    for (Node* n : allNodes) delete n;
    for (Node* n : allNodes2) delete n;

    return 0;
}
