#include <bits/stdc++.h>
using namespace std;

/*
    Multi-level priority queue with circular queues at each level.

    Model
    -----
    - There are K priority levels: 0 is highest, K-1 is lowest.
    - Each level is a circular queue of fixed capacity C.
    - Each item has:
          value        : arbitrary integer payload
          arrivalTime  : "time" when it was enqueued (for promotion)

    Operations
    ----------
    1) ENQ x p
         Put value x into the "appropriate level".
         We try level p first; if its queue is full, we try p+1, p+2, ...
         until some level has space. If all levels are full, we print
           "QUEUE FULL"
         and drop the item.

    2) DEQ
         Remove from the highest-priority non-empty level (smallest index).
         Print:
             value levelIndex
         If all queues are empty, print:
             EMPTY

    3) PROMOTE
         For every element in lower-priority levels, if it has waited at
         least T "time units", move it up one level (towards higher
         priority) when there is room.  Order within a level is preserved.
         (We scan each level once per PROMOTE and rotate elements.)

    Time
    ----
    We maintain a global 'currentTime' which increments by 1 before every
    operation (ENQ / DEQ / PROMOTE).  Waiting time for an item is:

        currentTime - arrivalTime

    Input format
    ------------
        K C T Q
        (K = number of priority levels, C = capacity of each circular queue,
         T = promotion threshold in time units,
         Q = number of operations)

        Then Q lines, each being one of:

        ENQ x p      (int x, int p)
        DEQ
        PROMOTE

    Output
    ------
        For DEQ:
            "EMPTY" or "<value> <levelIndex>"
        For ENQ that cannot insert anywhere:
            "QUEUE FULL"

        PROMOTE produces no direct output.
*/

struct Item {
    int value;
    long long arrivalTime;
};

class CircularQueue {
    vector<Item> buf;
    int head;
    int tail;
    int sz;
    int cap;

public:
    CircularQueue(int c = 0) { init(c); }

    void init(int c) {
        cap = c;
        buf.assign(cap, Item{0, 0});
        head = tail = sz = 0;
    }

    bool empty() const { return sz == 0; }
    bool full()  const { return sz == cap; }
    int size()   const { return sz; }

    bool push(const Item& it) {
        if (full()) return false;
        buf[tail] = it;
        tail = (tail + 1) % cap;
        ++sz;
        return true;
    }

    bool pop(Item& out) {
        if (empty()) return false;
        out = buf[head];
        head = (head + 1) % cap;
        --sz;
        return true;
    }

    // Peeks front without removing; caller must ensure !empty()
    Item& front() { return buf[head]; }
};

class PriorityQueueSystem {
    int K;
    int C;
    long long threshold;
    long long currentTime;
    vector<CircularQueue> levels;

public:
    PriorityQueueSystem(int k, int c, long long t)
        : K(k), C(c), threshold(t), currentTime(0), levels(k) {
        for (int i = 0; i < K; ++i) levels[i].init(C);
    }

    // Called before every external operation
    void tick() { ++currentTime; }

    void enqueue(int x, int p) {
        if (p < 0) p = 0;
        if (p >= K) p = K - 1;

        Item it{x, currentTime};

        bool inserted = false;
        for (int lvl = p; lvl < K; ++lvl) {
            if (!levels[lvl].full()) {
                levels[lvl].push(it);
                inserted = true;
                break;
            }
        }

        if (!inserted) {
            cout << "QUEUE FULL\n";
        }
    }

    void dequeue() {
        for (int lvl = 0; lvl < K; ++lvl) {
            if (!levels[lvl].empty()) {
                Item it;
                levels[lvl].pop(it);
                cout << it.value << ' ' << lvl << '\n';
                return;
            }
        }
        cout << "EMPTY\n";
    }

    void promote() {
        // Start from lowest priority and move upwards
        for (int lvl = K - 1; lvl > 0; --lvl) {
            int cnt = levels[lvl].size();
            for (int i = 0; i < cnt; ++i) {
                Item it;
                levels[lvl].pop(it);  // take front

                long long waitTime = currentTime - it.arrivalTime;
                if (waitTime >= threshold && !levels[lvl - 1].full()) {
                    // promote to higher priority
                    levels[lvl - 1].push(it);
                } else {
                    // keep in same level, but rotated to back
                    levels[lvl].push(it);
                }
            }
        }
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int K, C;
    long long T;
    int Q;

    if (!(cin >> K >> C >> T >> Q)) return 0;

    PriorityQueueSystem sys(K, C, T);

    for (int i = 0; i < Q; ++i) {
        string op;
        cin >> op;
        sys.tick();

        if (op == "ENQ") {
            int x, p;
            cin >> x >> p;
            sys.enqueue(x, p);
        } else if (op == "DEQ") {
            sys.dequeue();
        } else if (op == "PROMOTE") {
            sys.promote();
        }
    }
    return 0;
}
