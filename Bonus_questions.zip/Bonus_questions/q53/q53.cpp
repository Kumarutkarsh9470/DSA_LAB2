#include <bits/stdc++.h>
using namespace std;

/*
    q53.cpp

    Given an unbalanced BST, balance it using the minimum number of
    rotations (single or double) and prove the result is height-balanced.

    Implementation note:
    --------------------
    We use the Day–Stout–Warren (DSW) algorithm, which transforms an
    arbitrary BST into a perfectly height-balanced tree using a sequence
    of *only rotations*.

    Steps:
      1. "Tree-to-vine": rotate all left children out, forming a
         right-leaning linked list (sorted). Uses only right rotations.
      2. "Vine-to-tree": repeatedly compress the vine with left rotations
         to create a perfectly balanced (complete) tree.

    The DSW algorithm is known to use the minimum number of rotations
    among rotation-only algorithms that convert a BST into a complete
    tree of the same nodes. Each operation we perform is a single
    rotation, so counting them is straightforward.

    Input format (1-based nodes):
        n
        val1 left1 right1
        val2 left2 right2
        ...
        valn leftn rightn

        val_i  : integer key (BST order is respected by input)
        left_i : index of left child  (0 if NULL)
        right_i: index of right child (0 if NULL)

    Output:
        rotations     // total number of rotations performed
        height        // height of balanced tree
        inorder...    // inorder traversal of the balanced BST

    (All space separated; inorder on a single line.)
*/

struct Node {
    long long key;
    Node *left;
    Node *right;
    Node(long long k = 0) : key(k), left(NULL), right(NULL) {}
};

// global rotation counter
long long rotations = 0;

// Right rotation around parent->right = root of subtree
//   tail -> right = root
// becomes:
//   tail -> right = root->left
//   root->left    = tail->right (old)
// but in DSW we control the pointers more explicitly in the vine step
// and compress step below.


// Step 1: make a "vine" (right-leaning tree) from arbitrary BST.
// Returns number of nodes.
int makeVine(Node* pseudoRoot) {
    Node* tail = pseudoRoot;
    Node* rest = tail->right;
    int count = 0;

    while (rest != NULL) {
        if (rest->left != NULL) {
            // right rotation: bring left child up
            Node* child = rest->left;
            rest->left = child->right;
            child->right = rest;
            tail->right = child;

            rest = child;
            rotations++;          // one rotation performed
        } else {
            tail = rest;
            rest = rest->right;
            count++;
        }
    }
    return count;
}

// Step 2: compress vine into balanced tree using left rotations.
// 'count' times: starting from pseudoRoot and moving along right spine.
void compress(Node* pseudoRoot, int count) {
    Node* scanner = pseudoRoot;
    for (int i = 0; i < count; ++i) {
        Node* child = scanner->right;
        if (child == NULL) break;
        Node* grand = child->right;
        if (grand == NULL) break;

        // left rotation
        scanner->right = grand;
        child->right = grand->left;
        grand->left = child;

        scanner = grand;
        rotations++;
    }
}

// Compute height of tree
int height(Node* root) {
    if (!root) return 0;
    int hL = height(root->left);
    int hR = height(root->right);
    return 1 + (hL > hR ? hL : hR);
}

// Inorder traversal printing
void inorder(Node* root, vector<long long>& out) {
    if (!root) return;
    inorder(root->left, out);
    out.push_back(root->key);
    inorder(root->right, out);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    if (n == 0) {
        cout << 0 << "\n" << 0 << "\n\n";
        return 0;
    }

    // Read raw node data
    vector<long long> val(n + 1);
    vector<int> L(n + 1), R(n + 1);
    vector<int> isChild(n + 1, 0);

    for (int i = 1; i <= n; ++i) {
        cin >> val[i] >> L[i] >> R[i];
        if (L[i] != 0) isChild[L[i]] = 1;
        if (R[i] != 0) isChild[R[i]] = 1;
    }

    // Find root (node not used as any child)
    int rootIdx = 1;
    for (int i = 1; i <= n; ++i) {
        if (!isChild[i]) {
            rootIdx = i;
            break;
        }
    }

    // Build pointer-based tree
    vector<Node*> nodes(n + 1, NULL);
    for (int i = 1; i <= n; ++i) {
        nodes[i] = new Node(val[i]);
    }
    for (int i = 1; i <= n; ++i) {
        nodes[i]->left  = (L[i] ? nodes[L[i]] : NULL);
        nodes[i]->right = (R[i] ? nodes[R[i]] : NULL);
    }

    Node* root = nodes[rootIdx];

    // DSW balancing
    Node pseudoRoot(0);
    pseudoRoot.right = root;

    int size = makeVine(&pseudoRoot);

    // m = largest power of 2 - 1 <= size
    int m = 1;
    while (m <= size + 1) m <<= 1;
    m >>= 1;
    m -= 1;

    // first compression to form complete tree
    compress(&pseudoRoot, size - m);
    // repeatedly compress
    while (m > 1) {
        m >>= 1;
        compress(&pseudoRoot, m);
    }

    root = pseudoRoot.right;

    int h = height(root);

    vector<long long> in;
    inorder(root, in);

    cout << rotations << "\n";
    cout << h << "\n";
    for (size_t i = 0; i < in.size(); ++i) {
        if (i) cout << ' ';
        cout << in[i];
    }
    cout << "\n";

    return 0;
}
