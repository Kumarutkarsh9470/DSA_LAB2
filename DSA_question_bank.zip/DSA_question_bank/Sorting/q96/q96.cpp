#include <bits/stdc++.h>
using namespace std;

/*
    q96 — Extended Bucket Sort for negative and positive integers.
    Array tested: [-15, 23, -8, 42, -3, 17, -20, 5]

    Strategy:
      1. Find min and max values.
      2. Create buckets for entire range.
      3. Normalize index by subtracting minValue.
      4. Insert elements into buckets.
      5. Sort each bucket using Insertion Sort.
      6. Concatenate and show bucket distribution.
*/

// ----------------------------------------------------------
// Insertion sort for each bucket
// ----------------------------------------------------------
void insertionSort(vector<int> &arr) {
    for (int i = 1; i < (int)arr.size(); i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// ----------------------------------------------------------
// Extended Bucket Sort for negative + positive integers
// ----------------------------------------------------------
vector<int> bucketSortExtended(const vector<int> &a) {
    if (a.empty()) return {};

    int mn = *min_element(a.begin(), a.end());
    int mx = *max_element(a.begin(), a.end());

    int range = mx - mn + 1;

    vector<vector<int>> buckets(range);

    // Distribute values
    for (int x : a) {
        int idx = x - mn;      // Normalize index
        buckets[idx].push_back(x);
    }

    // Show bucket distribution
    cout << "\nBucket distribution: \n";
    for (int i = 0; i < range; i++) {
        int bucketValue = i + mn;
        cout << "Bucket for value = " << bucketValue << ": ";
        if (buckets[i].empty()) cout << "empty";
        else {
            for (int x : buckets[i]) cout << x << " ";
        }
        cout << "\n";
    }

    // Sort each bucket (Insertion Sort)
    for (int i = 0; i < range; i++) {
        if (!buckets[i].empty())
            insertionSort(buckets[i]);
    }

    // Concatenate
    vector<int> result;
    for (int i = 0; i < range; i++) {
        for (int x : buckets[i]) result.push_back(x);
    }

    return result;
}

int main() {
    vector<int> arr = {-15, 23, -8, 42, -3, 17, -20, 5};

    cout << "Original array:\n";
    for (int x : arr) cout << x << " ";
    cout << "\n";

    vector<int> sorted = bucketSortExtended(arr);

    cout << "\nSorted output:\n";
    for (int x : sorted) cout << x << " ";
    cout << "\n";

    // Verify correctness
    vector<int> check = arr;
    sort(check.begin(), check.end());

    if (check == sorted)
        cout << "\nVerification: SUCCESS — Sorting correct.\n";
    else
        cout << "\nVerification: FAILURE — Sorting incorrect.\n";

    cout << "\nWhy is this approach inefficient for large ranges?\n";
    cout << "  - Bucket Sort requires creating one bucket per value in the range.\n";
    cout << "  - For range [mn..mx], number of buckets = mx - mn + 1.\n";
    cout << "  - If mn = -1,000,000 and mx = 1,000,000, we need 2,000,001 buckets.\n";
    cout << "  - Most buckets are empty → wasted memory.\n";
    cout << "  - Insertion sort inside buckets adds extra overhead.\n";
    cout << "Thus, bucket sort is inefficient when the data range is large but\n";
    cout << "the number of actual elements is small.\n";

    return 0;
}
