#include <bits/stdc++.h>
using namespace std;

bool isOpen(char c) {
    return c == '(' || c == '[' || c == '{';
}

bool matches(char open, char close) {
    return (open == '(' && close == ')') ||
           (open == '[' && close == ']') ||
           (open == '{' && close == '}');
}

void dfs(int idx,
         const string &s,
         string &cur,         // built string so far
         string &st,          // stack of openings
         int rem,             // remaining corrections
         set<string> &ans)    // store unique results
{
    int n = (int)s.size();

    // If we've placed all characters
    if (idx == n) {
        // Valid only if stack empty and exactly K corrections used
        if (st.empty() && rem == 0) {
            ans.insert(cur);
        }
        return;
    }

    // Try every possible bracket character at this position
    static const vector<char> allBrackets = { '(', ')', '[', ']', '{', '}' };

    for (char c : allBrackets) {
        int cost = (c == s[idx] ? 0 : 1);
        if (cost > rem) continue;  // cannot afford this change

        if (isOpen(c)) {
            // Use c as an opening bracket
            st.push_back(c);
            cur.push_back(c);

            dfs(idx + 1, s, cur, st, rem - cost, ans);

            // backtrack
            cur.pop_back();
            st.pop_back();
        } else {
            // closing bracket: must match top of stack
            if (!st.empty() && matches(st.back(), c)) {
                char top = st.back();
                st.pop_back();
                cur.push_back(c);

                dfs(idx + 1, s, cur, st, rem - cost, ans);

                // backtrack
                cur.pop_back();
                st.push_back(top);
            }
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    int K;

    // Example input format:
    // first line: bracket string
    // second line: K
    if (!(cin >> s >> K)) {
        return 0;
    }

    set<string> ans;
    string cur, st;
    dfs(0, s, cur, st, K, ans);

    if (ans.empty()) {
        cout << "No valid sequence with exactly " << K << " corrections\n";
    } else {
        for (const auto &seq : ans) {
            cout << seq << "\n";
        }
    }

    return 0;
}
