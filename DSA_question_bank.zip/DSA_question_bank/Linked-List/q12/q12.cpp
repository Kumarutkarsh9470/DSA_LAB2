#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int x) : data(x), next(nullptr) {}
};

// Build list from vector
Node* buildList(const vector<int>& a) {
    if (a.empty()) return nullptr;
    Node* head = new Node(a[0]);
    Node* tail = head;
    for (size_t i = 1; i < a.size(); ++i) {
        tail->next = new Node(a[i]);
        tail = tail->next;
    }
    return head;
}

// Flatten list to array of values
vector<int> toArray(Node* head) {
    vector<int> a;
    for (Node* cur = head; cur != nullptr; cur = cur->next)
        a.push_back(cur->data);
    return a;
}

/*
    Compute minimum palindrome partitioning of a sequence a[0..n-1].

    We first precompute pal[i][j] = true iff a[i..j] is a palindrome.

    Then classic DP:
        dp[i]   = minimum number of palindromic segments
                  covering prefix a[0..i].
        prev[i] = starting index of the last segment in an
                  optimal partition of prefix ending at i.

    Recurrence:
        dp[i] = min over all j<=i with pal[j][i]:
                    (j==0 ? 1 : dp[j-1] + 1)

    Answer is dp[n-1].  We reconstruct segments using prev[].
*/
void minPalindromePartition(const vector<int>& a,
                            int& minSegments,
                            vector<pair<int,int>>& segments)
{
    int n = (int)a.size();
    if (n == 0) {
        minSegments = 0;
        segments.clear();
        return;
    }

    // Precompute palindromes O(n^2)
    vector<vector<bool>> pal(n, vector<bool>(n, false));

    // length 1
    for (int i = 0; i < n; ++i)
        pal[i][i] = true;

    // length >= 2
    for (int len = 2; len <= n; ++len) {
        for (int i = 0; i + len - 1 < n; ++i) {
            int j = i + len - 1;
            if (a[i] == a[j]) {
                if (len == 2 || pal[i+1][j-1])
                    pal[i][j] = true;
            }
        }
    }

    const int INF = 1e9;
    vector<int> dp(n, INF), prev(n, -1);

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j <= i; ++j) {
            if (pal[j][i]) {
                int cost = (j == 0 ? 1 : dp[j-1] + 1);
                if (cost < dp[i]) {
                    dp[i] = cost;
                    prev[i] = j;
                }
            }
        }
    }

    minSegments = dp[n-1];

    // Reconstruct segments from prev[]
    segments.clear();
    int idx = n - 1;
    while (idx >= 0) {
        int start = prev[idx];
        segments.push_back({start, idx});  // [start, idx] is a palindromic segment
        idx = start - 1;
    }
    reverse(segments.begin(), segments.end());
}

// Print list with '|' separators at partition points (for clarity)
void printPartitioned(Node* head, const vector<pair<int,int>>& segments) {
    // Convert list to array for easy indexing when printing
    vector<int> a = toArray(head);

    // Build a marker array where cutAfter[i] = true iff there is a cut after index i
    int n = (int)a.size();
    vector<bool> cutAfter(n, false);
    for (auto seg : segments) {
        int end = seg.second;
        if (end >= 0 && end < n) cutAfter[end] = true;
    }

    for (int i = 0; i < n; ++i) {
        cout << a[i];
        if (i + 1 < n) {
            if (cutAfter[i]) cout << " | ";
            else cout << " ";
        }
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    vector<int> values(n);
    for (int i = 0; i < n; ++i) cin >> values[i];

    Node* head = buildList(values);

    int minSegments;
    vector<pair<int,int>> segments;
    minPalindromePartition(values, minSegments, segments);

    cout << "Minimum number of palindromic segments: " << minSegments << "\n";
    cout << "Partition (segments separated by '|'):\n";
    printPartitioned(head, segments);
    cout << "Segments (start_index end_index):\n";
    for (auto seg : segments) {
        cout << seg.first << " " << seg.second << "\n";
    }
return 0;
}
