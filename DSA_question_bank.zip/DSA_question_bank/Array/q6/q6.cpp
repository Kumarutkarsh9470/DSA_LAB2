#include <bits/stdc++.h>
using namespace std;
class SlidingMedian {
multiset<int> lo;  
multiset<int> hi; 
void rebalance() {
 while (lo.size() > hi.size() + 1) {
 hi.insert(*lo.rbegin());
auto it = lo.end();
--it;
lo.erase(it);
}
while (lo.size() < hi.size()) {
lo.insert(*hi.begin());
hi.erase(hi.begin());
}
}

public:
void insert(int x) {
if (lo.empty() || x <= *lo.rbegin()) {
lo.insert(x);
} else {
hi.insert(x);
}
rebalance();
}
void erase(int x) {
if (!lo.empty() && x <= *lo.rbegin()) {
auto it = lo.find(x);
if (it != lo.end()) lo.erase(it);
else {
auto it2 = hi.find(x);
if (it2 != hi.end()) hi.erase(it2);
}
} else {
auto it = hi.find(x);
if (it != hi.end()) hi.erase(it);
else {
auto it2 = lo.find(x);
 if (it2 != lo.end()) lo.erase(it2);
}
}
rebalance();
}
double getMedian() const {
if (lo.empty() && hi.empty()) return 0.0;  
 if ((lo.size() + hi.size()) % 2 == 1) {
 return *lo.rbegin();            
} else{
 return (*lo.rbegin() / 2.0) + (*hi.begin() / 2.0);
 }
}
};

int main() {
vector<int> nums = {1, 3, -1, -3, 5, 3, 6, 7};
int K = 3;
SlidingMedian sm;
vector<double> medians;
for (int i = 0; i < K; ++i) sm.insert(nums[i]);
medians.push_back(sm.getMedian());
for (int i = K; i < (int)nums.size(); ++i) {
sm.erase(nums[i - K]);  
sm.insert(nums[i]);      
 medians.push_back(sm.getMedian());
}
for (double x : medians) cout << x << " ";
cout << endl;
return 0;
}
