#include <bits/stdc++.h>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode(int x) : val(x), next(NULL) {}
};

// Merge K sorted linked lists with priorities.
// If two nodes have the same value, the node coming from
// the list with HIGHER priority (smaller priority number)
// should come first.
struct HeapNode {
    int val;          // node value
    int listId;       // which list it came from
    int priority;     // priority of that list (smaller = higher priority)
    ListNode *node;   // pointer to the node itself
};

// comparator for min-heap
struct Cmp {
    bool operator()(const HeapNode &a, const HeapNode &b) const {
        if (a.val != b.val) {
            return a.val > b.val;              // smaller value first
        }
        return a.priority > b.priority;        // if equal value, higher priority first
    }
};

ListNode* mergeKListsWithPriority(vector<ListNode*> &lists, vector<int> &prior) {
    priority_queue<HeapNode, vector<HeapNode>, Cmp> pq;

    int k = (int)lists.size();
    for (int i = 0; i < k; i++) {
        if (lists[i] != NULL) {
            HeapNode h;
            h.val = lists[i]->val;
            h.listId = i;
            h.priority = prior[i];
            h.node = lists[i];
            pq.push(h);
        }
    }

    ListNode dummy(0);
    ListNode *tail = &dummy;

    while (!pq.empty()) {
        HeapNode cur = pq.top();
        pq.pop();

        // attach this node
        tail->next = cur.node;
        tail = tail->next;

        // advance in that list
        if (cur.node->next != NULL) {
            ListNode *nextNode = cur.node->next;
            HeapNode h;
            h.val = nextNode->val;
            h.listId = cur.listId;
            h.priority = cur.priority;   // same list -> same priority
            h.node = nextNode;
            pq.push(h);
        }
    }

    // make sure the final tail points to NULL
    if (tail) tail->next = NULL;
    return dummy.next;
}

// Helper to create a list from a vector
ListNode* buildList(const vector<int> &v) {
    if (v.empty()) return NULL;
    ListNode *head = new ListNode(v[0]);
    ListNode *cur = head;
    for (int i = 1; i < (int)v.size(); i++) {
        cur->next = new ListNode(v[i]);
        cur = cur->next;
    }
    return head;
}

// Helper to print a list
void printList(ListNode *head) {
    while (head != NULL) {
        cout << head->val;
        if (head->next) cout << " -> ";
        head = head->next;
    }
    cout << "\n";
}

int main() {
    // Example:
    // 3 sorted lists with different priorities.
    // Smaller priority number = higher priority.
    vector<int> p0 = {1, 4, 7};
    vector<int> p1 = {1, 3, 8};
    vector<int> p2 = {1, 4, 9};

    ListNode *l0 = buildList(p0);
    ListNode *l1 = buildList(p1);
    ListNode *l2 = buildList(p2);

    vector<ListNode*> lists;
    lists.push_back(l0);
    lists.push_back(l1);
    lists.push_back(l2);

    // priorities: list 0 has highest (0), then list 1 (1), then list 2 (2)
    vector<int> prior;
    prior.push_back(0); // list 0
    prior.push_back(1); // list 1
    prior.push_back(2); // list 2

    ListNode *merged = mergeKListsWithPriority(lists, prior);

    printList(merged);

    return 0;
}
