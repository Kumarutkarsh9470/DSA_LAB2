#include <bits/stdc++.h>
using namespace std;

// -----------------------------------------------------
// Statistics container for a single Quicksort run
// -----------------------------------------------------
struct Stats {
    int maxDepth;
    long long comparisons;

    Stats() : maxDepth(0), comparisons(0) {}
};

// -----------------------------------------------------
// Pivot strategies
// -----------------------------------------------------
enum PivotStrategy {
    PIVOT_FIRST = 0,
    PIVOT_MIDDLE = 1,
    PIVOT_MEDIAN3 = 2
};

// Choose pivot index according to strategy.
int choosePivot(const vector<int>& a, int l, int r, PivotStrategy strat) {
    if (strat == PIVOT_FIRST) {
        return l;
    } else if (strat == PIVOT_MIDDLE) {
        return l + (r - l) / 2;
    } else { // PIVOT_MEDIAN3
        int m = l + (r - l) / 2;
        int x = a[l], y = a[m], z = a[r];
        // compute median of (x,y,z) and return corresponding index
        if (x <= y) {
            if (y <= z) return m;  // x <= y <= z
            else if (x <= z) return r; // x <= z < y
            else return l; // z < x <= y
        } else { // y < x
            if (x <= z) return l;  // y < x <= z
            else if (y <= z) return r; // y <= z < x
            else return m; // z < y < x
        }
    }
}

// -----------------------------------------------------
// Quicksort (Lomuto partition) with stats
// -----------------------------------------------------
void quicksortRec(vector<int>& a, int l, int r,
                  PivotStrategy strat, Stats& st, int depth) {
    if (l >= r) return;

    if (depth > st.maxDepth) st.maxDepth = depth;

    int pIdx = choosePivot(a, l, r, strat);
    swap(a[pIdx], a[r]);           // move pivot to end
    int pivot = a[r];

    int i = l - 1;
    for (int j = l; j < r; ++j) {
        st.comparisons++;
        if (a[j] <= pivot) {
            ++i;
            if (i != j) {
                swap(a[i], a[j]);
            }
        }
    }
    int pivotPos = i + 1;
    swap(a[pivotPos], a[r]);

    quicksortRec(a, l, pivotPos - 1, strat, st, depth + 1);
    quicksortRec(a, pivotPos + 1, r, strat, st, depth + 1);
}

Stats quicksort(vector<int> arr, PivotStrategy strat) {
    Stats st;
    if (!arr.empty()) {
        quicksortRec(arr, 0, (int)arr.size() - 1, strat, st, 1);
    }
    return st;
}

// -----------------------------------------------------
// Dataset generators
// -----------------------------------------------------
vector<int> makeSorted(int n) {
    vector<int> a(n);
    for (int i = 0; i < n; ++i) a[i] = i;
    return a;
}

vector<int> makeReverseSorted(int n) {
    vector<int> a(n);
    for (int i = 0; i < n; ++i) a[i] = n - 1 - i;
    return a;
}

vector<int> makeRandom(int n, mt19937& rng) {
    vector<int> a(n);
    uniform_int_distribution<int> dist(-1000000, 1000000);
    for (int i = 0; i < n; ++i) a[i] = dist(rng);
    return a;
}

vector<int> makeAllEqual(int n, int val = 42) {
    return vector<int>(n, val);
}

// -----------------------------------------------------
// Pretty printing
// -----------------------------------------------------
string pivotName(PivotStrategy s) {
    if (s == PIVOT_FIRST) return "First element";
    if (s == PIVOT_MIDDLE) return "Middle element";
    return "Median-of-three";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    const int N = 1000;

    mt19937 rng(123456); // deterministic randomness

    // Prepare datasets
    vector<int> sortedArr       = makeSorted(N);
    vector<int> reverseArr      = makeReverseSorted(N);
    vector<int> randomArr       = makeRandom(N, rng);
    vector<int> allEqualArr     = makeAllEqual(N);

    struct Case {
        string name;
        vector<int> data;
    };

    vector<Case> cases;
    cases.push_back({"Sorted", sortedArr});
    cases.push_back({"Reverse sorted", reverseArr});
    cases.push_back({"Random", randomArr});
    cases.push_back({"All equal", allEqualArr});

    vector<PivotStrategy> strategies;
    strategies.push_back(PIVOT_FIRST);
    strategies.push_back(PIVOT_MIDDLE);
    strategies.push_back(PIVOT_MEDIAN3);

    cout << "Array size N = " << N << "\n\n";

    for (size_t ci = 0; ci < cases.size(); ++ci) {
        cout << "=== Input type: " << cases[ci].name << " ===\n";
        for (size_t si = 0; si < strategies.size(); ++si) {
            Stats st = quicksort(cases[ci].data, strategies[si]);
            cout << "  Pivot: " << pivotName(strategies[si]) << "\n";
            cout << "    Max recursion depth: " << st.maxDepth << "\n";
            cout << "    Comparisons:         " << st.comparisons << "\n";
        }
        cout << "\n";
    }

    return 0;
}
