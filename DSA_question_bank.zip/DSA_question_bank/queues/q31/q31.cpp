#include <bits/stdc++.h>
using namespace std;

// Represents one item in the decaying priority queue
struct Item {
    int id;
    double basePriority;
    double halfLife;
    double insertTime;
    double logBase;
    bool active;

    Item(int _id = 0, double p = 0.0, double h = 1.0, double t = 0.0)
        : id(_id), basePriority(p), halfLife(h),
          insertTime(t), logBase(log(max(p, 1e-300))), active(true) {}
};

// Global ln(2) constant
const double LN2 = std::log(2.0);

// Compute log of effective priority at time 'currentTime'
double logEffective(const Item &it, double currentTime) {
    if (!it.active) return -1e300; // effectively -infinity
    double dt = currentTime - it.insertTime;
    if (dt <= 0.0) return it.logBase;
    double factor = dt / it.halfLife;
    return it.logBase - LN2 * factor;
}

// Comparator for priority_queue: max-heap by effective priority
struct DecayCompare {
    const vector<Item> *items;
    const double *currentTime;

    bool operator()(int a, int b) const {
        const Item &ia = (*items)[a];
        const Item &ib = (*items)[b];
        double la = logEffective(ia, *currentTime);
        double lb = logEffective(ib, *currentTime);
        // priority_queue in C++ puts the "largest" at top,
        // but comparator returns true if a has LOWER priority than b.
        return la < lb;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    double currentTime = 0.0;
    vector<Item> items;
    vector<bool> alive; // parallel to items

    // We'll build the priority_queue lazily
    DecayCompare cmp;
    cmp.items = &items;
    cmp.currentTime = &currentTime;
    priority_queue<int, vector<int>, DecayCompare> pq(cmp);

    bool heapValid = false;

    auto rebuildHeap = [&]() {
        // Rebuild heap from scratch using all active items
        while (!pq.empty()) pq.pop();
        for (int i = 0; i < (int)items.size(); ++i) {
            if (items[i].active) pq.push(i);
        }
        heapValid = true;
    };

    cout.setf(ios::fixed);
    cout << setprecision(6);

    while (Q--) {
        string cmd;
        cin >> cmd;

        if (cmd == "ENQ" || cmd == "ENQUEUE") {
            int id;
            double p, h;
            cin >> id >> p >> h;
            if (h <= 0) h = 1.0;          // basic safety
            if (p <= 0) p = 1e-9;         // non-positive priorities treated tiny

            items.emplace_back(id, p, h, currentTime);
            items.back().active = true;

            heapValid = false; // new item -> heap must be rebuilt for correctness
            cout << "OK\n";

        } else if (cmd == "TIME" || cmd == "ADVANCE") {
            double dt;
            cin >> dt;
            currentTime += dt;
            heapValid = false; // relative ordering might change
            cout << "OK\n";

        } else if (cmd == "POP" || cmd == "DEQ") {
            if (!heapValid) rebuildHeap();

            // Remove any stale inactive items at top
            while (!pq.empty() && !items[pq.top()].active) {
                pq.pop();
            }

            if (pq.empty()) {
                cout << "EMPTY\n";
                continue;
            }

            int idx = pq.top();
            pq.pop();

            Item &it = items[idx];
            it.active = false;

            double logEff = logEffective(it, currentTime);
            double eff = exp(logEff);

            cout << it.id << " " << eff << "\n";

        } else {
            // Unknown command: consume rest of line and print error
            string rest;
            getline(cin, rest);
            cout << "ERR\n";
        }
    }

    return 0;
}
