#include <bits/stdc++.h>
using namespace std;

/*
   Given a string s consisting of '(', ')' and '?'.

   Each '?' can be turned into:
       - '('   with cost cOpen[i]
       - ')'   with cost cClose[i]
       - empty (removed) with cost cEmpty[i]

   Fixed characters '(' and ')' have cost 0 and cannot be changed.

   Goal: choose actions for all '?' so that the final string is a
   valid balanced parenthesis sequence and the total cost is minimum.
   If impossible, print -1.

   Input format:
       s
       For each i from 0 to s.size()-1, in order:
           if s[i] == '?':
               three integers: costOpen costClose costEmpty
           (for '(' or ')' nothing is read)

   Output:
       Minimal total cost, or -1 if impossible.

   Example:
       Input:
           (?))
           3 5 2
       Output:
           5

       Explanation:
           s = "(?))"
           Only position 1 is '?':
             - as '(' cost=3 -> "(() )"  (not balanced)
             - as ')' cost=5 -> "() )"  (balanced string "()") + extra ')'? wait.
           (You can design your own tests; this is just illustrative.
           Real tests should ensure whole string balances.)
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    if (!(cin >> s)) return 0;
    int n = (int)s.size();

    vector<long long> costOpen(n, 0), costClose(n, 0), costEmpty(n, 0);
    vector<bool> isQ(n, false);

    for (int i = 0; i < n; ++i) {
        if (s[i] == '?') {
            isQ[i] = true;
            long long a, b, c;
            cin >> a >> b >> c;        // costs for '(', ')', empty
            costOpen[i]  = a;
            costClose[i] = b;
            costEmpty[i] = c;
        }
    }

    const long long INF = (1LL << 60);

    // dp[bal] = min cost to process prefix so far with current balance = bal
    vector<long long> dp(n + 1, INF), nextDP(n + 1, INF);
    dp[0] = 0; // empty prefix, zero balance, zero cost

    for (int i = 0; i < n; ++i) {
        fill(nextDP.begin(), nextDP.end(), INF);

        if (s[i] == '(') {
            for (int bal = 0; bal <= n; ++bal) {
                if (dp[bal] == INF) continue;
                int nb = bal + 1;
                if (nb <= n) {
                    nextDP[nb] = min(nextDP[nb], dp[bal]); // cost 0
                }
            }
        } else if (s[i] == ')') {
            for (int bal = 0; bal <= n; ++bal) {
                if (dp[bal] == INF) continue;
                if (bal == 0) continue;   // cannot close more than open
                int nb = bal - 1;
                nextDP[nb] = min(nextDP[nb], dp[bal]); // cost 0
            }
        } else { // '?'
            for (int bal = 0; bal <= n; ++bal) {
                if (dp[bal] == INF) continue;

                // Option 1: make it '('
                int nb = bal + 1;
                if (nb <= n) {
                    nextDP[nb] = min(nextDP[nb], dp[bal] + costOpen[i]);
                }

                // Option 2: make it ')'
                if (bal > 0) {
                    nb = bal - 1;
                    nextDP[nb] = min(nextDP[nb], dp[bal] + costClose[i]);
                }

                // Option 3: delete (empty)
                nb = bal;
                nextDP[nb] = min(nextDP[nb], dp[bal] + costEmpty[i]);
            }
        }

        dp.swap(nextDP);
    }

    long long ans = dp[0];
    if (ans == INF) cout << -1 << '\n';
    else cout << ans << '\n';

    return 0;
}
