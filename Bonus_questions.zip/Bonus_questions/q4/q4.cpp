#include <bits/stdc++.h>
using namespace std;

/*
    q4 – Data structure with:
         1) update(index, value)
         2) queryVariance(L, R) on element frequencies

    For a subarray a[L..R], let the distinct elements have
    frequencies c1, c2, ..., cm.
        len = R - L + 1
        m   = #distinct values
        mean μ = len / m
        variance = (sum(ci^2) / m) - μ^2

    Implementation:
      - We store the array in a vector<int> a.
      - update: O(1)
      - queryVariance: build frequency map in O(length of range),
        compute variance from frequencies.

    Input format:
        n q
        a0 a1 ... a(n-1)
        Then q lines of operations:
          1 idx value    (update)
          2 L R          (queryVariance, inclusive, 0-based)

    Output:
        For each query of type 2, print variance as a double.
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    if (!(cin >> n >> q)) {
        return 0;
    }

    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    cout.setf(ios::fixed);
    cout << setprecision(6); // print variance with 6 decimal places

    while (q--) {
        int type;
        cin >> type;

        if (type == 1) {
            // update(index, value)
            int idx, value;
            cin >> idx >> value;
            if (idx >= 0 && idx < n) {
                a[idx] = value;
            }
        } else if (type == 2) {
            // queryVariance(L, R)
            int L, R;
            cin >> L >> R;
            if (L < 0) L = 0;
            if (R >= n) R = n - 1;
            if (L > R) {
                cout << 0.0 << "\n";
                continue;
            }

            unordered_map<int, int> freq;
            freq.reserve(R - L + 1);

            for (int i = L; i <= R; ++i) {
                ++freq[a[i]];
            }

            int len = R - L + 1;
            int m = (int)freq.size();

            if (m == 0) {
                cout << 0.0 << "\n";
                continue;
            }

            long long sumSquares = 0;
            for (unordered_map<int,int>::const_iterator it = freq.begin();
                 it != freq.end(); ++it) {
                long long c = it->second;
                sumSquares += c * c;
            }

            double mean = (double)len / (double)m;
            double var = (double)sumSquares / (double)m - mean * mean;

            cout << var << "\n";
        }
    }

    return 0;
}
