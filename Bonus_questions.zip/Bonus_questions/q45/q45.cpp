#include <bits/stdc++.h>
using namespace std;

/*
    Vertical weighted sum of binary tree.

    For each node:
        HD (horizontal distance):
            root = 0
            left child  = hd - 1
            right child = hd + 1
        Level:
            root = 1
            children = parent level + 1

    Weighted vertical sum for a vertical line = sum(value * level).

    Tasks:
        1. Find the vertical line with maximum weighted sum.
        2. Find the deepest node in that vertical line.
        3. Print:
            - max weighted sum
            - path from root to that deepest node

    Input format:
        n
        val left right
        ...
*/

struct Node {
    long long val;
    int left;
    int right;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    if (n == 0) {
        cout << 0 << "\n\n";
        return 0;
    }

    vector<Node> tree(n + 1);
    vector<int> isChild(n + 1, 0);

    for (int i = 1; i <= n; i++) {
        cin >> tree[i].val >> tree[i].left >> tree[i].right;
        if (tree[i].left != 0) isChild[tree[i].left] = 1;
        if (tree[i].right != 0) isChild[tree[i].right] = 1;
    }

    // find root
    int root = 1;
    for (int i = 1; i <= n; i++) {
        if (!isChild[i]) {
            root = i;
            break;
        }
    }

    // vertical sums: hd -> sum
    map<int, long long> vertSum;
    // deepest node: hd -> (depth, nodeIndex)
    map<int, pair<int,int>> deepest;

    vector<int> parent(n + 1, 0);

    // stack contains tuples (node, level, hd)
    stack< tuple<int,int,int> > st;
    st.push(make_tuple(root, 1, 0));

    while (!st.empty()) {
        tuple<int,int,int> tp = st.top();
        st.pop();

        int u    = get<0>(tp);
        int level = get<1>(tp);
        int hd    = get<2>(tp);

        if (u == 0) continue;

        vertSum[hd] += tree[u].val * 1LL * level;

        if (deepest.find(hd) == deepest.end()) {
            deepest[hd] = make_pair(level, u);
        } else {
            pair<int,int> cur = deepest[hd];
            if (level > cur.first || (level == cur.first && u < cur.second)) {
                deepest[hd] = make_pair(level, u);
            }
        }

        if (tree[u].right != 0) {
            parent[tree[u].right] = u;
            st.push(make_tuple(tree[u].right, level + 1, hd + 1));
        }
        if (tree[u].left != 0) {
            parent[tree[u].left] = u;
            st.push(make_tuple(tree[u].left, level + 1, hd - 1));
        }
    }

    long long bestSum = LLONG_MIN;
    int bestHd = 0;

    for (map<int,long long>::iterator it = vertSum.begin(); it != vertSum.end(); ++it) {
        int hd = it->first;
        long long s = it->second;
        if (s > bestSum) {
            bestSum = s;
            bestHd = hd;
        }
    }

    int targetNode = deepest[bestHd].second;

    // build path to root
    vector<long long> path;
    int curr = targetNode;
    while (curr != 0) {
        path.push_back(tree[curr].val);
        curr = parent[curr];
    }
    reverse(path.begin(), path.end());

    cout << bestSum << "\n";
    for (int i = 0; i < (int)path.size(); i++) {
        if (i) cout << " ";
        cout << path[i];
    }
    cout << "\n";

    return 0;
}
