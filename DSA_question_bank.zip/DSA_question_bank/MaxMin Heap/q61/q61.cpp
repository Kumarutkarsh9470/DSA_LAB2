#include <bits/stdc++.h>
using namespace std;

/*
    q61 – Running Median with insert/delete in O(log N)

    Operations:
        1 x   -> insert(x)
        2 x   -> delete(x)  (remove ONE occurrence if present)
        3     -> getMedian()

    Requirements:
        - All operations O(log N)
        - Handle duplicates correctly

    Implementation:
        - Treap (randomized BST) with:
            key  : value
            cnt  : how many times this key appears
            sz   : total elements in subtree (including multiplicities)

        - Median definition:
            * Let n = total count.
            * If n is odd: k = (n + 1) / 2
            * If n is even: k = n / 2  (lower median)
        - If the structure is empty and getMedian is called, we print -1.
*/

struct Node {
    long long key;
    int pr;
    int cnt;   // frequency of this key
    int sz;    // subtree size including duplicates
    Node *l, *r;

    Node(long long k, int p)
        : key(k), pr(p), cnt(1), sz(1), l(nullptr), r(nullptr) {}
};

mt19937 rng((unsigned)chrono::steady_clock::now().time_since_epoch().count());

int getSize(Node *t) {
    return t ? t->sz : 0;
}

void pull(Node *t) {
    if (!t) return;
    t->sz = t->cnt + getSize(t->l) + getSize(t->r);
}

// Rotate right
Node* rotateRight(Node *y) {
    Node *x = y->l;
    Node *beta = x->r;
    x->r = y;
    y->l = beta;
    pull(y);
    pull(x);
    return x;
}

// Rotate left
Node* rotateLeft(Node *x) {
    Node *y = x->r;
    Node *beta = y->l;
    y->l = x;
    x->r = beta;
    pull(x);
    pull(y);
    return y;
}

Node* insertNode(Node *t, long long key) {
    if (!t) {
        return new Node(key, (int)rng());
    }
    if (key == t->key) {
        t->cnt++;
    } else if (key < t->key) {
        t->l = insertNode(t->l, key);
        if (t->l->pr > t->pr) {
            t = rotateRight(t);
        }
    } else {
        t->r = insertNode(t->r, key);
        if (t->r->pr > t->pr) {
            t = rotateLeft(t);
        }
    }
    pull(t);
    return t;
}

Node* eraseNode(Node *t, long long key) {
    if (!t) return nullptr;

    if (key < t->key) {
        t->l = eraseNode(t->l, key);
    } else if (key > t->key) {
        t->r = eraseNode(t->r, key);
    } else {
        // found
        if (t->cnt > 1) {
            t->cnt--;
        } else {
            // remove this node, merge children
            Node *temp;
            if (!t->l) temp = t->r;
            else if (!t->r) temp = t->l;
            else {
                // choose rotation by priority to keep heap property
                if (t->l->pr > t->r->pr) {
                    t = rotateRight(t);
                    t->r = eraseNode(t->r, key);
                    pull(t);
                    return t;
                } else {
                    t = rotateLeft(t);
                    t->l = eraseNode(t->l, key);
                    pull(t);
                    return t;
                }
            }
            delete t;
            return temp;
        }
    }
    pull(t);
    return t;
}

// Find k-th smallest (1-indexed). Assumes 1 <= k <= size.
long long kth(Node *t, int k) {
    if (!t) return -1;
    int leftSize = getSize(t->l);
    if (k <= leftSize) {
        return kth(t->l, k);
    } else if (k <= leftSize + t->cnt) {
        return t->key;
    } else {
        return kth(t->r, k - leftSize - t->cnt);
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    Node *root = nullptr;

    while (Q--) {
        int type;
        cin >> type;

        if (type == 1) {
            long long x;
            cin >> x;
            root = insertNode(root, x);
        } else if (type == 2) {
            long long x;
            cin >> x;
            root = eraseNode(root, x);
        } else if (type == 3) {
            int n = getSize(root);
            if (n == 0) {
                cout << -1 << "\n";
            } else {
                int k;
                if (n % 2 == 1) k = (n + 1) / 2;
                else k = n / 2; // lower median
                cout << kth(root, k) << "\n";
            }
        }
    }

    return 0;
}
