#include <bits/stdc++.h>
using namespace std;

/*
    q60.cpp

    Serialize a BST so that deserializing reproduces the exact same
    tree shape, using O(N log N) bits of storage.

    Idea:
      - For a BST with distinct keys, the preorder traversal uniquely
        determines the entire tree (structure + values), because at each
        node, keys smaller than the root go to the left subtree and
        larger keys to the right subtree.
      - Therefore, we only need to store the values in preorder order.
      - Space: N values, each O(log N) bits  => O(N log N) bits.

    Implementation:
      1. Read the BST as:
            N
            val1 left1 right1
            ...
            valN leftN rightN
         (0 means NULL child, root is node never appearing as child.)
      2. Serialize: collect preorder traversal into a vector<int> "pre".
      3. Deserialize: from that preorder, rebuild the BST using the
         standard "preorder with bounds" reconstruction:
             build(low, high):
                if index == pre.size(): null
                v = pre[index]
                if v < low or v > high: null
                create node(v); index++;
                node->left  = build(low, v-1(or v-ε));
                node->right = build(v+1(or v+ε), high);
      4. Output:
            Line 1: N
            Line 2: preorder serialization (space-separated)
            Line 3: inorder traversal of the reconstructed tree

    Note: For simplicity, we treat values as long long and use
          numeric limits as bounds.
*/

struct Node {
    long long val;
    Node *left, *right;
    Node(long long v = 0) : val(v), left(NULL), right(NULL) {}
};

// Build pointer-based tree from array description
Node* buildTree(int n,
                const vector<long long> &val,
                const vector<int> &L,
                const vector<int> &R) {
    if (n == 0) return NULL;
    vector<Node*> nodes(n + 1, NULL);
    for (int i = 1; i <= n; ++i)
        nodes[i] = new Node(val[i]);

    vector<int> isChild(n + 1, 0);
    for (int i = 1; i <= n; ++i) {
        if (L[i] != 0) {
            nodes[i]->left = nodes[L[i]];
            isChild[L[i]] = 1;
        }
        if (R[i] != 0) {
            nodes[i]->right = nodes[R[i]];
            isChild[R[i]] = 1;
        }
    }
    int rootIdx = 1;
    for (int i = 1; i <= n; ++i)
        if (!isChild[i]) { rootIdx = i; break; }

    return nodes[rootIdx];
}

// Preorder traversal (for serialization)
void preorder(Node* root, vector<long long> &out) {
    if (!root) return;
    out.push_back(root->val);
    preorder(root->left, out);
    preorder(root->right, out);
}

// Inorder traversal (for verification output)
void inorder(Node* root, vector<long long> &out) {
    if (!root) return;
    inorder(root->left, out);
    out.push_back(root->val);
    inorder(root->right, out);
}

// Deserialize from preorder using bounds
Node* buildFromPre(const vector<long long> &pre,
                   int &idx,
                   long long low,
                   long long high) {
    if (idx >= (int)pre.size()) return NULL;
    long long v = pre[idx];
    if (v < low || v > high) return NULL;

    Node* root = new Node(v);
    ++idx;
    // left subtree: (low, v)
    root->left  = buildFromPre(pre, idx, low, v - 1LL);
    // right subtree: (v, high)
    root->right = buildFromPre(pre, idx, v + 1LL, high);
    return root;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;

    if (N == 0) {
        cout << 0 << "\n\n\n";
        return 0;
    }

    vector<long long> val(N + 1);
    vector<int> L(N + 1), R(N + 1);

    for (int i = 1; i <= N; ++i) {
        cin >> val[i] >> L[i] >> R[i];
    }

    // Build original BST
    Node* root = buildTree(N, val, L, R);

    // --- Serialize: preorder sequence ---
    vector<long long> pre;
    pre.reserve(N);
    preorder(root, pre);

    // --- Deserialize from preorder sequence ---
    int idx = 0;
    Node* newRoot = buildFromPre(pre, idx,
                                 numeric_limits<long long>::min(),
                                 numeric_limits<long long>::max());

    // --- Inorder of reconstructed tree for verification ---
    vector<long long> in;
    in.reserve(N);
    inorder(newRoot, in);

    // Output
    cout << N << "\n";
    // serialized preorder
    for (int i = 0; i < (int)pre.size(); ++i) {
        if (i) cout << ' ';
        cout << pre[i];
    }
    cout << "\n";
    // inorder of reconstructed BST
    for (int i = 0; i < (int)in.size(); ++i) {
        if (i) cout << ' ';
        cout << in[i];
    }
    cout << "\n";

    return 0;
}
