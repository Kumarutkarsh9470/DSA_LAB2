#include <bits/stdc++.h>
using namespace std;

/*
    Possible Celebrity Finder with Uncertain Knowledge

    Input:
        N
        N lines, each a string of length N, containing:
           '1' = i definitely knows j
           '0' = i definitely does NOT know j
           '?' = unknown / either

    Output:
        First line  : number of possible celebrities C
        Second line : indices (0-based) of all possible celebrities,
                      space-separated (if C > 0).

    A person c is a possible celebrity iff:
      1) For all j != c, M[c][j] != '1'
         (celebrity must not *necessarily* know anyone).
      2) For all j != c, M[j][c] != '0'
         (no one must be known to definitely not know c).

    If these hold, we can assign all '?' around c to satisfy the
    classical celebrity conditions, so c is feasible.
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;

    vector<string> M(N);
    for (int i = 0; i < N; ++i) {
        cin >> M[i];
    }

    vector<bool> isPossible(N, false);
    vector<bool> checked(N, false);

    // Stack-based traversal of all people
    stack<int> st;
    for (int i = 0; i < N; ++i) st.push(i);

    while (!st.empty()) {
        int c = st.top();
        st.pop();

        if (checked[c]) continue;   // already processed
        checked[c] = true;

        bool ok = true;
        for (int j = 0; j < N && ok; ++j) {
            if (j == c) continue;

            char cj = M[c][j];  // c -> j
            char jc = M[j][c];  // j -> c

            // Celebrity must know nobody:
            if (cj == '1') {
                ok = false;
                break;
            }
            // Everyone must know the celebrity:
            if (jc == '0') {
                ok = false;
                break;
            }
        }

        if (ok) isPossible[c] = true;
    }

    // Collect and print results
    vector<int> celebs;
    for (int i = 0; i < N; ++i)
        if (isPossible[i]) celebs.push_back(i);

    cout << celebs.size() << "\n";
    if (!celebs.empty()) {
        for (size_t k = 0; k < celebs.size(); ++k) {
            if (k) cout << ' ';
            cout << celebs[k];
        }
        cout << "\n";
    }

    return 0;
}
