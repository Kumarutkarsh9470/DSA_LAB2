#include <bits/stdc++.h>
using namespace std;

/*
    Monotonic-Stack-like structure with range add, all in O(log N).

    We keep elements in an array as a stack (1-based indices).
    To support addRange(L, R, val) in O(log N) we use a Fenwick tree
    (Binary Indexed Tree) that stores *increments*; the actual value at
    index i is:

        value[i] = base[i] + fenwick.prefixSum(i)

    Operations supported (all O(log N)):

        push x          : push value x on top
        pop             : pop top (ignored if empty)
        add L R val     : add val to all indices in [L, R] of the current
                          stack (1-based from bottom)
        top             : print top value or "EMPTY"
        get i           : print value at index i (1-based) or "INVALID"
        size            : print current size

    Input format (for testing / judging):

        Q                   // number of operations
        then Q lines, each is one of:

        push x
        pop
        add L R val
        top
        get i
        size

    Only commands that query something (top / get / size) produce output.
*/

struct Fenwick {
    int n;
    vector<long long> bit;

    Fenwick(int n_ = 0) { init(n_); }

    void init(int n_) {
        n = n_;
        bit.assign(n + 1, 0);
    }

    void add(int idx, long long delta) {
        for (int i = idx; i <= n; i += i & -i)
            bit[i] += delta;
    }

    long long sumPrefix(int idx) const {
        long long res = 0;
        for (int i = idx; i > 0; i -= i & -i)
            res += bit[i];
        return res;
    }

    // range add [l, r]
    void rangeAdd(int l, int r, long long val) {
        if (l > r) return;
        add(l, val);
        if (r + 1 <= n) add(r + 1, -val);
    }
};

class RangeAddStack {
    vector<long long> base;  // base values, length = capacity
    Fenwick fw;
    int topIndex;            // 0 means empty

public:
    explicit RangeAddStack(int capacity)
        : base(capacity + 2, 0), fw(capacity + 2), topIndex(0) {}

    int size() const { return topIndex; }
    bool empty() const { return topIndex == 0; }

    // push value x
    void push(long long x) {
        ++topIndex;
        long long inc = fw.sumPrefix(topIndex);
        base[topIndex] = x - inc;  // so that real value becomes x
    }

    // pop top (if any)
    void pop() {
        if (topIndex > 0) topIndex--;
    }

    // range add [L, R] (1-based indices from bottom of stack)
    void addRange(int L, int R, long long val) {
        if (topIndex == 0) return;
        L = max(L, 1);
        R = min(R, topIndex);
        if (L > R) return;
        fw.rangeAdd(L, R, val);
    }

    // get actual value at index idx (1-based)
    long long get(int idx) const {
        long long inc = fw.sumPrefix(idx);
        return base[idx] + inc;
    }

    // get top value (stack must be non-empty)
    long long top() const {
        return get(topIndex);
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    // Max stack size cannot exceed number of push operations,
    // which is at most Q; so we use Q as capacity.
    RangeAddStack st(Q);

    for (int qi = 0; qi < Q; ++qi) {
        string op;
        cin >> op;

        if (op == "push") {
            long long x;
            cin >> x;
            st.push(x);
        } else if (op == "pop") {
            st.pop();
        } else if (op == "add") {
            int L, R;
            long long v;
            cin >> L >> R >> v;
            st.addRange(L, R, v);
        } else if (op == "top") {
            if (st.empty()) {
                cout << "EMPTY\n";
            } else {
                cout << st.top() << "\n";
            }
        } else if (op == "get") {
            int idx;
            cin >> idx;
            if (idx < 1 || idx > st.size()) {
                cout << "INVALID\n";
            } else {
                cout << st.get(idx) << "\n";
            }
        } else if (op == "size") {
            cout << st.size() << "\n";
        }
    }

    return 0;
}
