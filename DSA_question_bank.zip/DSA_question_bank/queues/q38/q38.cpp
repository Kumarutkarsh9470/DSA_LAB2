#include <bits/stdc++.h>
using namespace std;

// Rotate queue left by d positions (front moves to back d times)
void rotateLeft(queue<int> &q, int d) {
    int n = (int)q.size();
    if (n == 0) return;
    d %= n;
    for (int i = 0; i < d; ++i) {
        int x = q.front(); q.pop();
        q.push(x);
    }
}

// Reverse the first k elements of the queue (standard trick with a stack)
void reverseFirstK(queue<int> &q, int k) {
    int n = (int)q.size();
    if (k <= 0 || k > n) return;

    stack<int> st;

    // Step 1: take first k into stack
    for (int i = 0; i < k; ++i) {
        st.push(q.front());
        q.pop();
    }

    // Step 2: push them back (reversed)
    while (!st.empty()) {
        q.push(st.top());
        st.pop();
    }

    // Step 3: move remaining (n-k) to back to restore their order
    for (int i = 0; i < n - k; ++i) {
        q.push(q.front());
        q.pop();
    }
}

// Reverse the last k elements of the queue, keeping others in order.
void reverseLastK(queue<int> &q, int k) {
    int n = (int)q.size();
    if (k <= 0 || k > n) return;

    // Idea:
    //   Q = [F (size n-k), L (size k)]
    // We want [F, reverse(L)].
    //
    //   1) rotateLeft(n-k)   -> [L, F]
    //   2) reverseFirstK(k)  -> [reverse(L), F]
    //   3) rotateLeft(k)     -> [F, reverse(L)]

    rotateLeft(q, n - k);
    reverseFirstK(q, k);
    rotateLeft(q, k);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    if (!(cin >> n >> k)) return 0;

    queue<int> q;
    for (int i = 0; i < n; ++i) {
        int x; cin >> x;
        q.push(x);
    }

    if (n == 0) return 0;
    k %= n; // safe if k > n

    // 1) Reverse first K elements
    reverseFirstK(q, k);

    // 2) Rotate entire queue right by K positions
    //    Right-rotation by K == left-rotation by (n-K).
    rotateLeft(q, n - k);

    // 3) Reverse last K elements
    reverseLastK(q, k);

    // Output final queue
    bool first = true;
    while (!q.empty()) {
        if (!first) cout << ' ';
        cout << q.front();
        q.pop();
        first = false;
    }
    cout << '\n';

    return 0;
}
