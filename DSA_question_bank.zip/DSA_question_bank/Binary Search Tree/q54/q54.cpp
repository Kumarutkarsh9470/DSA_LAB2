#include <bits/stdc++.h>
using namespace std;

struct Node {
    long long key;
    int pr;
    long long sum;   // subtree sum
    Node *l, *r;

    Node(long long k) : key(k), pr(rand()), sum(k), l(nullptr), r(nullptr) {}
};

long long getSum(Node *t) {
    return t ? t->sum : 0;
}

void pull(Node *t) {
    if (!t) return;
    t->sum = t->key + getSum(t->l) + getSum(t->r);
}

// clone only this node (children pointers reused)
Node* cloneNode(Node *t) {
    if (!t) return nullptr;
    Node *n = new Node(*t);   // memberwise copy
    return n;
}

// Persistent split: keys < key go to 'a', others to 'b'
void split(Node *t, long long key, Node* &a, Node* &b) {
    if (!t) {
        a = b = nullptr;
        return;
    }
    if (key <= t->key) {
        Node *newT = cloneNode(t);
        split(newT->l, key, a, newT->l);
        pull(newT);
        b = newT;
    } else {
        Node *newT = cloneNode(t);
        split(newT->r, key, newT->r, b);
        pull(newT);
        a = newT;
    }
}

// Persistent merge: all keys in a < all keys in b
Node* merge(Node *a, Node *b) {
    if (!a || !b) return a ? a : b;
    if (a->pr > b->pr) {
        Node *newA = cloneNode(a);
        newA->r = merge(newA->r, b);
        pull(newA);
        return newA;
    } else {
        Node *newB = cloneNode(b);
        newB->l = merge(a, newB->l);
        pull(newB);
        return newB;
    }
}

// Insert key, return new root
Node* insertKey(Node *root, long long key) {
    Node *a, *b;
    split(root, key, a, b);            // a: < key, b: >= key
    Node *node = new Node(key);
    Node *ab = merge(a, node);
    Node *res = merge(ab, b);
    return res;
}

// Delete ONE occurrence of key, return new root
Node* deleteKey(Node *root, long long key) {
    Node *a, *b, *c;
    split(root, key, a, b);            // a: < key, b: >= key
    split(b, key + 1, b, c);           // b: [key, key], c: > key

    if (b) {
        // Remove root of b and merge its children
        Node *merged = merge(b->l, b->r);
        delete b;
        b = merged;
    }

    Node *ac = merge(a, b);
    Node *res = merge(ac, c);
    return res;
}

// Prefix sum: sum of keys <= x
long long prefixSum(Node *t, long long x) {
    if (!t) return 0;
    if (t->key > x) {
        return prefixSum(t->l, x);
    } else {
        long long leftSum = getSum(t->l);
        return leftSum + t->key + prefixSum(t->r, x);
    }
}

// Range sum [L, R]
long long rangeSum(Node *root, long long L, long long R) {
    if (L > R) return 0;
    long long sr = prefixSum(root, R);
    long long sl = prefixSum(root, L - 1);
    return sr - sl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    srand((unsigned)time(nullptr));

    int Q;
    if (!(cin >> Q)) return 0;

    vector<Node*> versions;
    Node *root = nullptr;
    versions.push_back(root);       // version 0: empty tree
    int ops_done = 0;

    while (Q--) {
        int type;
        cin >> type;

        root = versions[ops_done];  // current root before this operation

        if (type == 1) {            // insert
            long long x;
            cin >> x;
            root = insertKey(root, x);
        } else if (type == 2) {     // delete
            long long x;
            cin >> x;
            root = deleteKey(root, x);
        } else if (type == 3) {     // rangeSum
            long long L, R;
            cin >> L >> R;
            long long ans = rangeSum(root, L, R);
            cout << ans << "\n";
            // root unchanged
        } else if (type == 4) {     // rollback
            int T;
            cin >> T;
            int target = ops_done - T;
            if (target < 0) target = 0;
            root = versions[target];
        }

        ops_done++;
        versions.push_back(root);   // store version after this operation
    }

    return 0;
}
