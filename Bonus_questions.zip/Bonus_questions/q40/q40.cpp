#include <bits/stdc++.h>
using namespace std;

/*
    Deque with extra operations in O(log N):

        - pushFront(x)
        - pushBack(x)
        - popFront()
        - popBack()
        - rangeSum(L, R)   // 1-based indices from front
        - rangeMax(L, R)
        - reverse(L, R)
        - size()

    Implementation: implicit treap.

    Input format
    ------------
        Q
        then Q lines, each is one of:

        PUSHFRONT x
        PUSHBACK x
        POPFRONT
        POPBACK
        RANGESUM L R
        RANGEMAX L R
        REVERSE L R
        SIZE

    Output
    ------
        POPFRONT / POPBACK:
            value  (or "EMPTY" if deque is empty)

        RANGESUM:
            sum of elements in [L, R]

        RANGEMAX:
            maximum element in [L, R]

        SIZE:
            current number of elements

        REVERSE:
            no output
*/

struct Node {
    int val;
    long long sum;
    int mx;
    int prio;
    int sz;
    bool rev;
    Node *l, *r;

    Node(int v)
        : val(v), sum(v), mx(v),
          prio(rand()), sz(1), rev(false),
          l(nullptr), r(nullptr) {}
};

int getSize(Node* t) { return t ? t->sz : 0; }
long long getSum(Node* t) { return t ? t->sum : 0LL; }
int getMax(Node* t) { return t ? t->mx : INT_MIN; }

void push(Node* t) {
    if (t && t->rev) {
        t->rev = false;
        swap(t->l, t->r);
        if (t->l) t->l->rev ^= 1;
        if (t->r) t->r->rev ^= 1;
    }
}

void pull(Node* t) {
    if (!t) return;
    push(t->l);
    push(t->r);
    t->sz  = 1 + getSize(t->l) + getSize(t->r);
    t->sum = t->val + getSum(t->l) + getSum(t->r);
    t->mx  = max(t->val, max(getMax(t->l), getMax(t->r)));
}

// split by position: first 'k' elements -> a, rest -> b (0-based count)
void split(Node* t, Node*& a, Node*& b, int k) {
    if (!t) { a = b = nullptr; return; }
    push(t);
    int leftSize = getSize(t->l);
    if (k <= leftSize) {
        split(t->l, a, t->l, k);
        pull(t);
        b = t;
    } else {
        split(t->r, t->r, b, k - leftSize - 1);
        pull(t);
        a = t;
    }
}

Node* merge(Node* a, Node* b) {
    if (!a || !b) return a ? a : b;
    if (a->prio > b->prio) {
        push(a);
        a->r = merge(a->r, b);
        pull(a);
        return a;
    } else {
        push(b);
        b->l = merge(a, b->l);
        pull(b);
        return b;
    }
}

// insert value v at position pos (0-based)
void insertAt(Node*& root, int pos, int v) {
    Node *t1, *t2;
    split(root, t1, t2, pos);
    Node* n = new Node(v);
    root = merge(merge(t1, n), t2);
}

// erase node at position pos (0-based), return its value via outVal
bool eraseAt(Node*& root, int pos, int &outVal) {
    if (!root || pos < 0 || pos >= getSize(root)) return false;
    Node *t1, *t2, *t3;
    split(root, t1, t2, pos);
    split(t2, t2, t3, 1);  // t2 is single node
    if (!t2) { root = merge(t1, t3); return false; }
    outVal = t2->val;
    delete t2;
    root = merge(t1, t3);
    return true;
}

// apply reverse on [L, R] (1-based inclusive)
void rangeReverse(Node*& root, int L, int R) {
    if (L > R) swap(L, R);
    Node *t1, *t2, *t3;
    split(root, t1, t2, L - 1);
    split(t2, t2, t3, R - L + 1);
    if (t2) t2->rev ^= 1;
    root = merge(merge(t1, t2), t3);
}

// query sum on [L, R]
long long rangeSum(Node*& root, int L, int R) {
    if (L > R) swap(L, R);
    Node *t1, *t2, *t3;
    split(root, t1, t2, L - 1);
    split(t2, t2, t3, R - L + 1);
    long long ans = getSum(t2);
    root = merge(merge(t1, t2), t3);
    return ans;
}

// query max on [L, R]
int rangeMax(Node*& root, int L, int R) {
    if (L > R) swap(L, R);
    Node *t1, *t2, *t3;
    split(root, t1, t2, L - 1);
    split(t2, t2, t3, R - L + 1);
    int ans = getMax(t2);
    root = merge(merge(t1, t2), t3);
    return ans;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    srand(712367);

    int Q;
    if (!(cin >> Q)) return 0;

    Node* root = nullptr;

    while (Q--) {
        string op;
        cin >> op;

        if (op == "PUSHFRONT") {
            int x; cin >> x;
            insertAt(root, 0, x);
        } else if (op == "PUSHBACK") {
            int x; cin >> x;
            insertAt(root, getSize(root), x);
        } else if (op == "POPFRONT") {
            if (getSize(root) == 0) {
                cout << "EMPTY\n";
            } else {
                int v;
                eraseAt(root, 0, v);
                cout << v << "\n";
            }
        } else if (op == "POPBACK") {
            int sz = getSize(root);
            if (sz == 0) {
                cout << "EMPTY\n";
            } else {
                int v;
                eraseAt(root, sz - 1, v);
                cout << v << "\n";
            }
        } else if (op == "RANGESUM") {
            int L, R;
            cin >> L >> R;
            if (getSize(root) == 0) {
                cout << 0 << "\n";
            } else {
                cout << rangeSum(root, L, R) << "\n";
            }
        } else if (op == "RANGEMAX") {
            int L, R;
            cin >> L >> R;
            if (getSize(root) == 0) {
                cout << "EMPTY\n";
            } else {
                cout << rangeMax(root, L, R) << "\n";
            }
        } else if (op == "REVERSE") {
            int L, R;
            cin >> L >> R;
            if (getSize(root) > 0) {
                rangeReverse(root, L, R);
            }
        } else if (op == "SIZE") {
            cout << getSize(root) << "\n";
        }
    }

    return 0;
}
