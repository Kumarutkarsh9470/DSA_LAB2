#include <bits/stdc++.h>
using namespace std;

/*
    q81 – Time-Dependent Dijkstra with Linear Edge Weights

    Edge weight of e = (u -> v) when departing at time t:
        w_e(t) = a_e * t + b_e

    If we arrive at node u at time T and immediately take edge e,
    arrival at v is:
        T' = T + w_e(T) = (1 + a_e) * T + b_e

    We assume a_e >= 0 so waiting is never beneficial, and a
    Dijkstra-style label-setting algorithm is valid.

    Input (directed graph):
        N M
        u v a b   (M lines, 0-based indices)
        ...
        S T       (source, target)

    Output:
        Earliest arrival time from S to T starting at time 0,
        or -1 if unreachable.
*/

struct Edge {
    int to;
    long long a, b;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int N, M;
    if (!(cin >> N >> M)) {
        return 0;
    }

    vector<vector<Edge> > g(N);
    for (int i = 0; i < M; ++i) {
        int u, v;
        long long a, b;
        cin >> u >> v >> a >> b;
        if (u < 0 || u >= N || v < 0 || v >= N) continue;
        g[u].push_back((Edge){v, a, b});
    }

    int S, T;
    cin >> S >> T;
    if (S < 0 || S >= N || T < 0 || T >= N) {
        cout << -1 << "\n";
        return 0;
    }

    const long long INF = (1LL << 62);
    vector<long long> dist(N, INF);
    dist[S] = 0;

    typedef pair<long long,int> State; // (time, node)
    priority_queue<State, vector<State>, greater<State> > pq;
    pq.push(State(0, S));

    while (!pq.empty()) {
        State cur = pq.top();
        pq.pop();
        long long t = cur.first;
        int u = cur.second;

        if (t != dist[u]) continue;      // stale entry
        if (u == T) break;               // already at best time for T

        for (size_t ei = 0; ei < g[u].size(); ++ei) {
            const Edge &e = g[u][ei];
            long long curT = t;

            // simple overflow guard (optional)
            if (e.a != 0) {
                long long absA1 = (e.a >= 0 ? e.a + 1 : -(e.a + 1));
                long long limit = (INF - (e.b >= 0 ? e.b : -e.b)) / max(1LL, absA1);
                if (curT > limit) continue;
            }

            long long travel = e.a * curT + e.b;
            if (travel < 0) continue; // ignore negative travel

            long long newT = curT + travel;
            if (newT < dist[e.to]) {
                dist[e.to] = newT;
                pq.push(State(newT, e.to));
            }
        }
    }

    if (dist[T] == INF) {
        cout << -1 << "\n";
    } else {
        cout << dist[T] << "\n";
    }

    return 0;
}
