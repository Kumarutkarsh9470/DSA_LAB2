#include <bits/stdc++.h>
using namespace std;

/*
    Problem interpretation

    - We are given a sorted singly linked list of N keys.
    - We must construct a deterministic skip list with an *optimal* layer
      distribution so that searching is O(log N) in the worst case.
    - We must output:
          * the number of layers
          * for each layer, which nodes belong to that layer.

    Deterministic optimal layout (used here)

    Let N be the number of elements.

        L = floor(log2(N)) + 1        // number of layers

    Index the nodes in the original list from 1 to N.

    We construct levels 0..L-1 (0 = bottom level, L-1 = top level):

        - Level 0: all nodes 1..N
        - Level 1: nodes with index multiple of 2      (2,4,6,...)
        - Level 2: nodes with index multiple of 4      (4,8,12,...)
        - ...
        - Level k: nodes with index multiple of 2^k

    This layout guarantees that between two consecutive towers in level k
    there are at most 2^k nodes, giving O(log N) search time.

    Input format (assumed):

        N
        v1 v2 ... vN          // values in sorted order

    Output:

        L
        For each level from TOP to BOTTOM:
           cnt  val1 val2 ... val_cnt

        where cnt is the number of nodes in that level and vali are their
        values (in increasing index order).
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;
    if (N <= 0) {
        cout << 0 << "\n";
        return 0;
    }

    vector<long long> a(N + 1); // 1-based
    for (int i = 1; i <= N; ++i) cin >> a[i];

    // number of layers L = floor(log2 N) + 1
    int L = 1;
    int tmp = N;
    while (tmp > 1) {
        tmp >>= 1;
        ++L;
    }

    cout << L << "\n";

    // For each level from top (L-1) to bottom (0), collect nodes whose
    // index is multiple of 2^level.
    for (int level = L - 1; level >= 0; --level) {
        int step = 1 << level;
        vector<long long> vals;

        for (int idx = step; idx <= N; idx += step) {
            vals.push_back(a[idx]);
        }

        cout << vals.size();
        for (auto v : vals) cout << ' ' << v;
        cout << "\n";
    }

    return 0;
}
