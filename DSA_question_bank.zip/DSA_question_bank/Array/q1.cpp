/* 
his problem requires breakage into multiple parts :
1. Separate each layer from the original matrix 
2. Rotate each layer individually by R times, since R can be larger than number of elements in the layer, we will rotate R%k times (k is length of a layer).
3. Reformulate the matrix by placing each layer back to its original position after rotation.
*/

#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> coord; // Defining a new type to represent each coordinate 
int M, N, R; // M: number of rows, N: number of columns, R: number of rotations

void addLayer(vector<coord> &layer, int r, int c, int len, int rAdd, int cAdd) {
    while(len-- > 0) {
        layer.push_back(make_pair(r, c));
        r += rAdd;
        c += cAdd;
    }
}
vector<vector<int>> rotate(vector<vector<int>> matrix) {
    vector<vector<int>> ret(M, vector<int>(N));
 int nLayers = min(M, N)/2;   
 int m = M, n = N;
    for(int i = 0; i < nLayers; i++) {
        vector<coord> layer;
        int r = i, c = i;
        addLayer(layer, r, c, n-1, +0, +1);
    
 r = layer.back().first;
c = layer.back().second+1;
addLayer(layer, r, c, m-1, +1, +0);

    r = layer.back().first+1;
        c = layer.back().second;
        addLayer(layer, r, c, n-1, 0, -1);
        
        r = layer.back().first;
    c = layer.back().second-1;
    addLayer(layer, r, c, m-1, -1, 0);
        
        int size = layer.size();
        for(int j = 0; j < size; j++) {
     int r1 = layer[j].first, c1 = layer[j].second;
  int r2 = layer[((j+R)%size+size)%size].first, c2 = layer[((j+R)%size+size)%size].second;
        ret[r1][c1] = matrix[r2][c2];
        }
        
        m -= 2;
        n -= 2;
    }

    return ret;
}
int main()
{
cin >> M >> N >> R;
vector < vector<int> > matrix(M, vector<int>(N));
    
for(int i = 0; i < M; i++) {
    for(int j = 0; j < N; j++) {
        cin >> matrix[i][j];
        }
    }       
vector<vector<int> > ans = rotate(matrix);
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            cout << ans[i][j] << " ";
        }
        cout << endl;
    }   
    return 0;
}