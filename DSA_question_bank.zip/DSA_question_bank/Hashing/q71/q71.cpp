#include <bits/stdc++.h>
using namespace std;

/*
    q71 – Dynamic Perfect Hashing

    --------------------------------------------
    High-level design (Fredman–Komlós–Szemerédi style)
    --------------------------------------------

    1. PRIMARY TABLE
       - Size M  ~  Θ(n) (we keep M ≈ 2n).
       - Hash h1(key) chooses a bucket in [0, M-1].
       - We use a universal hash family:
           h1(x) = (A * f(x) + B) mod P mod M,
           where P is a large prime, A,B random.

    2. SECONDARY TABLES (one per bucket)
       - For bucket i with n_i keys:
           * Allocate table of size s_i = n_i^2 (or 1 if n_i=1).
           * Pick random hash h2_i from universal family.
           * Place each key into slot h2_i(key).
           * If any collision occurs, throw away h2_i and the table
             and retry with new random parameters.
       - Expected number of retries is constant; expected build
         time per bucket is O(n_i).

       - Lookups are then O(1) worst case:
           * compute i = h1(key)
           * compute j = h2_i(key) in the secondary table
           * test single cell.

    3. DYNAMIC UPDATES
       - We keep total number of keys = n.
       - We maintain invariants:
           M >= max(2, 2n).
       - On insert/delete:
           * Reassign key to its bucket using h1.
           * Update that bucket's key list and rebuild its secondary
             table from scratch.
           * If n grows so that load factor exceeds 1/2
             (i.e. n > M/2) or a single bucket becomes "too big"
             (n_i^2 > 4M), we rebuild the *whole* structure with
             a larger M and fresh hash functions.

       Expected cost:
         - Rebuilding one bucket i costs O(n_i^2) time/space.
         - Random primary hashing ensures
             E[ sum_i n_i^2 ] = O(n),
           hence total expected work of all bucket rebuilds is O(n).
         - Occasional full rehash is O(n) but happens only after
           Ω(n) successful updates.
         => insert/delete have **expected amortized O(1)** time.

    4. Interface (this program):

        Q
        Then Q queries, each one of:
          1 x   -> insert x
          2 x   -> erase x
          3 x   -> contains x ? 1 : 0   (we print the answer)

       Keys are 64-bit signed integers.
*/

class DynamicPerfectHash {
    // Big prime for hashing
    static const unsigned long long P = 1000000007ULL;
    static const long long EMPTY = (long long)0x7fffffffffffffffLL;

    struct Secondary {
        // Keys currently in this bucket (for rebuild)
        vector<long long> keys;
        // Actual secondary table cells
        vector<long long> table;
        // Hash parameters
        unsigned long long a, b;
        // size of table (table.size())
    };

    // Primary hash parameters
    unsigned long long A1, B1;
    size_t M;                   // number of primary buckets
    size_t n;                   // total keys

    vector<Secondary> buckets;
    mt19937_64 rng;

public:
    DynamicPerfectHash(size_t initialCapacity = 4)
        : M(initialCapacity),
          n(0),
          buckets(initialCapacity),
          rng((uint64_t)chrono::steady_clock::now().time_since_epoch().count())
    {
        initPrimaryHash();
    }

    bool contains(long long x) const {
        if (M == 0) return false;
        size_t bi = primaryHash(x);
        const Secondary &sec = buckets[bi];
        if (sec.keys.empty()) return false;
        if (sec.table.empty()) return false;

        size_t idx = secondaryHash(sec, x);
        if (idx >= sec.table.size()) return false;
        return (sec.table[idx] == x);
    }

    void insert(long long x) {
        if (contains(x)) return;  // no duplicates in set

        ++n;
        ensureCapacity();

        size_t bi = primaryHash(x);
        buckets[bi].keys.push_back(x);

        // Check bucket size; if pathological, rebuild everything
        size_t ni = buckets[bi].keys.size();
        if (ni * ni > 4 * M) {
            rebuildAll(M * 2);
        } else {
            rebuildBucket(bi);
        }
    }

    void erase(long long x) {
        if (!contains(x)) return;

        size_t bi = primaryHash(x);
        Secondary &sec = buckets[bi];

        // Remove from key list
        vector<long long> &ks = sec.keys;
        for (size_t i = 0; i < ks.size(); ++i) {
            if (ks[i] == x) {
                ks[i] = ks.back();
                ks.pop_back();
                break;
            }
        }
        --n;
        rebuildBucket(bi);
    }

private:
    // ----------------- Hash Helpers -----------------

    static inline unsigned long long foldKey(long long x) {
        return (unsigned long long)x ^ 0x8000000000000000ULL;
    }

    void initPrimaryHash() {
        uniform_int_distribution<unsigned long long> dist(1, P - 1);
        A1 = dist(rng);
        B1 = dist(rng);
    }

    void initSecondaryHash(Secondary &sec) {
        uniform_int_distribution<unsigned long long> dist(1, P - 1);
        sec.a = dist(rng);
        sec.b = dist(rng);
    }

    size_t primaryHash(long long x) const {
        if (M == 0) return 0;
        unsigned long long fx = foldKey(x);
        unsigned long long h = (A1 * fx + B1) % P;
        return (size_t)(h % M);
    }

    size_t secondaryHash(const Secondary &sec, long long x) const {
        if (sec.table.empty()) return 0;
        unsigned long long fx = foldKey(x);
        unsigned long long h = (sec.a * fx + sec.b) % P;
        return (size_t)(h % sec.table.size());
    }

    // ----------------- Bucket & Global Rebuilds -----------------

    void rebuildBucket(size_t bi) {
        Secondary &sec = buckets[bi];
        size_t m = sec.keys.size();

        if (m == 0) {
            sec.table.clear();
            return;
        }

        size_t tableSize = m * m;
        if (tableSize == 0) tableSize = 1; // just in case

        // Try random secondary hash parameters until collision-free.
        while (true) {
            initSecondaryHash(sec);
            sec.table.assign(tableSize, EMPTY);
            bool collision = false;

            for (size_t i = 0; i < m; ++i) {
                long long x = sec.keys[i];
                size_t idx = secondaryHash(sec, x);
                if (sec.table[idx] != EMPTY && sec.table[idx] != x) {
                    collision = true;
                    break;
                }
                sec.table[idx] = x;
            }

            if (!collision) break; // success
        }
    }

    void collectAllKeys(vector<long long> &all) const {
        all.clear();
        all.reserve(n);
        for (size_t i = 0; i < M; ++i) {
            const Secondary &sec = buckets[i];
            for (size_t j = 0; j < sec.keys.size(); ++j) {
                all.push_back(sec.keys[j]);
            }
        }
    }

    void rebuildAll(size_t newM) {
        vector<long long> all;
        collectAllKeys(all);

        M = max<size_t>(2, newM);
        buckets.clear();
        buckets.resize(M);
        initPrimaryHash();

        // Distribute keys into new buckets
        for (size_t i = 0; i < all.size(); ++i) {
            long long x = all[i];
            size_t bi = primaryHash(x);
            buckets[bi].keys.push_back(x);
        }

        // Rebuild each bucket
        for (size_t bi = 0; bi < M; ++bi) {
            rebuildBucket(bi);
        }
    }

    void ensureCapacity() {
        if (M == 0) {
            M = 4;
            buckets.assign(M, Secondary());
            initPrimaryHash();
            rebuildAll(M);
            return;
        }
        if (n > M / 2) {
            // load factor > 1/2 ⇒ grow table and rehash all
            rebuildAll(M * 2);
        }
    }
};

// ----------------- Driver -----------------

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    DynamicPerfectHash dph;

    while (Q--) {
        int type;
        long long x;
        cin >> type >> x;
        if (type == 1) {
            dph.insert(x);
        } else if (type == 2) {
            dph.erase(x);
        } else if (type == 3) {
            cout << (dph.contains(x) ? 1 : 0) << "\n";
        }
    }

    return 0;
}
