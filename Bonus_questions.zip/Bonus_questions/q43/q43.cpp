#include <bits/stdc++.h>
using namespace std;

/*
    Problem:
    --------
    Determine whether two binary trees are isomorphic when:

      * Some nodes are wildcards – they can match any value.
      * Trees may be matched with or without swapping the left/right child
        at any pair of corresponding nodes.
      * Count the total number of distinct valid mappings.

    If the trees are not isomorphic, the number of mappings is 0.

    Input format (assumed, 1-based indices):
    ---------------------------------------

        n1
        val1 left1 right1   (for node 1)
        val2 left2 right2   (for node 2)
        ...
        val_n1 left_n1 right_n1

        n2
        val1 left1 right1   (for node 1)
        ...
        val_n2 left_n2 right_n2

    - `vali` is a string (no spaces). The special value "*" means wildcard.
    - `lefti`, `righti` are integer indices of children, 0 meaning NULL.
    - Roots are not given explicitly; we compute them as the unique nodes
      that are never listed as children.

    Output:
    -------

        First line : "YES" or "NO" (whether isomorphic).
        Second line: total number of valid mappings (0 if not isomorphic).

    Approach:
    ---------
    Dynamic programming with memoization over pairs of nodes (u, v).

        ways(u, v) =
          0                                 if labels incompatible
          ways(L1,R1 with L2,R2) +          (no swap)
          ways(L1,R1 with R2,L2)            (swap)

        where ways(NULL, NULL) = 1, and
              ways(NULL, non-NULL) = ways(non-NULL, NULL) = 0.

    Wildcards:
        - If either node's label is "*", it matches anything.
        - Otherwise, labels must be equal.

    Complexity:
        O(n1 * n2) states, O(1) per state with memoization.
*/

struct Node {
    string val;
    int left;
    int right;
};

long long dfs(int u, int v,
              const vector<Node>& T1,
              const vector<Node>& T2,
              vector<vector<long long>>& dp) {
    if (u == 0 && v == 0) return 1;   // both null
    if (u == 0 || v == 0) return 0;   // one null

    long long &res = dp[u][v];
    if (res != -1) return res;

    const Node &a = T1[u];
    const Node &b = T2[v];

    // label compatibility (wildcard "*")
    if (a.val != "*" && b.val != "*" && a.val != b.val) {
        return res = 0;
    }

    long long noSwap =
        dfs(a.left,  T2[v].left,  T1, T2, dp) *
        dfs(a.right, T2[v].right, T1, T2, dp);

    long long withSwap =
        dfs(a.left,  T2[v].right, T1, T2, dp) *
        dfs(a.right, T2[v].left,  T1, T2, dp);

    res = noSwap + withSwap;
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n1;
    if (!(cin >> n1)) return 0;

    vector<Node> T1(n1 + 1);
    vector<int> isChild1(n1 + 1, 0);
    for (int i = 1; i <= n1; ++i) {
        cin >> T1[i].val >> T1[i].left >> T1[i].right;
        if (T1[i].left  != 0) isChild1[T1[i].left]  = 1;
        if (T1[i].right != 0) isChild1[T1[i].right] = 1;
    }
    int root1 = 0;
    for (int i = 1; i <= n1; ++i)
        if (!isChild1[i]) { root1 = i; break; }

    int n2;
    cin >> n2;

    vector<Node> T2(n2 + 1);
    vector<int> isChild2(n2 + 1, 0);
    for (int i = 1; i <= n2; ++i) {
        cin >> T2[i].val >> T2[i].left >> T2[i].right;
        if (T2[i].left  != 0) isChild2[T2[i].left]  = 1;
        if (T2[i].right != 0) isChild2[T2[i].right] = 1;
    }
    int root2 = 0;
    for (int i = 1; i <= n2; ++i)
        if (!isChild2[i]) { root2 = i; break; }

    if (n1 == 0 && n2 == 0) {
        cout << "YES\n0\n";
        return 0;
    }

    // dp[u][v] = number of mappings between subtree rooted at u in T1
    //            and subtree rooted at v in T2; -1 = unknown.
    vector<vector<long long>> dp(n1 + 1, vector<long long>(n2 + 1, -1));

    long long count = dfs(root1, root2, T1, T2, dp);

    if (count > 0) {
        cout << "YES\n" << count << "\n";
    } else {
        cout << "NO\n0\n";
    }

    return 0;
}
