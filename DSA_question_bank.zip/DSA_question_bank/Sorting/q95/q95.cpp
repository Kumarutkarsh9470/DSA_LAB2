#include <bits/stdc++.h>
using namespace std;

/*
    q95 – Radix Sort with configurable base

    Problem recap:
      - Implement helper function:
            extractDigit(number, digitPos, base)
        which returns the digit at digitPos (0 = least significant)
        of `number` when written in the given base.
      - Implement LSD Radix Sort that works with arbitrary base.
      - Use it to sort the array [1024, 45, 789, 23, 456, 12]
        with bases: 2, 10, 16.
      - Count number of passes (digit positions processed) for
        each base and print them.
      - Explain the trade-off between base size and number of passes.
*/

// extractDigit( number, digitPos, base )
// digitPos = 0 for least significant digit.
int extractDigit(int number, int digitPos, int base) {
    for (int i = 0; i < digitPos; ++i) {
        number /= base;
    }
    return number % base;
}

// Return number of digits of `number` when written in `base`.
int countDigits(int number, int base) {
    if (number == 0) return 1;
    int cnt = 0;
    while (number > 0) {
        number /= base;
        ++cnt;
    }
    return cnt;
}

// LSD Radix Sort for non-negative integers in arbitrary base.
void radixSort(vector<int> &arr, int base, int &passes) {
    if (arr.empty()) {
        passes = 0;
        return;
    }

    int maxVal = *max_element(arr.begin(), arr.end());
    passes = countDigits(maxVal, base);

    vector<vector<int> > buckets(base);

    for (int pos = 0; pos < passes; ++pos) {
        // clear buckets
        for (int b = 0; b < base; ++b) buckets[b].clear();

        // distribute into buckets by current digit
        for (size_t i = 0; i < arr.size(); ++i) {
            int d = extractDigit(arr[i], pos, base);
            buckets[d].push_back(arr[i]);
        }

        // collect back in order
        int idx = 0;
        for (int b = 0; b < base; ++b) {
            for (size_t j = 0; j < buckets[b].size(); ++j) {
                arr[idx++] = buckets[b][j];
            }
        }
    }
}

void printArray(const vector<int> &a) {
    cout << "[";
    for (size_t i = 0; i < a.size(); ++i) {
        if (i) cout << ", ";
        cout << a[i];
    }
    cout << "]";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    vector<int> baseArray = {1024, 45, 789, 23, 456, 12};

    int passes2, passes10, passes16;

    vector<int> a2 = baseArray;
    radixSort(a2, 2, passes2);

    vector<int> a10 = baseArray;
    radixSort(a10, 10, passes10);

    vector<int> a16 = baseArray;
    radixSort(a16, 16, passes16);

    cout << "Original array: ";
    printArray(baseArray);
    cout << "\n\n";

    cout << "Base 2 (binary) radix sort:\n";
    cout << "  Sorted array: ";
    printArray(a2);
    cout << "\n";
    cout << "  Number of passes: " << passes2 << "\n\n";

    cout << "Base 10 (decimal) radix sort:\n";
    cout << "  Sorted array: ";
    printArray(a10);
    cout << "\n";
    cout << "  Number of passes: " << passes10 << "\n\n";

    cout << "Base 16 (hexadecimal) radix sort:\n";
    cout << "  Sorted array: ";
    printArray(a16);
    cout << "\n";
    cout << "  Number of passes: " << passes16 << "\n\n";

    // Explanation of tradeoff
    cout << "Explanation:\n";
    cout << "  - Radix Sort processes one digit per pass.\n";
    cout << "  - For a fixed maximum value, using a larger base\n";
    cout << "    reduces the number of digits, so fewer passes are required.\n";
    cout << "    In our example:\n";
    cout << "        base 2  needs " << passes2  << " passes,\n";
    cout << "        base 10 needs " << passes10 << " passes,\n";
    cout << "        base 16 needs " << passes16 << " passes.\n";
    cout << "  - However, each pass with a larger base uses more buckets\n";
    cout << "    (base many) and thus more memory and per-pass overhead.\n";
    cout << "  - Small base: more passes, cheap buckets.\n";
    cout << "    Large base: fewer passes, but each pass is heavier.\n";
    cout << "  - In practice, an intermediate base (like 10 or 256 for bytes)\n";
    cout << "    often gives the best balance between pass count and\n";
    cout << "    bucket-management cost.\n";

    return 0;
}
