#include <bits/stdc++.h>
using namespace std;

/*
    q51 – BST with lockable value ranges

    We implement a BST (Treap) where ranges can be "locked":
      - Any value inside a locked range [low, high] cannot be inserted
        or deleted.
      - Search still works normally.
      - We support:
          1 x          -> insert(x)
          2 x          -> delete(x)
          3 x          -> search(x)         : print 1 if present, else 0
          4 low high   -> lockRange(low, high)
          5 low high   -> unlockRange(low, high)
          6 x          -> canInsert(x?)     : print 1 if allowed, else 0

    Input:
        Q                       (number of operations)
        Q lines with one of the commands above.

    Output:
        For every query type 3 or 6 we print a line with 0/1.
*/

/// ---------- Treap implementation (keys only, unique) ----------
struct Node {
    long long key;
    unsigned pr;
    Node *l, *r;
    Node(long long k, unsigned p) : key(k), pr(p), l(nullptr), r(nullptr) {}
};

mt19937 rng((unsigned)chrono::steady_clock::now().time_since_epoch().count());

int getRand() {
    return (int)rng();
}

void deleteSubtree(Node *t) {
    if (!t) return;
    deleteSubtree(t->l);
    deleteSubtree(t->r);
    delete t;
}

// Merge two treaps a and b, where all keys in a < all keys in b.
Node* merge(Node *a, Node *b) {
    if (!a || !b) return a ? a : b;
    if (a->pr > b->pr) {
        a->r = merge(a->r, b);
        return a;
    } else {
        b->l = merge(a, b->l);
        return b;
    }
}

// Split treap t into a (keys < key) and b (keys >= key).
void split(Node *t, long long key, Node* &a, Node* &b) {
    if (!t) {
        a = b = nullptr;
        return;
    }
    if (key <= t->key) {
        split(t->l, key, a, t->l);
        b = t;
    } else {
        split(t->r, key, t->r, b);
        a = t;
    }
}

bool searchNode(Node *t, long long key) {
    while (t) {
        if (key == t->key) return true;
        if (key < t->key) t = t->l;
        else t = t->r;
    }
    return false;
}

Node* insertNode(Node *root, long long key) {
    if (searchNode(root, key)) return root; // keep unique
    Node *a, *b;
    split(root, key, a, b);
    Node *n = new Node(key, getRand());
    return merge(merge(a, n), b);
}

Node* deleteNode(Node *root, long long key) {
    Node *a, *b, *c;
    split(root, key, a, b);          // a: < key, b: >= key
    split(b, key + 1, b, c);         // b: == key, c: > key
    if (b) {
        // remove node(s) in b (unique -> single node)
        Node *mergedChildren = merge(b->l, b->r);
        delete b;
        b = mergedChildren;
    }
    return merge(merge(a, b), c);
}

/// ---------- Locked range structure (disjoint intervals) ----------
/// We store a set of closed intervals [L, R] with L <= R, disjoint and sorted.

set<pair<long long,long long>> locked;

// Returns true if x lies in any locked interval.
bool isLocked(long long x) {
    auto it = locked.upper_bound({x, LLONG_MAX});
    if (it == locked.begin()) return false;
    --it;
    return it->first <= x && x <= it->second;
}

// Lock range [L, R] (merge with existing overlapping intervals).
void lockRange(long long L, long long R) {
    if (L > R) swap(L, R);
    auto it = locked.lower_bound({L, LLONG_MIN});
    if (it != locked.begin()) {
        auto it2 = it;
        --it2;
        it = it2;
    }

    while (it != locked.end() && it->second < L - 1) ++it;

    long long newL = L, newR = R;
    vector<set<pair<long long,long long>>::iterator> toerase;

    for (; it != locked.end() && it->first <= R + 1; ++it) {
        newL = min(newL, it->first);
        newR = max(newR, it->second);
        toerase.push_back(it);
    }
    for (auto &e : toerase) locked.erase(e);

    locked.insert({newL, newR});
}

// Unlock (remove) range [L, R], possibly splitting existing intervals.
void unlockRange(long long L, long long R) {
    if (L > R) swap(L, R);
    auto it = locked.lower_bound({L+1, LLONG_MIN});
    if (it != locked.begin()) {
        auto it2 = it;
        --it2;
        it = it2;
    }

    vector<pair<long long,long long>> toAdd;
    vector<set<pair<long long,long long>>::iterator> toerase;

    for (; it != locked.end() && it->first <= R; ++it) {
        long long a = it->first;
        long long b = it->second;
        if (b < L) continue;
        if (a > R) break;

        // overlapping [a,b] with [L,R]
        if (L <= a && R >= b) {
            // remove entire [a,b]
        } else if (L > a && R < b) {
            // split into [a, L-1] and [R+1, b]
            if (a <= L-1) toAdd.push_back({a, L-1});
            if (R+1 <= b) toAdd.push_back({R+1, b});
        } else if (L <= a && R < b) {
            // shrink left
            if (R+1 <= b) toAdd.push_back({R+1, b});
        } else if (L > a && R >= b) {
            // shrink right
            if (a <= L-1) toAdd.push_back({a, L-1});
        }
        toerase.push_back(it);
    }
    for (auto &e : toerase) locked.erase(e);
    for (auto &p : toAdd) locked.insert(p);
}

/// ---------- Driver ----------

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    Node *root = nullptr;

    while (Q--) {
        int type;
        cin >> type;

        if (type == 1) {            // insert x
            long long x; cin >> x;
            if (!isLocked(x)) {
                root = insertNode(root, x);
            }
        } else if (type == 2) {     // delete x
            long long x; cin >> x;
            if (!isLocked(x)) {
                root = deleteNode(root, x);
            }
        } else if (type == 3) {     // search x
            long long x; cin >> x;
            cout << (searchNode(root, x) ? 1 : 0) << "\n";
        } else if (type == 4) {     // lockRange(low, high)
            long long low, high;
            cin >> low >> high;
            lockRange(low, high);
        } else if (type == 5) {     // unlockRange(low, high)
            long long low, high;
            cin >> low >> high;
            unlockRange(low, high);
        } else if (type == 6) {     // query if value can be inserted
            long long x; cin >> x;
            cout << (!isLocked(x) ? 1 : 0) << "\n";
        }
    }

    // Optional cleanup (not required for contest-style programs)
    deleteSubtree(root);
    return 0;
}
