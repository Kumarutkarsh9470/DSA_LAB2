#include <iostream>
#include <vector>
#include <unordered_set>
#include <algorithm>
#include <string>

struct Node {
    int id;        // index of the node
    Node* next;    // next pointer
    Node(int _id = 0) : id(_id), next(nullptr) {}
};

/*
 Input format (one possible consistent format):

 N
 next_0 next_1 ... next_{N-1}
 h1 h2

 where:
   - N            : total number of nodes in the combined structure
   - next_i       : index (0..N-1) of the node that node i points to
                    (since lists are circular, every next_i must be valid)
   - h1, h2       : indices (0..N-1) of the heads of the two circular lists

 Example:
   6
   1 2 0 4 5 3
   0 3

   This means:
   - Nodes 0->1->2->0 form one cycle
   - Nodes 3->4->5->3 form another cycle
   - head1 at node 0, head2 at node 3 (disjoint cycles)
*/

void traverse(Node* start, std::unordered_set<Node*>& visited) {
    Node* cur = start;
    while (cur && visited.find(cur) == visited.end()) {
        visited.insert(cur);
        cur = cur->next;
    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int N;
    if (!(std::cin >> N)) {
        std::cerr << "Invalid input\n";
        return 1;
    }

    if (N <= 0) {
        std::cout << 0 << "\nNone\nDISJOINT\n";
        return 0;
    }

    std::vector<int> nxtIdx(N);
    for (int i = 0; i < N; ++i) {
        std::cin >> nxtIdx[i];
        if (nxtIdx[i] < 0 || nxtIdx[i] >= N) {
            std::cerr << "Invalid next index for node " << i << "\n";
            return 1;
        }
    }

    int h1Idx, h2Idx;
    std::cin >> h1Idx >> h2Idx;
    if (h1Idx < 0 || h1Idx >= N || h2Idx < 0 || h2Idx >= N) {
        std::cerr << "Invalid head indices\n";
        return 1;
    }

    // Build nodes
    std::vector<Node*> nodes(N);
    for (int i = 0; i < N; ++i) {
        nodes[i] = new Node(i);
    }
    for (int i = 0; i < N; ++i) {
        nodes[i]->next = nodes[nxtIdx[i]];
    }

    Node* head1 = nodes[h1Idx];
    Node* head2 = nodes[h2Idx];

    // Reachable from head1 and head2
    std::unordered_set<Node*> reach1, reach2;
    traverse(head1, reach1);
    traverse(head2, reach2);

    // Compute intersection nodes (present in both reachable sets)
    std::vector<int> intersection;
    for (Node* node : reach1) {
        if (reach2.find(node) != reach2.end()) {
            intersection.push_back(node->id);
        }
    }
    std::sort(intersection.begin(), intersection.end());

    // Output number and list of intersection points
    std::cout << intersection.size() << "\n";
    if (intersection.empty()) {
        std::cout << "None\n";
    } else {
        for (size_t i = 0; i < intersection.size(); ++i) {
            if (i) std::cout << ' ';
            std::cout << intersection[i];
        }
        std::cout << "\n";
    }

    // Determine a simple topology classification:
    // - DISJOINT            : no common nodes
    // - IDENTICAL_CYCLES    : both lists visit exactly the same set of nodes
    // - ONE_CONTAINS_OTHER  : all nodes of one list are in the other, but not vice versa
    // - FIGURE_8_OR_COMPLEX : they share some, but each has exclusive nodes too
    std::string topology;
    size_t s1 = reach1.size();
    size_t s2 = reach2.size();
    size_t si = intersection.size();

    if (si == 0) {
        topology = "DISJOINT";
    } else if (si == s1 && si == s2) {
        topology = "IDENTICAL_CYCLES";
    } else if ((si == s1 && si < s2) || (si == s2 && si < s1)) {
        topology = "ONE_CONTAINS_OTHER";
    } else {
        topology = "FIGURE_8_OR_COMPLEX";
    }

    std::cout << topology << "\n";

    // Cleanup
    for (Node* node : nodes) {
        delete node;
    }

    return 0;
}
