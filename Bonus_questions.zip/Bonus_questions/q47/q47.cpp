#include <bits/stdc++.h>
using namespace std;

/*
    Extract all diagonals (top-left to bottom-right) of a binary tree.
    For each diagonal, compute the length of its Longest Increasing
    Subsequence (LIS).  Return the diagonal that has the maximum LIS length.

    Diagonal definition used here
    -----------------------------
    - Root is at diagonal 0.
    - Left child  is on diagonal (d + 1).
    - Right child stays on the same diagonal d.

    We traverse the tree in BFS order while tracking diagonal index,
    collecting node values for each diagonal in the order visited.

    Input format (1-based nodes)
    ----------------------------
        n
        val1 left1 right1
        val2 left2 right2
        ...
        valn leftn rightn

        vali  : integer value of node i
        lefti : index of left child  (0 if NULL)
        righti: index of right child (0 if NULL)

        Root is the unique node that is never listed as a child.

    Output
    ------
        Line 1: maximum LIS length among all diagonals
        Line 2: values of the diagonal (in traversal order) that attains
                this maximum (space separated).  If the tree is empty,
                output:
                    0
                    <blank line>
*/

struct Node {
    long long val;
    int left;
    int right;
};

int lisLength(const vector<long long> &a) {
    if (a.empty()) return 0;
    vector<long long> tail;
    tail.reserve(a.size());

    for (size_t i = 0; i < a.size(); ++i) {
        long long x = a[i];
        vector<long long>::iterator it =
            lower_bound(tail.begin(), tail.end(), x);
        if (it == tail.end())
            tail.push_back(x);
        else
            *it = x;
    }
    return (int)tail.size();
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    if (n == 0) {
        cout << 0 << "\n\n";
        return 0;
    }

    vector<Node> tree(n + 1);
    vector<int> isChild(n + 1, 0);

    for (int i = 1; i <= n; ++i) {
        cin >> tree[i].val >> tree[i].left >> tree[i].right;
        if (tree[i].left  != 0) isChild[tree[i].left]  = 1;
        if (tree[i].right != 0) isChild[tree[i].right] = 1;
    }

    // Find root (node that is not a child of anyone)
    int root = 1;
    for (int i = 1; i <= n; ++i) {
        if (!isChild[i]) {
            root = i;
            break;
        }
    }

    // Collect diagonals: diagIndex -> vector of values
    map<int, vector<long long> > diagVals;

    queue< pair<int,int> > q; // (node, diagonal)
    q.push(make_pair(root, 0));

    while (!q.empty()) {
        pair<int,int> cur = q.front();
        q.pop();
        int u  = cur.first;
        int d  = cur.second;
        if (u == 0) continue;

        diagVals[d].push_back(tree[u].val);

        // Left child goes to next diagonal, right stays
        if (tree[u].left  != 0) q.push(make_pair(tree[u].left,  d + 1));
        if (tree[u].right != 0) q.push(make_pair(tree[u].right, d));
    }

    // Find diagonal with maximum LIS length
    int bestDiag = 0;
    int bestLen = -1;

    for (map<int, vector<long long> >::iterator it = diagVals.begin();
         it != diagVals.end(); ++it) {
        int d = it->first;
        const vector<long long> &vals = it->second;
        int len = lisLength(vals);
        if (len > bestLen) {
            bestLen = len;
            bestDiag = d;
        }
    }

    const vector<long long> &best = diagVals[bestDiag];

    cout << bestLen << "\n";
    for (size_t i = 0; i < best.size(); ++i) {
        if (i) cout << ' ';
        cout << best[i];
    }
    cout << "\n";

    return 0;
}
