#include <bits/stdc++.h>
using namespace std;
int zzis_with_diff(int arr[], int n, int D)
{
int las[n][2];
int parent[n][2]; 
for (int i = 0; i < n; i++) {
las[i][0] = las[i][1] = 1;
parent[i][0] = parent[i][1] = -1;
 }
int res = 1;
int best_i = 0;
int best_state = 0; 
for (int i = 1; i < n; i++) {
for (int j = 0; j < i; j++) {
int diff = abs(arr[i] - arr[j]);
 if (diff < D) continue;
if (arr[j] < arr[i] && las[i][0] < las[j][1] + 1) {
las[i][0] = las[j][1] + 1;
parent[i][0] = j;
}
if (arr[j] > arr[i] && las[i][1] < las[j][0] + 1) {
las[i][1] = las[j][0] + 1;
parent[i][1] = j;
}
}
if (res < las[i][0]) {
res = las[i][0];
best_i = i;
best_state = 0;
}
if (res < las[i][1]) {
res = las[i][1];
best_i = i;
best_state = 1;
}
}
vector<int> indices;
int i = best_i;
int state = best_state;
while (i != -1) {
indices.push_back(i);
int prev_i = parent[i][state];
state = 1 - state;
 i = prev_i;
}
reverse(indices.begin(), indices.end());
cout << "Length = " << res << "\nSubsequence: ";
for (int idx : indices) {
cout << arr[idx] << " ";
}
cout << "\n";
return res;
}
int main()
{
int arr[] = {10, 22, 9, 33, 49, 50, 31, 60};
int n = sizeof(arr) / sizeof(arr[0]);
int D = 5;
zzis_with_diff(arr, n, D);

    return 0;
}
