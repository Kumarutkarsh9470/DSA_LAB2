#include <bits/stdc++.h>
using namespace std;

/*
   Problem:
   --------
   A binary tree is "foldable" if its left and right subtrees are
   mirror images structurally (values don't matter here).

   We may swap the left and right child of ANY node (a "node swap").
   Swapping a node counts as 1 operation, regardless of subtree size.

   Tasks:
     1. Decide whether the tree is already foldable.
     2. If not, find the minimum number of node swaps needed
        to make it foldable. If impossible, report that too.

   Input format (same style as previous tree problems):
   ----------------------------------------------------
       n
       val1 left1 right1
       val2 left2 right2
       ...
       valn leftn rightn

       val_i  : integer node value (ignored for structural folding)
       left_i : index of left child  (0 if NULL)
       right_i: index of right child (0 if NULL)

   Root is the unique node that never appears as any child.

   Output:
   -------
       If foldable (possibly after swaps):
           YES
           <minimum_swaps>

       If impossible:
           NO
           -1
*/

struct Node {
    int left;
    int right;
};

// key helper for unordered_map on pair(u,v)
struct PairHash {
    size_t operator()(const pair<int,int>& p) const {
        return ( (size_t)p.first << 32 ) ^ (size_t)p.second;
    }
};

const int INF = 1000000000;

vector<Node> tree;
unordered_map< pair<int,int>, int, PairHash > memo;

/*
   dfs(u, v) = minimum swaps needed to make subtree rooted at u
               and subtree rooted at v mirrors of each other.
   Returns INF if impossible.
*/
int dfs(int u, int v) {
    if (u == 0 && v == 0) return 0;   // both null => already mirror
    if (u == 0 || v == 0) return INF; // one null, other not => impossible

    pair<int,int> key = make_pair(u, v);
    unordered_map< pair<int,int>, int, PairHash >::iterator it =
        memo.find(key);
    if (it != memo.end()) return it->second;

    int ul = tree[u].left,  ur = tree[u].right;
    int vl = tree[v].left,  vr = tree[v].right;

    long long best = INF;

    // Case 1: no swap at u or v
    int c1a = dfs(ul, vr);
    int c1b = dfs(ur, vl);
    if (c1a < INF && c1b < INF)
        best = min(best, (long long)c1a + c1b);

    // Case 2: swap at u only
    int c2a = dfs(ur, vr);
    int c2b = dfs(ul, vl);
    if (c2a < INF && c2b < INF)
        best = min(best, 1LL + c2a + c2b);

    // Case 3: swap at v only
    int c3a = dfs(ul, vl);
    int c3b = dfs(ur, vr);
    if (c3a < INF && c3b < INF)
        best = min(best, 1LL + c3a + c3b);

    // Case 4: swap at both u and v
    int c4a = dfs(ur, vl);
    int c4b = dfs(ul, vr);
    if (c4a < INF && c4b < INF)
        best = min(best, 2LL + c4a + c4b);

    int ans = (best >= INF) ? INF : (int)best;
    memo[key] = ans;
    return ans;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    if (n == 0) {
        // Empty tree is trivially foldable with 0 swaps.
        cout << "YES\n0\n";
        return 0;
    }

    tree.assign(n + 1, Node{0, 0});
    vector<int> isChild(n + 1, 0);
    for (int i = 1; i <= n; ++i) {
        int val, L, R;
        cin >> val >> L >> R;    // 'val' ignored
        tree[i].left = L;
        tree[i].right = R;
        if (L != 0) isChild[L] = 1;
        if (R != 0) isChild[R] = 1;
    }

    // find root (node that is not a child)
    int root = 1;
    for (int i = 1; i <= n; ++i) {
        if (!isChild[i]) {
            root = i;
            break;
        }
    }

    int leftRoot  = tree[root].left;
    int rightRoot = tree[root].right;

    int result = dfs(leftRoot, rightRoot);

    if (result >= INF) {
        cout << "NO\n-1\n";
    } else {
        cout << "YES\n" << result << "\n";
    }

    return 0;
}
