#include <bits/stdc++.h>
using namespace std;

/*
    q82 – Bellman-Ford with capacity constraint

    Problem:
        Each directed edge e = (u -> v) has:
            - length   len_e  (can be negative, assume no neg cycles)
            - capacity cap_e  (non-negative)

        Given F units of flow, we must find the shortest path from S to T
        such that every edge on the path can carry F units:

            For all edges e on path: cap_e >= F

        Among all such paths, minimize sum(len_e).

    Approach:
        1. Read graph with N nodes, M edges.
        2. Discard edges whose capacity < F (they cannot carry F units).
        3. Run Bellman-Ford on remaining edges:
                dist[S] = 0, others = INF
                Relax all edges N-1 times.
        4. If dist[T] == INF, print -1 (no feasible path).
           Else print dist[T].

    Input format:

        N M
        u v len cap   (M lines, 0-based indices)
        ...
        S T F

    Output format:

        Single integer:
            shortest distance (total length) of feasible path, or -1
            if none exists.

    Notes:
        - Uses 64-bit signed integers (long long) for lengths & distance.
        - Complexity: O(N * M)
*/

struct Edge {
    int u, v;
    long long len;
    long long cap;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int N, M;
    if (!(cin >> N >> M)) {
        return 0;
    }

    vector<Edge> edges;
    edges.reserve(M);

    for (int i = 0; i < M; ++i) {
        int u, v;
        long long len, cap;
        cin >> u >> v >> len >> cap;
        if (u < 0 || u >= N || v < 0 || v >= N) continue;
        Edge e;
        e.u = u;
        e.v = v;
        e.len = len;
        e.cap = cap;
        edges.push_back(e);
    }

    int S, T;
    long long F;
    cin >> S >> T >> F;

    const long long INF = (1LL << 60);

    vector<long long> dist(N, INF);
    dist[S] = 0;

    // Bellman-Ford with capacity filter
    for (int iter = 0; iter < N - 1; ++iter) {
        bool changed = false;
        for (size_t i = 0; i < edges.size(); ++i) {
            const Edge &e = edges[i];
            if (e.cap < F) continue;          // cannot carry F units
            if (dist[e.u] == INF) continue;   // source not reachable yet

            long long nd = dist[e.u] + e.len;
            if (nd < dist[e.v]) {
                dist[e.v] = nd;
                changed = true;
            }
        }
        if (!changed) break; // early stop if no updates
    }

    if (dist[T] == INF) {
        cout << -1 << "\n";
    } else {
        cout << dist[T] << "\n";
    }

    return 0;
}
