#include <bits/stdc++.h>
using namespace std;

/*
    Problem:
      Binary tree nodes are colored Red, Blue, or Green.
      Find the maximum path sum where the path must alternate colors
      (no two consecutive nodes of the same color). The path does NOT
      need to pass through the root.

    Assumed input format:
        n
        value0 color0 left0 right0
        value1 color1 left1 right1
        ...
        value(n-1) color(n-1) left(n-1) right(n-1)

      * n : number of nodes (0-based indexing)
      * valuei : integer value of node i
      * colori : character 'R', 'G', or 'B'
      * lefti, righti : indices of left and right children, -1 if absent
      * Node 0 is the root.

    Output:
        Single integer: the maximum valid path sum.
*/

struct Node {
    long long val;
    char color; // 'R', 'G', 'B'
    int left;
    int right;
};

vector<Node> tree;
long long globalAns;

// Returns the maximum sum of a downward path that
//   * starts at node 'u'
//   * stays within the subtree of 'u'
//   * obeys the color-alternation constraint.
long long dfs(int u) {
    if (u == -1) return LLONG_MIN;  // should not be called with -1

    Node &cur = tree[u];

    long long bestLeftDown = LLONG_MIN;
    long long bestRightDown = LLONG_MIN;

    // Recurse on children if they exist
    if (cur.left != -1) {
        bestLeftDown = dfs(cur.left);
    }
    if (cur.right != -1) {
        bestRightDown = dfs(cur.right);
    }

    // Compute best downward extension from current node
    long long bestChild = 0; // 0 means we may stop at current node

    // We can extend to a child only if its color differs from current node
    if (cur.left != -1 && tree[cur.left].color != cur.color && bestLeftDown > 0) {
        bestChild = max(bestChild, bestLeftDown);
    }
    if (cur.right != -1 && tree[cur.right].color != cur.color && bestRightDown > 0) {
        bestChild = max(bestChild, bestRightDown);
    }

    // Best downward path starting at current node
    long long bestDown = cur.val + bestChild;

    // Now consider paths that pass through current node:
    // one child -> current -> other child
    vector<long long> contrib;

    if (cur.left != -1 && tree[cur.left].color != cur.color && bestLeftDown > 0) {
        contrib.push_back(bestLeftDown);
    }
    if (cur.right != -1 && tree[cur.right].color != cur.color && bestRightDown > 0) {
        contrib.push_back(bestRightDown);
    }

    sort(contrib.begin(), contrib.end(), greater<long long>());

    long long through = cur.val;
    if (!contrib.empty()) {
        through += contrib[0];
        if (contrib.size() > 1) {
            through += contrib[1];   // at most two children
        }
    }

    // Update global answer with all possibilities at this node
    globalAns = max(globalAns, cur.val);      // node alone
    globalAns = max(globalAns, bestDown);     // downward path
    globalAns = max(globalAns, through);      // path through node

    return bestDown;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0) {
        return 0;
    }

    tree.resize(n);
    for (int i = 0; i < n; ++i) {
        long long v;
        char c;
        int l, r;
        cin >> v >> c >> l >> r;
        tree[i] = {v, c, l, r};
    }

    globalAns = LLONG_MIN;

    // Root is node 0
    dfs(0);

    cout << globalAns << '\n';
    return 0;
}
