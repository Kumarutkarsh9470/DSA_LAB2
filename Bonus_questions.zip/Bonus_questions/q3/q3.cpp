#include <bits/stdc++.h>
using namespace std;

/*
    q3 – Longest subarray that can be turned into a palindrome
         by modifying at most K elements.

    Idea:
      - For any fixed subarray [L, R], the minimum number of element
        changes needed to make it a palindrome equals the number of
        mismatched symmetric pairs:
              (L, R), (L+1, R-1), ...
        because each mismatch can be fixed by changing one side.
      - We need the *longest* subarray whose number of mismatches
        is <= K. If multiple, we choose one with minimal operations.

      - We expand around every possible center (like in palindrome
        detection):
          * odd length:  center at i        -> (L=i, R=i)
          * even length: center between i,i+1 -> (L=i, R=i+1)
        and move L--, R++ while counting mismatches.
        Whenever mismatches <= K, the current [L, R] is a candidate.

      - Overall complexity: O(N^2), fine for typical constraints
        in this style of question.

    Input format:
        n K
        a0 a1 ... a(n-1)

    Output:
        First line : best subarray length
        Second line: minimum operations needed for that subarray
        Third line : resulting palindrome (space-separated)

    Example:
        Input:
          7 1
          1 2 3 2 1 4 5
        Output might be:
          5
          0
          1 2 3 2 1
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    int K;
    if (!(cin >> n >> K)) {
        return 0;
    }

    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    int bestL = 0;
    int bestR = 0;
    int bestLen = 1;
    int bestOps = 0;   // mismatches for best subarray

    // Helper lambda to try a center.
    auto tryCenter = [&](int left, int right) {
        int mismatches = 0;
        int L = left;
        int R = right;

        while (L >= 0 && R < n) {
            if (a[L] != a[R]) {
                mismatches++;
                if (mismatches > K) break;
            }

            int curLen = R - L + 1;
            if (curLen > bestLen ||
                (curLen == bestLen && mismatches < bestOps)) {
                bestLen = curLen;
                bestL = L;
                bestR = R;
                bestOps = mismatches;
            }

            L--;
            R++;
        }
    };

    // Consider all centers
    for (int i = 0; i < n; ++i) {
        // odd-length center at i
        tryCenter(i, i);
        // even-length center between i and i+1
        if (i + 1 < n) tryCenter(i, i + 1);
    }

    // Build one optimal palindrome from bestL..bestR.
    vector<int> pal(a.begin() + bestL, a.begin() + bestR + 1);
    int l = 0, r = (int)pal.size() - 1;
    int ops = 0;

    while (l < r) {
        if (pal[l] != pal[r]) {
            // Change right side to match left (could also do opposite).
            pal[r] = pal[l];
            ops++;
        }
        l++;
        r--;
    }

    // Sanity: ops should match bestOps (but print ops we actually used).
    cout << (bestR - bestL + 1) << "\n";
    cout << ops << "\n";
    for (size_t i = 0; i < pal.size(); ++i) {
        if (i) cout << ' ';
        cout << pal[i];
    }
    cout << "\n";

    return 0;
}
