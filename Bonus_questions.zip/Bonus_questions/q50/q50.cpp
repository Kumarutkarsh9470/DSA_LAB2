#include <bits/stdc++.h>
using namespace std;

/*
    Calculate maximum width of a binary tree counting "gaps".

    For any level, if we label positions as in a full binary tree:

        root at position 0
        left child  of pos i -> 2*i + 1
        right child of pos i -> 2*i + 2

    Then width(level) = last_pos - first_pos + 1
    even if some intermediate children are null.

    We must return max width over all levels and avoid integer overflow.

    Input format (1-based indexing of nodes):

        n
        val1 left1 right1
        ...
        valn leftn rightn

        vali  : integer value (ignored for width computation)
        lefti : index of left child  (0 if NULL)
        righti: index of right child (0 if NULL)

    Root is the unique node never listed as any child.

    Output:

        single integer = maximum width
*/

struct Node {
    long long val;
    int left;
    int right;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    if (n == 0) {
        cout << 0 << "\n";
        return 0;
    }

    vector<Node> tree(n + 1);
    vector<int> isChild(n + 1, 0);

    for (int i = 1; i <= n; ++i) {
        cin >> tree[i].val >> tree[i].left >> tree[i].right;
        if (tree[i].left  != 0) isChild[tree[i].left]  = 1;
        if (tree[i].right != 0) isChild[tree[i].right] = 1;
    }

    // Find root (node that is not any other's child)
    int root = 1;
    for (int i = 1; i <= n; ++i) {
        if (!isChild[i]) {
            root = i;
            break;
        }
    }

    // BFS: queue of (node index, position)
    queue< pair<int, unsigned long long> > q;
    q.push(make_pair(root, 0ULL));

    unsigned long long maxWidth = 0;

    while (!q.empty()) {
        int levelSize = (int)q.size();
        unsigned long long base = q.front().second;  // to normalize indices
        unsigned long long first = 0, last = 0;

        for (int i = 0; i < levelSize; ++i) {
            pair<int, unsigned long long> cur = q.front();
            q.pop();

            int nodeIdx = cur.first;
            unsigned long long idx = cur.second - base;  // normalized

            if (i == 0) first = idx;
            if (i == levelSize - 1) last = idx;

            int L = tree[nodeIdx].left;
            int R = tree[nodeIdx].right;

            if (L != 0) q.push(make_pair(L, idx * 2ULL + 1ULL));
            if (R != 0) q.push(make_pair(R, idx * 2ULL + 2ULL));
        }

        unsigned long long width = last - first + 1ULL;
        if (width > maxWidth) maxWidth = width;
    }

    cout << maxWidth << "\n";
    return 0;
}
