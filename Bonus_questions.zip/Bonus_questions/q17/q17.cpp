#include <bits/stdc++.h>
using namespace std;

/*
   Problem (interpreted):

   We have a circular linked list that is being rotated by some fixed amount
   K nodes *per second* in one direction (clockwise or counter-clockwise).
   We are given two snapshots of the list (as sequences of node values)
   at two consecutive seconds.

   From these two snapshots we must determine:

       - K (how many positions it moves each second), and
       - the direction of rotation,

   or determine that the structure was *modified* (not a pure rotation).

   Input format assumed:

       N
       a0 a1 ... a{N-1}        // snapshot at time t
       b0 b1 ... b{N-1}        // snapshot at time t+1

   Output:

       - If second snapshot is not a rotation of the first:
             MODIFIED

       - Otherwise, print
             K DIRECTION

         where DIRECTION is one of:
             CLOCKWISE
             COUNTERCLOCKWISE
             NONE              (when K = 0, i.e., no rotation)

   We choose the smallest possible K (0 <= K <= N/2).  If the effective
   rotation from first to second snapshot is a left rotation by s positions,
   then:
       - if s == 0      -> K = 0, direction NONE
       - if s <= N - s  -> K = s, direction COUNTERCLOCKWISE
       - else           -> K = N - s, direction CLOCKWISE
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;
    if (N <= 0) {
        cout << "MODIFIED\n";
        return 0;
    }

    vector<int> A(N), B(N);
    for (int i = 0; i < N; ++i) cin >> A[i];
    for (int i = 0; i < N; ++i) cin >> B[i];

    // Find shift s such that rotating A LEFT by s gives B.
    // i.e., B[i] == A[(i + s) % N] for all i.
    int shiftLeft = -1;
    for (int s = 0; s < N; ++s) {
        bool ok = true;
        for (int i = 0; i < N; ++i) {
            if (B[i] != A[(i + s) % N]) {
                ok = false;
                break;
            }
        }
        if (ok) {
            shiftLeft = s;
            break;
        }
    }

    if (shiftLeft == -1) {
        // second snapshot is not a rotation of the first
        cout << "MODIFIED\n";
        return 0;
    }

    // Determine minimal K and direction from net left shift.
    int s = shiftLeft;
    int K;
    string dir;

    if (s == 0) {
        K = 0;
        dir = "NONE";
    } else {
        int rightShift = (N - s) % N;
        if (s <= rightShift) {
            K = s;
            dir = "COUNTERCLOCKWISE";
        } else {
            K = rightShift;
            dir = "CLOCKWISE";
        }
    }

    cout << K << " " << dir << "\n";
    return 0;
}
