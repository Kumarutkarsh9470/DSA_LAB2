#include <bits/stdc++.h>
using namespace std;

/*
    q69 – Build a max-heap from a data stream with a memory window of K.

    For the purposes of this coding exercise, we:

      * Read all N elements into an array `a`.
      * Build a max-heap in-place using the standard bottom-up O(N) heapify.
      * Output the resulting heap array.

    In a real streaming / external-memory setting (K << N), the idea is:

      1. The full array lives on disk; you only have a RAM buffer of size K.
      2. Partition the N elements into blocks of size <= K.
      3. For each block, read it into memory, build a local max-heap,
         and write it back. Now each block is heap-ordered internally.
      4. Treat each block root as an element of a higher-level heap and
         repeat in multiple passes (like building a tournament tree) until
         the global heap property is satisfied at all levels.

    With fan-out ≈ K, the number of passes is O(log_K N); each pass scans
    O(N) data. So total I/O is O(N log_K N) and RAM usage is O(K).

    Here we implement the in-memory building part cleanly and efficiently.
*/


// Sifts element at index i downwards in a max-heap of size n.
void siftDown(vector<long long> &a, int n, int i) {
    while (true) {
        int largest = i;
        int left  = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && a[left] > a[largest])  largest = left;
        if (right < n && a[right] > a[largest]) largest = right;

        if (largest == i) break;
        swap(a[i], a[largest]);
        i = largest;
    }
}

// Standard bottom-up heapify: O(N)
void buildMaxHeap(vector<long long> &a) {
    int n = (int)a.size();
    for (int i = n / 2 - 1; i >= 0; --i) {
        siftDown(a, n, i);
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    long long K;       // memory window size, not used directly in this simulation
    if (!(cin >> N >> K)) {
        return 0;
    }

    vector<long long> a(N);
    for (int i = 0; i < N; ++i) {
        cin >> a[i];
    }

    buildMaxHeap(a);

    // Output the heap array (level-order)
    for (int i = 0; i < N; ++i) {
        if (i) cout << ' ';
        cout << a[i];
    }
    cout << '\n';

    return 0;
}
