#include <bits/stdc++.h>
using namespace std;

/*
    Fair group queue

    We have G different groups (0 .. G-1).  Each element belongs to one
    group.  We must serve elements such that no group gets more than K
    consecutive elements **whenever another group is available**.

    Operations (all in O(log G)):

        enqueue(x, g)  – push element x into group g
        fairDequeue()  – pop one element, respecting fairness

    Data structure
    --------------
    - For each group g, we keep a FIFO queue<int> q[g].
    - A std::set<int> active keeps the ids of groups that currently
      have at least one pending element.
    - We remember:
          lastGroup   – group served most recently (or -1)
          consecCount – how many consecutive elements taken from lastGroup.

    On fairDequeue():

        1. If no active group -> EMPTY.
        2. If lastGroup is inactive or not set -> pick the smallest id
           from active.
        3. Else if consecCount < K -> pick lastGroup again (still fair).
        4. Else (consecCount == K and lastGroup still active):
             - If there exists another active group, pick the smallest
               group id ≠ lastGroup.
             - If lastGroup is the *only* active group, we must still take
               from it (there is no alternative), so we just continue.

    This guarantees that, whenever multiple groups are waiting, no group
    will get more than K consecutive services.

    Input format
    ------------
        G K Q
        (G = number of groups, K = fairness cap, Q = number of ops)

        Then Q lines, each being:

        ENQ x g     (element value x, group id g in [0, G-1])
        DEQ

    Output
    ------
        For every DEQ:
            - "EMPTY" if no element is available
            - otherwise: "<value> <groupId>"
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int G, K, Q;
    if (!(cin >> G >> K >> Q)) return 0;

    vector<queue<int>> groups(G);
    set<int> active;          // groups with non-empty queue

    int lastGroup = -1;
    int consecCount = 0;

    auto chooseGroup = [&]() -> int {
        if (active.empty()) return -1;

        // If last group is invalid, choose smallest active group
        if (lastGroup == -1 || !active.count(lastGroup)) {
            return *active.begin();
        }

        // If we haven't exhausted K consecutive from lastGroup, use it
        if (consecCount < K) {
            return lastGroup;
        }

        // We have already served K from lastGroup consecutively.
        // Try to pick another active group if one exists.
        if (active.size() == 1 && *active.begin() == lastGroup) {
            // Only this group is available; fairness cannot be enforced
            return lastGroup;
        }

        auto it = active.begin();
        if (*it != lastGroup) return *it;
        ++it;
        return *it;    // there must be at least one more group
    };

    for (int qi = 0; qi < Q; ++qi) {
        string op;
        cin >> op;
        if (op == "ENQ") {
            int x, g;
            cin >> x >> g;
            if (g < 0 || g >= G) continue; // ignore invalid
            bool wasEmpty = groups[g].empty();
            groups[g].push(x);
            if (wasEmpty) active.insert(g);
        } else if (op == "DEQ") {
            int g = chooseGroup();
            if (g == -1) {
                cout << "EMPTY\n";
                continue;
            }
            int x = groups[g].front();
            groups[g].pop();
            if (groups[g].empty()) {
                active.erase(g);
            }

            if (g == lastGroup) {
                consecCount++;
            } else {
                lastGroup = g;
                consecCount = 1;
            }

            cout << x << ' ' << g << '\n';
        }
    }

    return 0;
}
