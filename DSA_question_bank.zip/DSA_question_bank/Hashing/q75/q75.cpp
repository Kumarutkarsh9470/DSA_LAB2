#include <bits/stdc++.h>
using namespace std;

/*
    q75 – Cuckoo Hashing with k >= 3 Hash Functions

    -------------------------------------------------------------
    Design
    -------------------------------------------------------------
    We implement a cuckoo hash table that uses K >= 3 independent
    hash functions instead of the classical 2.

    Storage:
        - Single table `table[0..M-1]` of keys (long long).
        - `used[i]` marks if slot i is occupied.
        - Special value EMPTY is not stored as a key.

    Hash functions:
        h_i(key) = (a[i] * f(key) + b[i]) mod PRIME mod M
        where a[i], b[i] are random 64-bit coefficients.
        f(key) folds signed key into unsigned for hashing.

    Operations:
        - insert(x)
        - contains(x)
        - erase(x)

    Insertion algorithm (multi-way cuckoo):

        if key already present -> done.

        For up to MAX_KICKS times:
            1. For all K candidate positions pos[h] = h_i(key):
                   if any is empty, place key there and return.

            2. Otherwise, pick one candidate position (round-robin
               on [0..K-1]), kick out its current occupant y,
               place key there, and set key := y and repeat.

        If we fail to insert after MAX_KICKS displacements, we
        declare a *cycle / insertion failure* and call rehash(),
        which re-creates all hash functions (and optionally grows
        the table) and reinserts all existing keys including the new one.

    Cycle detection & resolution:
        - Detection: exceeding MAX_KICKS during a single insert.
        - Resolution: rehash() with new random hash functions,
          and if we had many failures in a row we also double
          the table size to lower the load factor.

    Complexity & Load Factor (intuition, not strict proof):
        - With k >= 3 positions per key, the probability that all
          candidate positions are occupied in a "bad" cycle is
          significantly smaller than for k = 2. This allows higher
          load factors (close to ~0.95 or more in practice) before
          rehashing becomes likely.
        - Each successful insert probes at most K positions plus a
          small expected number of displacements → amortized O(1).
        - Search and delete are O(K) worst-case (check at most
          K candidate positions).
        - Rehash is O(N) but happens rarely, so amortized insert
          remains O(1).

    -------------------------------------------------------------
    Console interface for this problem:
    -------------------------------------------------------------
        M K Q
        Q lines with operations:

          1 x   : insert x
          2 x   : search x, print 1 if present, else 0
          3 x   : erase x,  print 1 if erased,  else 0

    All keys are 64-bit signed integers.
*/

class CuckooHash {
    static constexpr unsigned long long PRIME = 1000000007ULL;
    static constexpr long long EMPTY = (long long)0x7fffffffffffffffLL;

    size_t M;                 // table capacity
    int K;                    // number of hash functions (>=3)
    vector<long long> table;  // stored keys
    vector<bool> used;
    vector<unsigned long long> a, b; // hash parameters
    mt19937_64 rng;
    int maxKicks;             // max displacements per insert

public:
    CuckooHash(size_t capacity, int K_hash)
        : M(capacity), K(max(3, K_hash)),
          table(capacity, EMPTY), used(capacity, false),
          a(K), b(K), rng((uint64_t)chrono::steady_clock::now().time_since_epoch().count()) {
        maxKicks = 2 * (int)log2(max<size_t>(4, M)) * K + 50;
        initHashes();
    }

    // Insert key x; returns true if inserted or already existed.
    bool insert(long long x) {
        if (contains(x)) return true;

        for (int attempt = 0; attempt < 5; ++attempt) {
            if (insertInternal(x)) return true;
            rehash(true); // grow + rehash after failure
        }
        return false; // very unlikely
    }

    // Search key
    bool contains(long long x) const {
        for (int i = 0; i < K; ++i) {
            size_t pos = hash_i(i, x);
            if (used[pos] && table[pos] == x) return true;
        }
        return false;
    }

    // Erase key; returns true if found and erased.
    bool erase(long long x) {
        for (int i = 0; i < K; ++i) {
            size_t pos = hash_i(i, x);
            if (used[pos] && table[pos] == x) {
                used[pos] = false;
                table[pos] = EMPTY;
                return true;
            }
        }
        return false;
    }

private:
    void initHashes() {
        uniform_int_distribution<unsigned long long> dist(1, PRIME - 1);
        for (int i = 0; i < K; ++i) {
            a[i] = dist(rng);
            b[i] = dist(rng);
        }
    }

    // Fold signed key to unsigned space for hashing
    static inline unsigned long long foldKey(long long x) {
        return (unsigned long long)(x) ^ (unsigned long long)(0x8000000000000000ULL);
    }

    size_t hash_i(int idx, long long key) const {
        unsigned long long x = foldKey(key);
        unsigned long long h = (a[idx] * x + b[idx]) % PRIME;
        return (size_t)(h % M);
    }

    // Try to insert without global rehash; if fails, return false.
    bool insertInternal(long long key) {
        long long cur = key;
        int which = 0; // which hash function to use when kicking

        for (int kick = 0; kick < maxKicks; ++kick) {

            // First try: see if any candidate position is empty
            for (int i = 0; i < K; ++i) {
                size_t pos = hash_i(i, cur);
                if (!used[pos]) {
                    used[pos] = true;
                    table[pos] = cur;
                    return true;
                }
            }

            // All positions occupied. Kick one victim (round-robin across K).
            size_t pos = hash_i(which, cur);
            which = (which + 1) % K;

            // swap cur with victim
            std::swap(cur, table[pos]);
            // cur is the victim; continue to reinsert cur
        }
        // Too many displacements -> likely cycle
        return false;
    }

    // Rebuild table with new hash functions; optionally grow table.
    void rehash(bool grow) {
        vector<long long> keys;
        keys.reserve(M);
        for (size_t i = 0; i < M; ++i) {
            if (used[i]) keys.push_back(table[i]);
        }

        if (grow) {
            M *= 2;
            if (M == 0) M = 4;
        }

        table.assign(M, EMPTY);
        used.assign(M, false);
        initHashes();
        maxKicks = 2 * (int)log2(max<size_t>(4, M)) * K + 50;

        for (long long x : keys) {
            insertInternal(x); // internal insert; should succeed
        }
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    size_t M;
    int K, Q;
    if (!(cin >> M >> K >> Q)) return 0;

    CuckooHash ht(M, K);

    while (Q--) {
        int type;
        long long x;
        cin >> type >> x;

        if (type == 1) {
            ht.insert(x);
        } else if (type == 2) {
            cout << (ht.contains(x) ? 1 : 0) << "\n";
        } else if (type == 3) {
            cout << (ht.erase(x) ? 1 : 0) << "\n";
        }
    }

    return 0;
}
