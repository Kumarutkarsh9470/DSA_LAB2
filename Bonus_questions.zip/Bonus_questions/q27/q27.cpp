#include <bits/stdc++.h>
using namespace std;

/*
    Problem:

    Given:
      - an array of temperatures T[0..N-1]
      - an array gaps[0..N-1], where gaps[i] is the number of missing
        calendar days AFTER day i (i.e., between measurement i and i+1)

    For each measured day i, find how many previous **consecutive days**
    (in calendar time) had temperature ≤ T[i], counting gaps as days.
    This is a “stock span with gaps” problem.

    Interpretation:

        Let D[i] be the actual calendar day index when temperature T[i]
        was measured (1-based). Then

            D[0] = 1
            D[i] = D[i-1] + 1 + gaps[i-1]   for i ≥ 1

        For each i we want the span in calendar days:

            span[i] = D[i] - lastGreaterDay

        where lastGreaterDay is the calendar day index of the nearest
        previous measurement j with T[j] > T[i]; if none exists,
        lastGreaterDay = 0.

    We can find lastGreaterDay using a decreasing stack of indices
    (standard O(N) stock-span trick), but when computing the span we use
    calendar days D[i] instead of the plain index i.

    Assumed input format:

        N
        T0 T1 ... T{N-1}
        g0 g1 ... g{N-1}

        (g_{N-1} is the number of missing days after the last measurement
         and does not affect any span; we just read it for completeness.)

    Output:

        N integers: span[0] span[1] ... span[N-1]
        (space separated, in order of days 0..N-1)
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;
    if (N <= 0) return 0;

    vector<long long> temp(N);
    for (int i = 0; i < N; ++i) cin >> temp[i];

    vector<long long> gaps(N);
    for (int i = 0; i < N; ++i) cin >> gaps[i];

    // Compute actual calendar day indices
    vector<long long> day(N);
    day[0] = 1;
    for (int i = 1; i < N; ++i) {
        day[i] = day[i-1] + 1 + gaps[i-1];
    }

    vector<long long> span(N);
    stack<int> st;  // indices of previous days with strictly greater temps

    for (int i = 0; i < N; ++i) {
        while (!st.empty() && temp[st.top()] <= temp[i]) {
            st.pop();
        }

        long long lastGreaterDay = st.empty() ? 0LL : day[st.top()];
        span[i] = day[i] - lastGreaterDay;

        st.push(i);
    }

    for (int i = 0; i < N; ++i) {
        if (i) cout << ' ';
        cout << span[i];
    }
    cout << '\n';

    return 0;
}
