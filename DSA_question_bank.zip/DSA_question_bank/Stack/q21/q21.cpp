#include <bits/stdc++.h>
using namespace std;

/*
    KStacksMin:
    -----------
    Implements K stacks in a single array of size N.

    - All stacks share one pool of slots => no fixed partition.
      So capacity is automatically "rebalanced": any stack can
      grow while there is at least one free slot in the array.

    - push(stackId, x):  amortized O(1)
    - pop(stackId):      amortized O(1)
    - getMin(stackId):   O(1)

    Implementation details
    ----------------------
    We maintain arrays of length N:

        value[i]   : stored value at slot i
        nextIdx[i] : used as:
                     * in free list: link to next free slot
                     * in stack: link to next element in that stack
        minVal[i]  : the minimum of the stack *up to and including*
                     this node

    And:
        top[s]     : index of the top slot of stack s (or -1)
        freeTop    : head of the free-list linked list

    push(s, x):
        - Take first free slot 'i' from freeTop.
        - Store x in value[i].
        - minVal[i] = (empty stack ? x : min(x, minVal[top[s]])).
        - Link it into the stack via nextIdx[i] = top[s], top[s] = i.

    pop(s):
        - Remove top index i from stack s.
        - Attach i back to free-list.

    getMin(s):
        - Return minVal[top[s]].
*/

class KStacksMin {
private:
    int N;                 // total capacity (slots)
    int K;                 // number of stacks

    vector<long long> value;
    vector<long long> minVal;
    vector<int> nextIdx;   // next index for stack/free list
    vector<int> top;       // top index for each stack
    int freeTop;           // head of free list

public:
    KStacksMin(int numStacks, int capacity)
        : N(capacity), K(numStacks),
          value(N), minVal(N), nextIdx(N),
          top(K, -1), freeTop(0)
    {
        // initialize free list [0 -> 1 -> 2 -> ... -> N-1]
        for (int i = 0; i < N-1; ++i)
            nextIdx[i] = i+1;
        nextIdx[N-1] = -1;
    }

    bool isFull() const {
        return freeTop == -1;
    }

    bool isEmpty(int s) const {
        if (s < 0 || s >= K) return true;
        return top[s] == -1;
    }

    // Push x on stack s (0-based stack index). Returns false if full.
    bool push(int s, long long x) {
        if (s < 0 || s >= K) return false;
        if (isFull()) return false;

        int i = freeTop;         // take first free slot
        freeTop = nextIdx[i];    // advance free list

        value[i] = x;

        // link into stack s
        nextIdx[i] = top[s];
        top[s] = i;

        // maintain per-stack min
        if (nextIdx[i] == -1) {
            // stack was empty; min is x
            minVal[i] = x;
        } else {
            long long prevMin = minVal[nextIdx[i]];
            minVal[i] = std::min(x, prevMin);
        }

        return true;
    }

    // Pop from stack s. Returns (success, poppedValue).
    pair<bool,long long> pop(int s) {
        if (s < 0 || s >= K) return {false, 0};
        int i = top[s];
        if (i == -1) return {false, 0};  // underflow

        top[s] = nextIdx[i];    // move top down

        // add popped index back to free list
        nextIdx[i] = freeTop;
        freeTop = i;

        return {true, value[i]};
    }

    // Get minimum of stack s. Returns (exists, minValue).
    pair<bool,long long> getMin(int s) const {
        if (s < 0 || s >= K) return {false, 0};
        int i = top[s];
        if (i == -1) return {false, 0};
        return {true, minVal[i]};
    }
};

// Simple command-driven test harness:
//
// Input format:
//   N K Q
//   Then Q lines, each one is one of:
//     push s x
//     pop s
//     getMin s
//
// Indices s are 0..K-1
// For each operation we print a response.
//
// Example:
//   10 3 7
//   push 0 5
//   push 0 3
//   push 1 10
//   getMin 0
//   pop 0
//   getMin 0
//   getMin 1
//
// Output:
//   OK
//   OK
//   OK
//   3
//   3
//   5
//   10

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, K, Q;
    if (!(cin >> N >> K >> Q)) {
        return 0;
    }

    KStacksMin ks(K, N);

    while (Q--) {
        string cmd;
        cin >> cmd;

        if (cmd == "push") {
            int s;
            long long x;
            cin >> s >> x;
            if (ks.push(s, x)) {
                cout << "OK\n";
            } else {
                cout << "FULL\n";
            }
        } else if (cmd == "pop") {
            int s;
            cin >> s;
            auto res = ks.pop(s);
            if (!res.first) {
                cout << "EMPTY\n";
            } else {
                cout << res.second << "\n";
            }
        } else if (cmd == "getMin") {
            int s;
            cin >> s;
            auto res = ks.getMin(s);
            if (!res.first) {
                cout << "EMPTY\n";
            } else {
                cout << res.second << "\n";
            }
        } else {
            // Unknown command; consume rest of line to avoid issues.
            string dummy;
            getline(cin, dummy);
            cout << "ERR\n";
        }
    }

    return 0;
}
