#include <bits/stdc++.h>
using namespace std;

/*
    q8 – Circular array partition into exactly M contiguous segments
         minimizing the maximum segment sum.

    Assumptions:
        - Array elements are non-negative (standard for this type of
          partitioning problem; otherwise the objective is not monotone).
        - 1 <= M <= N.

    Idea:

      For a *linear* array we can binary-search the answer X and, for
      each X, greedily count how many segments are needed if each segment
      must have sum <= X. Monotonicity in X makes this work.

      For a *circular* array we must handle wrap-around: we may start
      at any index.

      For a fixed X, we need to know if we can cover the circle with
      at most M segments, each having sum <= X.

      Approach for a given X:

      1) Duplicate the array: B[0..2N-1] = A[0..N-1] repeated twice.
      2) For each starting position i in [0, 2N), compute
            next[0][i] = smallest index j > i such that
                             sum(B[i..j-1]) <= X
                         and extending j further would break the condition.
         We can do this with a sliding window / two pointers in O(N).
         Also have a sentinel index LEN = 2N with next[0][LEN] = LEN.
      3) Build binary lifting table:
             next[k+1][i] = next[k][ next[k][i] ]
         so that in O(log M) we can jump over 2^k segments at once.
      4) For each starting index s in [0, N-1], simulate taking at most
         M segments:
             pos = s
             for each bit b of M:
                 if (M & (1<<b)) pos = next[b][pos]
         If pos >= s + N, then starting at s we can cover N consecutive
         elements (i.e., the whole circle) with at most M segments,
         each sum <= X. Hence X is feasible.

      Complexity:
          - Feasibility check: O(N log M)
          - Binary search over X: O(log(sum(A)))
          - Total: O(N log M log(sum(A)))

      We then binary search X between:
          low  = max(A[i])
          high = sum(A[i])
      and output the minimal feasible X.

    Input:
        N M
        a0 a1 ... a(N-1)

    Output:
        Minimal possible value of the maximum segment sum.
*/

bool canPartitionCircular(const vector<long long> &A, int M, long long X) {
    int N = (int)A.size();
    int LEN = 2 * N;

    // Build duplicated array
    vector<long long> B(LEN);
    for (int i = 0; i < LEN; ++i) B[i] = A[i % N];

    // next[0][i]: index after taking one maximal segment from i
    vector<int> nxt0(LEN + 1, LEN);
    int j = 0;
    long long cur = 0;

    for (int i = 0; i < LEN; ++i) {
        while (j < LEN && cur + B[j] <= X) {
            cur += B[j];
            ++j;
        }
        // we can always take at least one element because X >= max(A)
        nxt0[i] = j;
        cur -= B[i];
    }
    nxt0[LEN] = LEN; // sentinel

    // Binary lifting for up to M segments
    int K = 0;
    while ((1 << K) <= M) ++K;
    vector< vector<int> > up(K, vector<int>(LEN + 1, LEN));
    for (int i = 0; i <= LEN; ++i) up[0][i] = nxt0[i];
    for (int k = 1; k < K; ++k) {
        for (int i = 0; i <= LEN; ++i) {
up[k][i] = up[k - 1][ up[k - 1][i] ];
}
}
// Try each starting point on the original circle
for (int s = 0; s < N; ++s) {
int pos = s;
for (int k = 0; k < K; ++k) {
if (M & (1 << k)) pos = up[k][pos];
}
if (pos >= s + N) return true; // covered full circle from s
}
return false;
}
int main() {
ios::sync_with_stdio(false);
cin.tie(nullptr);
int N, M;
if (!(cin >> N >> M)) return 0;
vector<long long> A(N);
for (int i = 0; i < N; ++i) cin >> A[i];
long long low = 0, high = 0;
for (int i = 0; i < N; ++i) {
low = max(low, A[i]);
high += A[i];
}
if (M <= 0 || M > N) {
// Degenerate: can't form more segments than elements or zero segments.
// Here we just print -1 to indicate invalid.
cout << -1 << "\n";
return 0;
    }

    while (low < high) {
        long long mid = low + (high - low) / 2;
        if (canPartitionCircular(A, M, mid)) high = mid;
        else low = mid + 1;
    }

    cout << low << "\n";
    return 0;
}
