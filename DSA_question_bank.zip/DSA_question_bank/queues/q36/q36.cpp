#include <bits/stdc++.h>
using namespace std;

/*
    Auto-resizing circular queue with movement tracking.

    Strategy:
      - Backing array of capacity 'cap'.
      - 'head' = index of current front element.
      - 'tail' = index of position *after* last element.
      - 'sz'   = current number of elements.
      - When full, capacity doubles.
      - When sz <= cap/4, capacity halves (down to at least 1).
      - On each resize we pack all elements starting from index 0.
        Number of moved elements = sz (each copied once).
      - We accumulate this into totalMoves.

    Operations:
      ENQ x  : enqueue x
      DEQ    : dequeue front, print popped value or "EMPTY"
      PEEK   : print front without removing, or "EMPTY"
      STATS  : print "SIZE cap sz MOVES totalMoves"

    Input format:
      M                      -- number of operations
      <M command lines>

    At the very end we also print:
      TOTAL_MOVES totalMoves
*/

class AutoCircularQueue {
private:
    vector<long long> data;
    int cap;
    int head;
    int tail;
    int sz;
    long long totalMoves;  // total elements copied during resizes

    void resizeIfNeededOnPush() {
        if (sz < cap) return;           // space available
        int newCap = max(1, cap * 2);   // double capacity
        reallocate(newCap);
    }

    void resizeIfNeededOnPop() {
        if (cap <= 1) return;
        if (sz * 4 > cap) return;      // keep at least 25% full
        int newCap = max(1, cap / 2);  // halve capacity
        if (newCap < sz) newCap = sz;  // just in case
        if (newCap == cap) return;
        reallocate(newCap);
    }

    void reallocate(int newCap) {
        vector<long long> nd(newCap);
        // copy elements in queue order to new array starting at 0
        for (int i = 0; i < sz; ++i) {
            nd[i] = data[(head + i) % cap];
        }
        totalMoves += sz;          // each element moved once
        data.swap(nd);
        cap = newCap;
        head = 0;
        tail = sz % cap;
    }

public:
    AutoCircularQueue(int initialCap = 1)
        : cap(max(1, initialCap)),
          head(0), tail(0), sz(0), totalMoves(0) {
        data.assign(cap, 0);
    }

    bool empty() const { return sz == 0; }
    int size() const { return sz; }
    int capacity() const { return cap; }
    long long moved() const { return totalMoves; }

    void enqueue(long long x) {
        resizeIfNeededOnPush();
        data[tail] = x;
        tail = (tail + 1) % cap;
        ++sz;
    }

    bool dequeue(long long &out) {
        if (sz == 0) return false;
        out = data[head];
        head = (head + 1) % cap;
        --sz;
        resizeIfNeededOnPop();
        return true;
    }

    bool front(long long &out) const {
        if (sz == 0) return false;
        out = data[head];
        return true;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int M;
    if (!(cin >> M)) return 0;

    AutoCircularQueue q; // start with capacity 1

    while (M--) {
        string cmd;
        cin >> cmd;

        if (cmd == "ENQ" || cmd == "ENQUEUE") {
            long long x;
            cin >> x;
            q.enqueue(x);
            cout << "OK\n";
        } else if (cmd == "DEQ" || cmd == "DEQUEUE") {
            long long val;
            if (!q.dequeue(val)) {
                cout << "EMPTY\n";
            } else {
                cout << val << "\n";
            }
        } else if (cmd == "PEEK" || cmd == "FRONT") {
            long long val;
            if (!q.front(val)) {
                cout << "EMPTY\n";
            } else {
                cout << val << "\n";
            }
        } else if (cmd == "STATS") {
            cout << "SIZE " << q.capacity()
                 << " " << q.size()
                 << " MOVES " << q.moved() << "\n";
        } else {
            // unknown command: consume rest of line, print error
            string rest;
            getline(cin, rest);
            cout << "ERR\n";
        }
    }

    cout << "TOTAL_MOVES " << q.moved() << "\n";
    return 0;
}
