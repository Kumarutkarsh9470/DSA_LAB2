#include <bits/stdc++.h>
using namespace std;

/*
    q10 – Structure with:
        1) update(index, value)
        2) queryXOR(L, R)
        3) countSubarraysWithXOR(L, R, X)

    Implementation:
        - Fenwick tree for XOR to support point updates + range XOR.
        - For countSubarraysWithXOR, do a linear scan on [L,R] with a
          hash map of prefix XOR frequencies.

    Input format:

        n q
        a0 a1 ... a(n-1)
        Then q operations:

        type 1: 1 idx value          -> update
        type 2: 2 L R                -> print XOR of [L,R]
        type 3: 3 L R X              -> print count of subarrays in [L,R]
                                       whose XOR is X

        All indices are 0-based.

    Output:
        For each query of type 2 or 3, print the answer on its own line.
*/

// Fenwick tree (BIT) with XOR operation
struct Fenwick {
    int n;
    vector<int> bit;

    Fenwick(int n = 0) {
        init(n);
    }

    void init(int n_) {
        n = n_;
        bit.assign(n + 1, 0);
    }

    // add 'val' at position idx (0-based)
    void add(int idx, int val) {
        for (int i = idx + 1; i <= n; i += i & -i) {
            bit[i] ^= val;
        }
    }

    // prefix XOR [0..idx] (0-based)
    int prefixXor(int idx) const {
        int res = 0;
        for (int i = idx + 1; i > 0; i -= i & -i) {
            res ^= bit[i];
        }
        return res;
    }

    // range XOR [l..r]
    int rangeXor(int l, int r) const {
        if (l > r) return 0;
        int xr = prefixXor(r);
        int xl = (l == 0 ? 0 : prefixXor(l - 1));
        return xr ^ xl;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    if (!(cin >> n >> q)) {
        return 0;
    }

    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    Fenwick fw(n);
    // build Fenwick by adding current values
    for (int i = 0; i < n; ++i) {
        fw.add(i, a[i]);
    }

    while (q--) {
        int type;
        cin >> type;

        if (type == 1) {
            // update(index, value)
            int idx, value;
            cin >> idx >> value;
            if (idx < 0 || idx >= n) continue;

            int delta = a[idx] ^ value; // XOR difference
            a[idx] = value;
            fw.add(idx, delta);
        }
        else if (type == 2) {
            // queryXOR(L, R)
            int L, R;
            cin >> L >> R;
            if (L < 0) L = 0;
            if (R >= n) R = n - 1;
            if (L > R) {
                cout << 0 << "\n";
                continue;
            }
            int ans = fw.rangeXor(L, R);
            cout << ans << "\n";
        }
        else if (type == 3) {
            // countSubarraysWithXOR(L, R, X)
            int L, R, X;
            cin >> L >> R >> X;
            if (L < 0) L = 0;
            if (R >= n) R = n - 1;
            if (L > R) {
                cout << 0 << "\n";
                continue;
            }

            unordered_map<int, long long> freq;
            freq.reserve(R - L + 2);
            freq.max_load_factor(0.7f);

            int pref = 0;
            freq[0] = 1; // empty prefix before L

            long long count = 0;
            for (int i = L; i <= R; ++i) {
                pref ^= a[i];
                int want = pref ^ X;
                unordered_map<int,long long>::iterator it = freq.find(want);
                if (it != freq.end()) {
                    count += it->second;
                }
                freq[pref]++;
            }
            cout << count << "\n";
        }
    }

    return 0;
}
