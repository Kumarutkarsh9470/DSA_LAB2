#include <bits/stdc++.h>
using namespace std;

/*
    DEPQ (Double-Ended Priority Queue) with:

        insert x
        getMin
        getMax
        deleteMin
        deleteMax
        updatePriority oldVal newVal   (identify element by its value)

    All operations are O(log N).

    Design
    ------
    We maintain:

        - a min-heap
        - a max-heap

    Both heaps store the *value* itself (which is also its priority).
    We also maintain maps:

        posMin[value] -> index in min-heap
        posMax[value] -> index in max-heap

    Using these, deletions and updates by value become O(log N).

    Assumption: all values in the DEPQ are distinct.  This is necessary
                to have a unique mapping from value to heap index.

    Input format
    ------------
        Q                        // number of operations
        Then Q lines, each of:

        INSERT x
        GETMIN
        GETMAX
        DELETEMIN
        DELETEMAX
        UPDATE oldVal newVal

    Commands are case-insensitive (we convert to upper).

    Output
    ------
        GETMIN      -> prints minimum value or "EMPTY"
        GETMAX      -> prints maximum value or "EMPTY"
        DELETEMIN   -> prints removed minimum value or "EMPTY"
        DELETEMAX   -> prints removed maximum value or "EMPTY"
        UPDATE      -> prints "OK" if successful, "NOTFOUND" otherwise

    (INSERT prints nothing.)
*/

class DEPQ {
    vector<int> minHeap;                 // 0-based
    vector<int> maxHeap;
    unordered_map<int,int> posMin;       // value -> index in minHeap
    unordered_map<int,int> posMax;       // value -> index in maxHeap

    // ===== heap helpers =====
    void swapMin(int i, int j) {
        if (i == j) return;
        swap(minHeap[i], minHeap[j]);
        posMin[minHeap[i]] = i;
        posMin[minHeap[j]] = j;
    }

    void swapMax(int i, int j) {
        if (i == j) return;
        swap(maxHeap[i], maxHeap[j]);
        posMax[maxHeap[i]] = i;
        posMax[maxHeap[j]] = j;
    }

    void heapifyUpMin(int idx) {
        while (idx > 0) {
            int p = (idx - 1) / 2;
            if (minHeap[p] <= minHeap[idx]) break;
            swapMin(p, idx);
            idx = p;
        }
    }

    void heapifyDownMin(int idx) {
        int n = (int)minHeap.size();
        while (true) {
            int l = 2 * idx + 1;
            int r = 2 * idx + 2;
            int smallest = idx;
            if (l < n && minHeap[l] < minHeap[smallest]) smallest = l;
            if (r < n && minHeap[r] < minHeap[smallest]) smallest = r;
            if (smallest == idx) break;
            swapMin(idx, smallest);
            idx = smallest;
        }
    }

    void heapifyUpMax(int idx) {
        while (idx > 0) {
            int p = (idx - 1) / 2;
            if (maxHeap[p] >= maxHeap[idx]) break;
            swapMax(p, idx);
            idx = p;
        }
    }

    void heapifyDownMax(int idx) {
        int n = (int)maxHeap.size();
        while (true) {
            int l = 2 * idx + 1;
            int r = 2 * idx + 2;
            int largest = idx;
            if (l < n && maxHeap[l] > maxHeap[largest]) largest = l;
            if (r < n && maxHeap[r] > maxHeap[largest]) largest = r;
            if (largest == idx) break;
            swapMax(idx, largest);
            idx = largest;
        }
    }

    // remove a value from a specific heap, given its index
    void removeFromMin(int idx) {
        int n = (int)minHeap.size();
        if (idx < 0 || idx >= n) return;
        int v = minHeap[idx];
        swapMin(idx, n - 1);
        minHeap.pop_back();
        posMin.erase(v);
        if (idx < (int)minHeap.size()) {
            heapifyUpMin(idx);
            heapifyDownMin(idx);
        }
    }

    void removeFromMax(int idx) {
        int n = (int)maxHeap.size();
        if (idx < 0 || idx >= n) return;
        int v = maxHeap[idx];
        swapMax(idx, n - 1);
        maxHeap.pop_back();
        posMax.erase(v);
        if (idx < (int)maxHeap.size()) {
            heapifyUpMax(idx);
            heapifyDownMax(idx);
        }
    }

public:
    bool empty() const {
        return minHeap.empty();
    }

    // Insert new value x (assumes x not already present)
    void insert(int x) {
        // insert in minHeap
        minHeap.push_back(x);
        posMin[x] = (int)minHeap.size() - 1;
        heapifyUpMin(posMin[x]);

        // insert in maxHeap
        maxHeap.push_back(x);
        posMax[x] = (int)maxHeap.size() - 1;
        heapifyUpMax(posMax[x]);
    }

    // Getters
    bool getMin(int &out) const {
        if (minHeap.empty()) return false;
        out = minHeap[0];
        return true;
    }

    bool getMax(int &out) const {
        if (maxHeap.empty()) return false;
        out = maxHeap[0];
        return true;
    }

    // Delete min / max, returning the removed value if any
    bool deleteMin(int &out) {
        if (minHeap.empty()) return false;
        int v = minHeap[0];
        out = v;

        // remove from both heaps
        int idxMin = posMin[v];
        int idxMax = posMax[v];
        removeFromMin(idxMin);
        removeFromMax(idxMax);
        return true;
    }

    bool deleteMax(int &out) {
        if (maxHeap.empty()) return false;
        int v = maxHeap[0];
        out = v;

        int idxMin = posMin[v];
        int idxMax = posMax[v];
        removeFromMin(idxMin);
        removeFromMax(idxMax);
        return true;
    }

    // Update priority: change value oldVal -> newVal.
    // Returns true if oldVal existed and was updated.
    bool updatePriority(int oldVal, int newVal) {
        auto itMin = posMin.find(oldVal);
        if (itMin == posMin.end()) return false;

        // Assume newVal is not already present.
        int idxMin = itMin->second;
        int idxMax = posMax[oldVal];

        // Update minHeap
        minHeap[idxMin] = newVal;
        posMin.erase(oldVal);
        posMin[newVal] = idxMin;
        heapifyUpMin(idxMin);
        heapifyDownMin(idxMin);

        // Update maxHeap
        maxHeap[idxMax] = newVal;
        posMax.erase(oldVal);
        posMax[newVal] = idxMax;
        heapifyUpMax(idxMax);
        heapifyDownMax(idxMax);

        return true;
    }
};

string toUpper(const string &s) {
    string t = s;
    for (char &c : t) c = (char)toupper((unsigned char)c);
    return t;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    DEPQ depq;

    for (int qi = 0; qi < Q; ++qi) {
        string op;
        cin >> op;
        op = toUpper(op);

        if (op == "INSERT") {
            int x;
            cin >> x;
            depq.insert(x);
        } else if (op == "GETMIN") {
            int v;
            if (depq.getMin(v)) cout << v << "\n";
            else cout << "EMPTY\n";
        } else if (op == "GETMAX") {
            int v;
            if (depq.getMax(v)) cout << v << "\n";
            else cout << "EMPTY\n";
        } else if (op == "DELETEMIN") {
            int v;
            if (depq.deleteMin(v)) cout << v << "\n";
            else cout << "EMPTY\n";
        } else if (op == "DELETEMAX") {
            int v;
            if (depq.deleteMax(v)) cout << v << "\n";
            else cout << "EMPTY\n";
        } else if (op == "UPDATE") {
            int oldVal, newVal;
            cin >> oldVal >> newVal;
            if (depq.updatePriority(oldVal, newVal))
                cout << "OK\n";
            else
                cout << "NOTFOUND\n";
        }
    }

    return 0;
}
