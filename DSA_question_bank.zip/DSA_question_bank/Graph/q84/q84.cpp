#include <bits/stdc++.h>
using namespace std;

/*
    q84 – Construct dual of a planar graph (given embedding by faces)

    Input:
        V E F
        u v f1 f2   (E lines)

      V = #vertices of original graph
      E = #edges
      F = #faces (including outer face)
      Each edge line:
          u, v  : endpoints (0-based, not used for dual construction)
          f1,f2 : face IDs (0-based, [0,F-1]) lying on either side
                   of the edge in the planar embedding.

    Output:
        F E F_dual
        For i = 1..E:
            f1 f2    (dual edge endpoints = faces of original edge i)

      where F_dual is computed from Euler's formula and equals V
      if the embedding is consistent and graph is connected.

    The dual graph:
        - Has one vertex per face (so F vertices).
        - For each original edge separating faces f1 and f2 we create
          a dual edge between f1 and f2 (loop if f1 == f2).
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int V, E, F;
    if (!(cin >> V >> E >> F)) {
        return 0;
    }

    struct EdgeInput {
        int u, v, f1, f2;
    };

    vector<EdgeInput> edges;
    edges.reserve(E);

    for (int i = 0; i < E; ++i) {
        int u, v, f1, f2;
        cin >> u >> v >> f1 >> f2;
        EdgeInput ei;
        ei.u = u;
        ei.v = v;
        ei.f1 = f1;
        ei.f2 = f2;
        edges.push_back(ei);
    }

    // Dual graph:
    // number of vertices = F
    // number of edges    = E
    int V_dual = F;
    int E_dual = E;

    // Number of faces in dual from Euler's formula:
    // V - E + F = 2  (original)
    // Vd - Ed + Fd = 2 (dual), with Vd = F, Ed = E
    // => Fd = 2 - F + E, which should equal original V.
    int F_dual = 2 - V_dual + E_dual;

    // Output counts
    cout << V_dual << " " << E_dual << " " << F_dual << "\n";

    // Output dual edges: one per original edge, between faces f1,f2
    for (int i = 0; i < E; ++i) {
        cout << edges[i].f1 << " " << edges[i].f2 << "\n";
    }

    return 0;
}
