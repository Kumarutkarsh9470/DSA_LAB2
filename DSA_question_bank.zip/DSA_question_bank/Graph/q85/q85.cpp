#include <bits/stdc++.h>
using namespace std;

/*
    q85 – DSU with rollback on last k edge additions.

    We maintain connected components of an undirected graph.

    Operations:
        1 u v  : addEdge(u, v)
        2      : print number of components
        3 k    : rollback(k) - undo last k edge additions

    Implementation:
        - Union-Find (Disjoint Set Union) with union by size.
        - No path compression (to keep rollback simple and correct).
        - A history stack records each *successful* union.
        - For each addEdge() we store a "checkpoint" (history size
          before performing the union). rollback(k) restores DSU
          state to what it was k edge additions ago by rolling
          back to previous checkpoints.

    Complexity:
        - Each union and rollback is O(alpha(N)) (almost constant).
        - Rollback(k) is O(# of unions actually undone) which is ≤ k.
*/

struct Change {
    int child;              // node whose parent changed (the attached root)
    int parent_before;      // its old parent (itself)
    int root;               // main root whose size changed
    int size_root_before;   // size[root] before union
};

struct DSURollback {
    int n;
    vector<int> parent;
    vector<int> sz;
    int components;

    // History of changes for rollback
    vector<Change> history;
    // For each addEdge operation, store history size BEFORE the union.
    vector<int> checkpoints;

    DSURollback(int n_) : n(n_), parent(n_), sz(n_, 1), components(n_) {
        for (int i = 0; i < n; ++i) parent[i] = i;
    }

    int find(int x) {
        // No path compression – important for cheap rollback.
        while (x != parent[x]) x = parent[x];
        return x;
    }

    void addEdge(int u, int v) {
        int before = (int)history.size();
        checkpoints.push_back(before);
        unite(u, v);
    }

    void unite(int u, int v) {
        int ru = find(u);
        int rv = find(v);
        if (ru == rv) return;   // already connected, nothing to log

        if (sz[ru] < sz[rv]) swap(ru, rv);  // ru has larger size

        // Log change: rv gets attached to ru; size[ru] changes
        Change ch;
        ch.child = rv;
        ch.parent_before = parent[rv];      // should be rv
        ch.root = ru;
        ch.size_root_before = sz[ru];
        history.push_back(ch);

        // Apply union
        parent[rv] = ru;
        sz[ru] += sz[rv];
        components--;
    }

    void rollback(int k) {
        // Undo last k addEdge operations
        while (k-- > 0 && !checkpoints.empty()) {
            int targetHistSize = checkpoints.back();
            checkpoints.pop_back();
            rollbackTo(targetHistSize);
        }
    }

    void rollbackTo(int targetHistSize) {
        while ((int)history.size() > targetHistSize) {
            Change ch = history.back();
            history.pop_back();

            // Revert parent and size
            parent[ch.child] = ch.parent_before;
            sz[ch.root] = ch.size_root_before;
            components++;
        }
    }

    int countComponents() const {
        return components;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, Q;
    if (!(cin >> N >> Q)) return 0;

    DSURollback dsu(N);

    while (Q--) {
        int type;
        cin >> type;

        if (type == 1) {
            int u, v;
            cin >> u >> v;
            dsu.addEdge(u, v);
        } else if (type == 2) {
            cout << dsu.countComponents() << "\n";
        } else if (type == 3) {
            int k;
            cin >> k;
            dsu.rollback(k);
        }
    }

    return 0;
}
