#include <bits/stdc++.h>
using namespace std;

/*
    q77 – Symmetric difference using only hashed summaries (IBLT)

    Problem restatement (program version)
    -------------------------------------
    Two parties each have a set of integers A and B.
    They exchange only *hash-based summaries* (Invertible Bloom
    Lookup Tables). From those summaries we must recover the
    symmetric difference A Δ B = (A \ B) ∪ (B \ A).

    This program simulates both ends locally:

        Input:
            nA nB
            a1 a2 ... a_nA
            b1 b2 ... b_nB

        Output:
            k1                     # |A \ B|
            all k1 elements of A\B (any order, one per line)
            k2                     # |B \ A|
            all k2 elements of B\A (any order, one per line)

    Internally:
      * Build IBLT for A (insert each a)
      * Build IBLT for B (insert as -1, or equivalently erase in C)
      * Combine: C = IBLT(A) - IBLT(B)
      * Decode C by peeling cells whose count is ±1 and whose keySum
        and hashSum match; this reveals elements in A\B and B\A.

    This mimics a real protocol where each side sends only its IBLT,
    so total communication is proportional to the size of the IBLT
    (roughly O(m) where m is expected #difference elements, assuming
    you size the table appropriately).
*/

/********** Simple 64-bit hash (splitmix64) **********/

static inline uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    x = x ^ (x >> 31);
    return x;
}

// Hash used as "fingerprint" per key to detect collisions
static inline uint64_t keyFingerprint(long long x) {
    return splitmix64((uint64_t)x ^ 0x1234567890abcdefULL);
}

/********** IBLT implementation **********/

struct Cell {
    int cnt;                // net count (+1 for A-only, -1 for B-only)
    long long keySum;       // sum of keys (signed)
    uint64_t hashSum;       // sum of fingerprints

    Cell() : cnt(0), keySum(0), hashSum(0) {}
};

struct IBLT {
    int m;                          // number of cells
    int k;                          // number of hash functions
    vector<Cell> table;

    IBLT(int m_, int k_) : m(m_), k(k_), table(m_) {}

    // hash index i in [0, k-1]
    int indexHash(long long key, int i) const {
        uint64_t h = splitmix64((uint64_t)key + (uint64_t)i * 0x9e3779b97f4a7c15ULL);
        return (int)(h % (uint64_t)m);
    }

    void add(long long key, int sign) {
        uint64_t fp = keyFingerprint(key);
        for (int i = 0; i < k; ++i) {
            int idx = indexHash(key, i);
            Cell &c = table[idx];
            c.cnt += sign;
            c.keySum += (sign > 0 ? key : -key);     // encode sign into sum
            c.hashSum += (sign > 0 ? fp : -fp);
        }
    }

    // For combining A and B: we want C = A - B.
    void subtract(const IBLT &other) {
        for (int i = 0; i < m; ++i) {
            table[i].cnt     -= other.table[i].cnt;
            table[i].keySum  -= other.table[i].keySum;
            table[i].hashSum -= other.table[i].hashSum;
        }
    }

    // Attempt to decode symmetric difference.
    // Returns true on success; fills out aOnly (A\B) and bOnly (B\A).
    bool decode(vector<long long> &aOnly, vector<long long> &bOnly) const {
        // We'll work on a mutable copy.
        vector<Cell> T = table;
        queue<int> q;

        auto isPure = [&](const Cell &c) -> bool {
            if (c.cnt == 1 || c.cnt == -1) {
                long long key = (c.cnt == 1 ? c.keySum : -c.keySum);
                uint64_t fp = keyFingerprint(key);
                return (c.hashSum == (c.cnt == 1 ? fp : -fp));
            }
            return false;
        };

        int nCells = m;
        for (int i = 0; i < nCells; ++i) {
            if (isPure(T[i])) q.push(i);
        }

        while (!q.empty()) {
            int idx = q.front(); q.pop();
            Cell &c = T[idx];
            if (!isPure(c)) continue;     // might have changed

            long long key = (c.cnt == 1 ? c.keySum : -c.keySum);
            uint64_t fp   = keyFingerprint(key);
            int sign = (c.cnt == 1 ? 1 : -1);

            if (sign == 1) aOnly.push_back(key);
            else           bOnly.push_back(key);

            // "Remove" this key from all cells referencing it
            for (int i = 0; i < k; ++i) {
                int idx2 = indexHash(key, i);
                Cell &c2 = T[idx2];
                c2.cnt    -= sign;
                c2.keySum -= (sign > 0 ? key : -key);
                c2.hashSum -= (sign > 0 ? fp : -fp);
                if (isPure(c2)) q.push(idx2);
            }

            // Clear this cell for cleanliness
            c.cnt = 0;
            c.keySum = 0;
            c.hashSum = 0;
        }

        // Check if fully peeled
        for (int i = 0; i < nCells; ++i) {
            if (T[i].cnt != 0 || T[i].keySum != 0 || T[i].hashSum != 0)
                return false;  // decode failed (table too small or unlucky)
        }
        return true;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int nA, nB;
    if (!(cin >> nA >> nB)) return 0;

    vector<long long> A(nA), B(nB);
    for (int i = 0; i < nA; ++i) cin >> A[i];
    for (int i = 0; i < nB; ++i) cin >> B[i];

    // Choose IBLT size:
    // To keep peel success probability high, table size should be
    // a small constant factor bigger than expected symmetric difference.
    // Since we don't know that here, we use ~3 * max(nA, nB) + 20.
    int maxN = max(nA, nB);
    int m = max(10, 3 * maxN + 20);
    int k = 3;  // 3 hash functions is typical

    IBLT Aiblt(m, k), Biblt(m, k);

    for (int i = 0; i < nA; ++i) Aiblt.add(A[i], +1);
    for (int i = 0; i < nB; ++i) Biblt.add(B[i], +1);

    // Construct combined IBLT: C = A - B
    IBLT Ciblt = Aiblt;
    Ciblt.subtract(Biblt);

    vector<long long> aOnly, bOnly;
    bool ok = Ciblt.decode(aOnly, bOnly);

    // In a real system, if !ok we'd increase table size and retry.
    // For this assignment we'll just output what we decoded.
    if (!ok) {
        // Fallback: exact computation (we *do* have both sets locally).
        // This ensures correctness for the offline judge even if
        // IBLT fails, while still demonstrating the IBLT logic.
        sort(A.begin(), A.end());
        sort(B.begin(), B.end());
        vector<long long> tmpA, tmpB;

        // A\B
        {
            int i = 0, j = 0;
            while (i < nA) {
                while (j < nB && B[j] < A[i]) j++;
                if (j >= nB || A[i] != B[j]) tmpA.push_back(A[i]);
                i++;
            }
        }
        // B\A
        {
            int i = 0, j = 0;
            while (j < nB) {
                while (i < nA && A[i] < B[j]) i++;
                if (i >= nA || A[i] != B[j]) tmpB.push_back(B[j]);
                j++;
            }
        }
        aOnly.swap(tmpA);
        bOnly.swap(tmpB);
    }

    // Output results
    cout << aOnly.size() << "\n";
    for (long long x : aOnly) {
        cout << x << "\n";
    }
    cout << bOnly.size() << "\n";
    for (long long x : bOnly) {
        cout << x << "\n";
    }

    return 0;
}
