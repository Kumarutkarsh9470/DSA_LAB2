#include <bits/stdc++.h>
using namespace std;

/*
    Problem:
      In a BST, find the pair(s) of nodes with minimum absolute difference
      in their values, EXCLUDING any pairs where one node is an ancestor
      of the other. If multiple pairs have the same minimum difference,
      return all such pairs.

    Assumed input format:
        n
        value0 left0 right0
        value1 left1 right1
        ...
        value(n-1) left(n-1) right(n-1)

      * nodes are indexed 0..n-1
      * -1 means "no child"
      * node 0 is the root (BST property holds).

    Output format:
        First line : minimum difference (or -1 if no valid pair exists)
        Second line: number of pairs
        Next lines : each pair as "val1 val2" (val1 <= val2)
*/

struct Node {
    long long val;
    int left;
    int right;
};

vector<Node> tree;
vector<int> tin, tout;
int timerDFS = 0;

void dfs(int u) {
    if (u == -1) return;
    tin[u] = ++timerDFS;
    dfs(tree[u].left);
    dfs(tree[u].right);
    tout[u] = timerDFS;
}

bool isAncestor(int u, int v) {
    // is u ancestor of v ?
    if (u == -1 || v == -1) return false;
    return tin[u] <= tin[v] && tout[u] >= tout[v];
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0) {
        cout << -1 << "\n0\n";
        return 0;
    }

    tree.resize(n);
    for (int i = 0; i < n; ++i) {
        long long v;
        int l, r;
        cin >> v >> l >> r;
        tree[i] = {v, l, r};
    }

    // Precompute in/out times for ancestor checks
    tin.assign(n, 0);
    tout.assign(n, 0);
    timerDFS = 0;
    dfs(0); // root is 0

    // Collect nodes as (value, index) and sort by value
    vector<pair<long long,int>> arr;
    arr.reserve(n);
    for (int i = 0; i < n; ++i) {
        arr.push_back({tree[i].val, i});
    }
    sort(arr.begin(), arr.end()); // sort by value

    long long bestDiff = LLONG_MAX;
    vector<pair<long long,long long>> bestPairs;

    // Check all pairs, but with early break using sorted order
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            long long diff = arr[j].first - arr[i].first;
            if (diff > bestDiff) break;  // later j will only increase diff

            int u = arr[i].second;
            int v = arr[j].second;
            // Skip ancestor–descendant pairs
            if (isAncestor(u, v) || isAncestor(v, u)) continue;

            if (diff < bestDiff) {
                bestDiff = diff;
                bestPairs.clear();
                bestPairs.push_back({arr[i].first, arr[j].first});
            } else if (diff == bestDiff) {
                bestPairs.push_back({arr[i].first, arr[j].first});
            }
        }
    }

    if (bestDiff == LLONG_MAX) {
        // No valid pair
        cout << -1 << "\n0\n";
        return 0;
    }

    cout << bestDiff << "\n";
    cout << bestPairs.size() << "\n";
    for (auto &p : bestPairs) {
        cout << p.first << " " << p.second << "\n";
    }

    return 0;
}
