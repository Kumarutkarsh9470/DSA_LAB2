#include <bits/stdc++.h>
using namespace std;

/*
    q74 – Versioned Hash Table with getValue(key, time)

    We maintain, for each key, a compact history of changes:
        vector<Version> history;
    where each Version is:
        time  : operation index when this key changed
        val   : new value
        alive : whether key exists after this change

    We only append to a key's history when its value actually changes
    (or it gets deleted). So if a key rarely changes, it stores only a
    few versions → space efficient.

    Time is the 1-based index of the operation, i.e. first command has
    time=1, second time=2, etc.

    Operations (input format):

        Q
        Then Q lines, each one of:

        1 key value
            - insert or update key with value
        2 key
            - get current value of key (after this operation)
              print value or -1 if absent
        3 key
            - delete key
        4 key t
            - getValue(key, t) : value associated with key right after
              operation t (1 ≤ t ≤ current operation index)
              print value or -1 if key absent then

    Keys and values are 64-bit integers (long long).
*/

struct Version {
    long long time;   // operation index
    long long val;    // stored value
    bool alive;       // true if key exists after this change
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    unordered_map<long long, vector<Version>> table;
    table.reserve(Q * 2);

    long long curOp = 0;  // current operation index (1-based)

    while (Q--) {
        int type;
        cin >> type;
        ++curOp;

        if (type == 1) {
            // insert / update
            long long key, value;
            cin >> key >> value;
            auto &hist = table[key];

            if (!hist.empty()) {
                Version &last = hist.back();
                if (last.alive && last.val == value) {
                    // no actual change; skip to save space
                    continue;
                }
            }
            hist.push_back({curOp, value, true});
        }

        else if (type == 2) {
            // get current value
            long long key;
            cin >> key;
            auto it = table.find(key);
            if (it == table.end() || it->second.empty()) {
                cout << -1 << "\n";
                continue;
            }
            Version &last = it->second.back();
            if (!last.alive) {
                cout << -1 << "\n";
            } else {
                cout << last.val << "\n";
            }
        }

        else if (type == 3) {
            // delete key
            long long key;
            cin >> key;
            auto &hist = table[key];

            if (!hist.empty() && !hist.back().alive) {
                // already deleted, no change
                continue;
            }
            hist.push_back({curOp, 0, false}); // value unused when !alive
        }

        else if (type == 4) {
            // getValue(key, time)
            long long key, t;
            cin >> key >> t;
            auto it = table.find(key);
            if (it == table.end() || it->second.empty()) {
                cout << -1 << "\n";
                continue;
            }

            const vector<Version> &hist = it->second;
            // find last version with time <= t
            int l = 0, r = (int)hist.size() - 1, best = -1;
            while (l <= r) {
                int mid = (l + r) / 2;
                if (hist[mid].time <= t) {
                    best = mid;
                    l = mid + 1;
                } else {
                    r = mid - 1;
                }
            }

            if (best == -1 || !hist[best].alive) {
                cout << -1 << "\n";
            } else {
                cout << hist[best].val << "\n";
            }
        }
    }

    return 0;
}
