#include <bits/stdc++.h>
using namespace std;

/*
    q34.cpp

    Given N elements (0..N-1) and M constraints (i, j) meaning
    "i must come before j", decide whether there exists an order
    of all elements that respects all constraints.

    We use Kahn's algorithm for topological sorting, driven by a
    queue. If we can output all N elements, a valid ordering exists.
    Otherwise there is a cycle and no valid ordering.

    Input:
        N M
        M lines: i j   (0 <= i, j < N)

    Output:
        If possible:
          YES
          v0 v1 ... v_{N-1}
        Otherwise:
          NO
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    if (!(cin >> N >> M)) {
        return 0;
    }

    vector<vector<int>> adj(N);
    vector<int> indeg(N, 0);

    for (int k = 0; k < M; ++k) {
        int u, v;
        cin >> u >> v;   // u must be before v
        if (u < 0 || u >= N || v < 0 || v >= N) {
            // ignore invalid edges in input, but you could also exit with error
            continue;
        }
        adj[u].push_back(v);
        ++indeg[v];
    }

    // Queue of all currently "free" elements (indegree 0)
    queue<int> q;
    for (int i = 0; i < N; ++i) {
        if (indeg[i] == 0) q.push(i);
    }

    vector<int> order;
    order.reserve(N);

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        order.push_back(u);

        for (int v : adj[u]) {
            if (--indeg[v] == 0) {
                q.push(v);
            }
        }
    }

    if ((int)order.size() != N) {
        // Not all vertices were output => cycle exists
        cout << "NO\n";
    } else {
        cout << "YES\n";
        for (int i = 0; i < N; ++i) {
            if (i) cout << ' ';
            cout << order[i];
        }
        cout << "\n";
    }

    return 0;
}
