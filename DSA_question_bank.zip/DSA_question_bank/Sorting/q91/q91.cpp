#include <bits/stdc++.h>
using namespace std;
// Naive Bubble Sort (baseline)

long long bubbleNaive(vector<int> a) {
 int n = (int)a.size();
long long comps = 0;
for (int i = 0; i < n - 1; ++i) {
for (int j = 0; j < n - 1 - i; ++j) {
    ++comps;
if (a[j] > a[j + 1]) {
     std::swap(a[j], a[j + 1]);
 }
}
}
return comps;
}
// Helpers for enhanced algorithm
// Detect alternating long ascending/descending segments (runs).
// Fills 'runs' with [l,r] indices and 'asc' with direction.
// Returns true iff:
//   - there are at least 2 runs,
//   - we have at least one ascending and one descending run,
//   - average run length >= 3 (i.e. segments are "longish").
// All comparisons done here are counted into 'comps'.
bool detectAlternatingRuns(const vector<int> &a,
vector<pair<int,int> > &runs,
vector<bool> &asc,
long long &comps) {
runs.clear();
asc.clear();
int n = (int)a.size();
if (n < 3) return false;
int i = 0;
while (i < n - 1) {
int j = i;
// Determine direction based on first difference in run
++comps;
bool dirAsc = (a[j + 1] >= a[j]);

if (dirAsc) {
 while (j + 1 < n) {
     ++comps;
 if (a[j + 1] >= a[j]) j++;
 else break;
    }
} else {
  while (j + 1 < n) {
    ++comps;
if (a[j + 1] <= a[j]) j++;
else break;
}
}
runs.push_back(make_pair(i, j));
 asc.push_back(dirAsc);
i = j + 1;
}
bool hasAsc = false, hasDesc = false;
for (size_t k = 0; k < asc.size(); ++k) {
        if (asc[k]) hasAsc = true;
        else hasDesc = true;
    }
    if (!hasAsc || !hasDesc) return false;
    if (runs.size() < 2) return false;

    double avgLen = (double)n / (double)runs.size();
    if (avgLen < 3.0) return false; // runs too short, treat as random

    return true;
}

// Merge two consecutive ascending runs [l1,r1] and [l2,r2].
// Uses 'tmp' as auxiliary array and counts comparisons in 'comps'.
void mergeRuns(vector<int> &a, vector<int> &tmp,
               int l1, int r1, int l2, int r2,
               long long &comps) {
    for (int i = l1; i <= r2; ++i) tmp[i] = a[i];

    int i = l1, j = l2, k = l1;
    while (i <= r1 && j <= r2) {
        ++comps;
        if (tmp[i] <= tmp[j]) a[k++] = tmp[i++];
        else                  a[k++] = tmp[j++];
    }
    while (i <= r1) a[k++] = tmp[i++];
    while (j <= r2) a[k++] = tmp[j++];
}

// Specialized algorithm once we know the array consists of
// alternating ascending/descending segments.
// We:
//   1. Reverse descending runs to make them ascending.
//   2. Perform a "natural mergesort" on the runs.
void specializedRunSort(vector<int> &a,
                        const vector<pair<int,int> > &runs,
                        const vector<bool> &asc,
                        long long &comps) {
    int n = (int)a.size();
    if (n <= 1) return;

    // Step 1: make every run ascending
    for (size_t idx = 0; idx < runs.size(); ++idx) {
        if (!asc[idx]) {
     int l = runs[idx].first;
    int r = runs[idx].second;
            while (l < r) {
     std::swap(a[l], a[r]);
     ++l; --r;
            }
        }
    }
    // Step 2: merge runs until only one remains
    vector<pair<int,int> > currentRuns = runs;
    vector<int> tmp(n);
while (currentRuns.size() > 1) {
     vector<pair<int,int> > nextRuns;
     for (size_t i = 0; i < currentRuns.size(); i += 2) {
    if (i + 1 == currentRuns.size()) {
       nextRuns.push_back(currentRuns[i]);
     } else {
    int l1 = currentRuns[i].first;
    int r1 = currentRuns[i].second;
         int l2 = currentRuns[i + 1].first;
    int r2 = currentRuns[i + 1].second;
    mergeRuns(a, tmp, l1, r1, l2, r2, comps);
        nextRuns.push_back(make_pair(l1, r2));
            }
        }
        currentRuns.swap(nextRuns);
    }
}
// Enhanced Bubble Sort

long long bubbleEnhanced(vector<int> a) {
long long comps = 0;

// First, see if the array is composed of long alternating
 // ascending/descending segments. If yes, switch to run-based sort.
vector<pair<int,int> > runs;
vector<bool> asc;
if (detectAlternatingRuns(a, runs, asc, comps)) {
specializedRunSort(a, runs, asc, comps);
return comps;
}
int n = (int)a.size();
int newn;
do {
newn = 0;
for (int i = 1; i < n; ++i) {
++comps;
if (a[i - 1] > a[i]) {
std::swap(a[i - 1], a[i]);
newn = i;  // last index where a swap occurred
}
}
n = newn;
} while (n > 1);
return comps;
}
// Experiment driver

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    const int NUM_DATASETS = 100;
    const int N = 100;             
    const int MIN_VAL = -1000;
    const int MAX_VAL = 1000;

    mt19937 rng(123456);             
    uniform_int_distribution<int> distVal(MIN_VAL, MAX_VAL);

    long long totalNaive = 0;
    long long totalEnhanced = 0;

    for (int d = 0; d < NUM_DATASETS; ++d) {
        vector<int> arr(N);
        for (int i = 0; i < N; ++i) {
            arr[i] = distVal(rng);
        }

        totalNaive    += bubbleNaive(arr);
        totalEnhanced += bubbleEnhanced(arr);
    }

    cout << "Datasets: " << NUM_DATASETS << "\n";
    cout << "Array size each: " << N << "\n\n";

    cout << "Naive Bubble Sort comparisons:    " << totalNaive << "\n";
    cout << "Enhanced Bubble Sort comparisons: " << totalEnhanced << "\n";
    cout << "Comparisons saved:                "
         << (totalNaive - totalEnhanced) << "\n";

    return 0;
}
