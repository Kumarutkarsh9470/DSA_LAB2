#include <bits/stdc++.h>
using namespace std;

/*
    Problem interpretation

    We are given a nested list in a bracketed form, e.g.

        [1,[2,[3,4]],5]

    Depth starts at 1 for elements directly inside the outermost list.
    Normally, each integer at depth d contributes:    value * d.

    However, *inside a given list (branch)*, whenever we encounter a
    **negative** number, we reverse the "weight direction" for the rest of
    that list: all following elements in that same list are multiplied by
    -1 with respect to their usual depth-based weight.  (A second negative
    number flips it back, etc.)

    The computation must be done using an explicit stack – no recursion.

    Input  (assumed):

        A single line containing the nested list, for example:
        [1,[2,[3,4]],5]

        Numbers may be positive or negative and separated by commas and/or
        spaces. Only characters used are '[', ']', ',', ' ', '-', digits.

    Output:

        A single integer: the weighted sum.

    Approach:

        We parse the string once left-to-right.

        Stack frame:
            depth      – depth of this list (all elements directly inside)
            signFactor – +1 or -1, multiplier applied to all *remaining*
                        elements in this list; it can flip when a negative
                        number is seen in this list.

        Algorithm:

            - Push a dummy frame: depth = 0, signFactor = +1.
            - On '[' : create a new frame with:
                      depth = parent.depth + 1,
                      signFactor = parent.signFactor
                      push it.
            - On ']' : pop the current frame.
            - On reading an integer value v at current depth d and with
              signFactor s:
                      contribution = v * d * s
              If v < 0, then flip signFactor of *current* frame:
                      s *= -1   (applies to following elements in this list).
*/

struct Frame {
    int depth;
    int signFactor;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    if (!getline(cin, s)) return 0;

    long long result = 0;

    stack<Frame> st;
    st.push({0, 1}); // dummy outer frame

    const int n = (int)s.size();
    int i = 0;

    while (i < n) {
        char c = s[i];

        if (c == '[') {
            Frame parent = st.top();
            st.push({parent.depth + 1, parent.signFactor});
            ++i;
        } else if (c == ']') {
            if (!st.empty()) st.pop();
            ++i;
        } else if (c == ',' || isspace(static_cast<unsigned char>(c))) {
            ++i; // ignore separators and spaces
        } else { // number (possibly negative)
            int sign = 1;
            if (c == '-') {
                sign = -1;
                ++i;
            }
            long long val = 0;
            bool hasDigit = false;
            while (i < n && isdigit(static_cast<unsigned char>(s[i]))) {
                hasDigit = true;
                val = val * 10 + (s[i] - '0');
                ++i;
            }
            if (!hasDigit) continue; // malformed, but we just skip

            val *= sign;

            if (st.empty()) {
                cerr << "Malformed input: value outside of any list\n";
                return 1;
            }

            Frame &frame = st.top();
            long long contribution = val * 1LL * frame.depth * frame.signFactor;
            result += contribution;

            if (val < 0) {
                frame.signFactor *= -1; // reverse weight direction
            }
        }
    }

    cout << result << "\n";
    return 0;
}
