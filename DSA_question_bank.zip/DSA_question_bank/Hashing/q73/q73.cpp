#include <bits/stdc++.h>
using namespace std;

/*
    q73 – Hash table for 3D points with Manhattan-radius range queries.

    Supported operations (input format):

        Q
        Then Q lines, each one is:

        1 x y z           -> insert point (x,y,z)
        2 x y z           -> delete point (x,y,z) if it exists
        3 x y z           -> exact lookup: print 1 if present, else 0
        4 x y z D         -> range query:
                               all points p with
                                   |px - x| + |py - y| + |pz - z| <= D
                             Output:
                               K           (number of points)
                               then K lines "px py pz" (any order)

    Internals:

      - We use an unordered_set of Point with a custom hash.
      - For a range query centered at (cx, cy, cz) with radius D,
        we enumerate all integer lattice points within that
        Manhattan ball:

            for dx from -D .. D:
                rem1 = D - |dx|
                for dy from -rem1 .. rem1:
                    rem2 = rem1 - |dy|
                    for dz from -rem2 .. rem2:
                        candidate = (cx+dx, cy+dy, cz+dz)

        and check membership in the hash set (O(1) expected).

      - This visits exactly the points with L1-distance <= D.
        Complexity is Θ(D³), which is optimal when we must
        output all such points.

*/

struct Point {
    long long x, y, z;

    bool operator==(const Point& other) const {
        return x == other.x && y == other.y && z == other.z;
    }
};

struct PointHash {
    size_t operator()(const Point& p) const noexcept {
        // Simple 64-bit mix of three coordinates
        uint64_t h = 1469598103934665603ull; // FNV offset basis
        auto mix = [&](long long v) {
            uint64_t x = (uint64_t)v ^ 0x8000000000000000ull;
            h ^= x;
            h *= 1099511628211ull; // FNV prime
        };
        mix(p.x);
        mix(p.y);
        mix(p.z);
        return (size_t)h;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    unordered_set<Point, PointHash> S;
    S.reserve(Q * 2);

    while (Q--) {
        int type;
        cin >> type;

        if (type == 1) {          // insert
            long long x, y, z;
            cin >> x >> y >> z;
            S.insert({x, y, z});
        }
        else if (type == 2) {     // delete
            long long x, y, z;
            cin >> x >> y >> z;
            auto it = S.find({x, y, z});
            if (it != S.end()) S.erase(it);
        }
        else if (type == 3) {     // exact lookup
            long long x, y, z;
            cin >> x >> y >> z;
            cout << (S.find({x, y, z}) != S.end() ? 1 : 0) << "\n";
        }
        else if (type == 4) {     // range query (Manhattan ball)
            long long cx, cy, cz, D;
            cin >> cx >> cy >> cz >> D;

            vector<Point> ans;

            for (long long dx = -D; dx <= D; ++dx) {
                long long rem1 = D - llabs(dx);
                for (long long dy = -rem1; dy <= rem1; ++dy) {
                    long long rem2 = rem1 - llabs(dy);
                    for (long long dz = -rem2; dz <= rem2; ++dz) {
                        Point p{cx + dx, cy + dy, cz + dz};
                        auto it = S.find(p);
                        if (it != S.end()) {
                            ans.push_back(*it);
                        }
                    }
                }
            }

            cout << ans.size() << "\n";
            for (const auto& p : ans) {
                cout << p.x << " " << p.y << " " << p.z << "\n";
            }
        }
    }

    return 0;
}
