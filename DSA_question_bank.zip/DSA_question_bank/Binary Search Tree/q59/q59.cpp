#include <bits/stdc++.h>
using namespace std;

/*
    Problem (q59):

    In a BST, find all pairs of nodes whose values sum to a target T,
    with the extra constraint that the length of the path between the
    two nodes in the tree (number of edges) is <= K.

    Return (print) all such pairs.

    ----------------------------------------------------------------
    Assumed input format:

        n
        value0 left0 right0
        value1 left1 right1
        ...
        value(n-1) left(n-1) right(n-1)
        T K

      * Nodes are indexed 0..n-1.
      * -1 means "no child".
      * Node 0 is the root and the tree satisfies BST property.
      * value_i can be any (possibly negative) long long.
      * T is the target sum (long long).
      * K is the maximum allowed path length (int).

    Output format:

        P
        v1a v1b
        v2a v2b
        ...
        vPa vPb

      * P = number of valid pairs.
      * Each line after that is one pair of values (va, vb) with va <= vb.
      * Each pair corresponds to a distinct pair of nodes (i != j, i < j).
*/

struct Node {
    long long val;
    int left;
    int right;
};

const int LOG = 20;   // enough for up to ~1e6 nodes

vector<Node> tree;
vector<int> depthArr;
vector< vector<int> > up; // binary lifting table

// DFS to fill depth and 1st parent (up[v][0])
void dfs_build(int u, int parent) {
    up[u][0] = parent;
    if (parent == -1) depthArr[u] = 0;
    else depthArr[u] = depthArr[parent] + 1;

    if (tree[u].left != -1)  dfs_build(tree[u].left,  u);
    if (tree[u].right != -1) dfs_build(tree[u].right, u);
}

int lca(int a, int b) {
    if (a == -1 || b == -1) return -1;
    if (depthArr[a] < depthArr[b]) swap(a, b);

    int diff = depthArr[a] - depthArr[b];
    for (int j = LOG - 1; j >= 0; --j) {
        if ((diff >> j) & 1) {
            a = up[a][j];
        }
    }

    if (a == b) return a;

    for (int j = LOG - 1; j >= 0; --j) {
        if (up[a][j] != -1 && up[a][j] != up[b][j]) {
            a = up[a][j];
            b = up[b][j];
        }
    }
    return up[a][0];
}

int dist_nodes(int u, int v) {
    int c = lca(u, v);
    if (c == -1) return INT_MAX;
    return depthArr[u] + depthArr[v] - 2 * depthArr[c];
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0) {
        cout << 0 << "\n";
        return 0;
    }

    tree.resize(n);
    for (int i = 0; i < n; ++i) {
        long long v;
        int l, r;
        cin >> v >> l >> r;
        tree[i].val = v;
        tree[i].left = l;
        tree[i].right = r;
    }

    long long T;
    int K;
    cin >> T >> K;

    // --- Build LCA infrastructure ---
    depthArr.assign(n, 0);
    up.assign(n, vector<int>(LOG, -1));

    int root = 0;
    dfs_build(root, -1);

    // fill higher ancestors
    for (int j = 1; j < LOG; ++j) {
        for (int v = 0; v < n; ++v) {
            int mid = up[v][j-1];
            if (mid != -1) up[v][j] = up[mid][j-1];
        }
    }

    // --- Inorder traversal -> sorted by value (BST property) ---
    vector< pair<long long,int> > arr; // (value, index)
    arr.reserve(n);

    // iterative inorder to avoid recursion depth issues
    vector<int> st;
    int cur = root;
    while (cur != -1 || !st.empty()) {
        while (cur != -1) {
            st.push_back(cur);
            cur = tree[cur].left;
        }
        cur = st.back(); st.pop_back();
        arr.push_back(make_pair(tree[cur].val, cur));
        cur = tree[cur].right;
    }

    // At this point arr is already sorted by value because it's inorder of BST.
    // (If tree might not be a valid BST, we could sort(arr.begin(), arr.end()).)

    // --- Two-pointer over sorted values to find all value-sum pairs ---
    int i = 0;
    int j = (int)arr.size() - 1;

    vector< pair<long long,long long> > result;

    while (i < j) {
        long long a = arr[i].first;
        long long b = arr[j].first;
        long long sum = a + b;

        if (sum < T) {
            ++i;
        } else if (sum > T) {
            --j;
        } else {
            // sum == T, handle duplicates around i and j
            int i2 = i;
            while (i2 + 1 <= j && arr[i2 + 1].first == a) ++i2;
            int j2 = j;
            while (j2 - 1 >= i && arr[j2 - 1].first == b) --j2;

            if (a != b) {
                // values different: [i..i2] x [j2..j]
                for (int p = i; p <= i2; ++p) {
                    int u = arr[p].second;
                    for (int q = j2; q <= j; ++q) {
                        int v = arr[q].second;
                        int dist = dist_nodes(u, v);
                        if (dist <= K) {
                            long long va = arr[p].first;
                            long long vb = arr[q].first;
                            if (va <= vb) result.push_back(make_pair(va, vb));
                            else          result.push_back(make_pair(vb, va));
                        }
                    }
                }
            } else {
                // a == b and T == 2*a. All indices in [i..j] share same value.
                for (int p = i; p <= j; ++p) {
                    int u = arr[p].second;
                    for (int q = p + 1; q <= j; ++q) {
                        int v = arr[q].second;
                        int dist = dist_nodes(u, v);
                        if (dist <= K) {
                            long long va = arr[p].first;
                            long long vb = arr[q].first;
                            if (va <= vb) result.push_back(make_pair(va, vb));
                            else          result.push_back(make_pair(vb, va));
                        }
                    }
                }
            }

            i = i2 + 1;
            j = j2 - 1;
        }
    }

    // Output
    cout << (int)result.size() << "\n";
    for (size_t idx = 0; idx < result.size(); ++idx) {
        cout << result[idx].first << " " << result[idx].second << "\n";
    }

    return 0;
}
