#include <bits/stdc++.h>
using namespace std;

/*
    q55.cpp

    Given an "incomplete" inorder traversal of a BST
    (some positions marked as -1 = unknown key),
    reconstruct ALL possible BSTs consistent with this traversal.

    Interpretation used:
      - We have N inorder slots, each slot definitely corresponds to a node.
      - Slot i (0-based) has a known key A[i] (any integer) or A[i] == -1,
        meaning "there is a node here, but its key is not fixed".
      - The inorder *order* of nodes is fixed by these slots.
      - A BST is consistent if:
            • its inorder traversal visits nodes in exactly these N slots,
            • nodes whose slots have known values get those values.

      Since we can always pick actual numeric keys for unknown positions to
      preserve non-decreasing order, consistency only requires that the
      known values in A[] are already non-decreasing left to right.

    Under that assumption, the number of consistent BSTs equals the number
    of distinct BST shapes with N nodes, which is the Catalan number C_N.

    We generate all such shapes recursively and label each node with its
    inorder index i, then map that index to the given value A[i].

    Input
    -----
        N
        a0 a1 ... a{N-1}
        (ai is integer; ai == -1 means "unknown value")

    Output
    ------
        T
        (number of BSTs consistent with the traversal)

        Then T lines follow.
        For each tree:
            preorder traversal of node values (space separated)

        Unknown values (-1) are printed as -1.

    NOTE: This is exponential in N (Catalan growth). Intended for small N
    (e.g., N <= 10 or so).
*/

struct Node {
    int idx;            // inorder index
    Node *left, *right;

    Node(int i) : idx(i), left(NULL), right(NULL) {}
};

// Build all BST shapes that use inorder indices [l, r]
vector<Node*> build(int l, int r) {
    vector<Node*> res;
    if (l > r) {
        res.push_back(NULL);
        return res;
    }

    for (int i = l; i <= r; ++i) {
        vector<Node*> leftTrees  = build(l, i - 1);
        vector<Node*> rightTrees = build(i + 1, r);

        for (size_t li = 0; li < leftTrees.size(); ++li) {
            for (size_t ri = 0; ri < rightTrees.size(); ++ri) {
                Node* root = new Node(i);
                root->left  = leftTrees[li];
                root->right = rightTrees[ri];
                res.push_back(root);
            }
        }
    }
    return res;
}

// Preorder traversal collecting values
void preorder(Node* root, const vector<long long>& vals, vector<long long>& out) {
    if (!root) return;
    out.push_back(vals[root->idx]);
    preorder(root->left, vals, out);
    preorder(root->right, vals, out);
}

// Clean up dynamically allocated trees
void destroy(Node* root) {
    if (!root) return;
    destroy(root->left);
    destroy(root->right);
    delete root;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;

    vector<long long> A(N);
    for (int i = 0; i < N; ++i) cin >> A[i];

    // Check that known values are non-decreasing
    bool ok = true;
    long long last = LLONG_MIN;
    bool hasLast = false;
    for (int i = 0; i < N; ++i) {
        if (A[i] == -1) continue;  // unknown, ignore in order check
        if (hasLast && A[i] < last) {
            ok = false;
            break;
        }
        last = A[i];
        hasLast = true;
    }

    if (!ok) {
        cout << 0 << "\n";
        return 0;
    }

    if (N == 0) {
        cout << 0 << "\n";
        return 0;
    }

    vector<Node*> trees = build(0, N - 1);
    cout << trees.size() << "\n";

    for (size_t ti = 0; ti < trees.size(); ++ti) {
        vector<long long> out;
        preorder(trees[ti], A, out);
        for (size_t i = 0; i < out.size(); ++i) {
            if (i) cout << ' ';
            cout << out[i];
        }
        cout << "\n";
    }

    // free memory
    for (size_t ti = 0; ti < trees.size(); ++ti) {
        destroy(trees[ti]);
    }

    return 0;
}
