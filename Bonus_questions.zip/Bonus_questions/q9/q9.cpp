#include <bits/stdc++.h>
using namespace std;

/*
    q9 – Matrix-chain multiplication with restricted adjacent pairs.

    Input:
        n
        p0 p1 ... pn          (n+1 integers: dimensions)
        r
        i1 i2 ... ir          (indices 1..n-1; pair (Ai, Ai+1) forbidden)

    Output:
        If possible:
            minimal scalar multiplication cost
            one optimal parenthesization (e.g. ((A1A2)A3))
        Else:
            IMPOSSIBLE
*/

const long long INF = (long long)4e18;

string buildParen(int i, int j, const vector<vector<int> > &split) {
    if (i == j) {
        return "A" + to_string(i);
    }
    int k = split[i][j];
    if (k == -1) {
        // Should not happen if DP is correct, but handle gracefully.
        return "A" + to_string(i) + "...A" + to_string(j);
    }
    string left  = buildParen(i, k, split);
    string right = buildParen(k + 1, j, split);
    return "(" + left + right + ")";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    vector<long long> p(n + 1);
    for (int i = 0; i <= n; ++i) cin >> p[i];

    int r;
    cin >> r;
    vector<bool> forbidden(n + 1, false); // forbidden[i] => (Ai, Ai+1) not allowed as direct pair
    for (int k = 0; k < r; ++k) {
        int idx;
        cin >> idx;
        if (idx >= 1 && idx <= n - 1) {
            forbidden[idx] = true;
        }
    }

    // dp[i][j] = minimal cost to multiply Ai..Aj
    // split[i][j] = k giving optimal split between Ai..Ak and A(k+1)..Aj
    vector<vector<long long> > dp(n + 1, vector<long long>(n + 1, INF));
    vector<vector<int> > split(n + 1, vector<int>(n + 1, -1));

    for (int i = 1; i <= n; ++i) dp[i][i] = 0;

    for (int len = 2; len <= n; ++len) {
        for (int i = 1; i + len - 1 <= n; ++i) {
            int j = i + len - 1;
            long long best = INF;
            int bestK = -1;

            for (int k = i; k < j; ++k) {
                // If this is a direct pair (Ai, Ai+1) and it's forbidden,
                // we forbid this split when len == 2, i.e., i == k and j == i+1.
                if (len == 2 && k == i && forbidden[i]) {
                    continue;
                }

                if (dp[i][k] == INF || dp[k + 1][j] == INF) continue;

                long long cost = dp[i][k] + dp[k + 1][j] + p[i - 1] * p[k] * p[j];
                if (cost < best) {
                    best = cost;
                    bestK = k;
                }
            }

            dp[i][j] = best;
            split[i][j] = bestK;
        }
    }

    if (dp[1][n] == INF) {
        cout << "IMPOSSIBLE\n";
        return 0;
    }

    cout << dp[1][n] << "\n";
    cout << buildParen(1, n, split) << "\n";

    return 0;
}
