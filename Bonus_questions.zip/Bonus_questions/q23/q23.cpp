#include <bits/stdc++.h>
using namespace std;

/*
    Problem:
    Given a histogram, find the maximum rectangle area such that
      - the rectangle spans at least K consecutive bars
      - the rectangle's height is at least H
    Use a stack-based (O(N)) approach.

    Assumed input format:

        N K H
        h0 h1 ... h{N-1}

    Output:

        maxArea          (0 if no valid rectangle exists)

    Approach:
    1. Any rectangle with height >= H must only use bars whose height >= H.
       So we transform the histogram:
           h'[i] = h[i] if h[i] >= H, else 0
    2. Now every contiguous stretch of h'[i] > 0 corresponds to bars where
       height >= H in the original.
    3. Run the standard "largest rectangle in histogram" algorithm on h',
       but:
           - we ignore candidate rectangles whose width < K.
    4. This yields the max area satisfying both width ≥ K and height ≥ H.
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    long long K, H;
    if (!(cin >> N >> K >> H)) return 0;

    vector<long long> h(N + 2, 0); // +2 for sentinel zeros at both ends
    for (int i = 1; i <= N; ++i) {
        long long x;
        cin >> x;
        h[i] = (x >= H ? x : 0);   // zero-out bars shorter than H
    }
    // h[0] and h[N+1] are already 0 (sentinels)

    stack<int> st;
    st.push(0); // index of left sentinel
    long long maxArea = 0;

    for (int i = 1; i <= N + 1; ++i) {
        // Maintain increasing stack of heights
        while (!st.empty() && h[i] < h[st.top()]) {
            int top = st.top();
            st.pop();
            long long height = h[top];
            if (height == 0) continue;  // can't form valid rectangle

            int leftIndex = st.top();   // index of previous smaller bar
            int width = i - leftIndex - 1;

            if (width >= K && height >= H) {
                long long area = height * 1LL * width;
                if (area > maxArea) maxArea = area;
            }
        }
        st.push(i);
    }

    cout << maxArea << '\n';
    return 0;
}
