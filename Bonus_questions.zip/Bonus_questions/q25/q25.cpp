#include <bits/stdc++.h>
using namespace std;

/*
    Sort a stack using only one additional stack and O(1) extra space
    (aside from that helper stack).

    Then:
      - restore it to original order
      - sort it again using the opposite comparison

    Assumed input format:

        N
        a1 a2 ... aN

    a1 is the bottom of the stack, aN is the top.
    Output:

        First line : elements of stack (top -> bottom) after ascending sort
        Second line: elements of stack (top -> bottom) after descending sort
*/

void sortStack(stack<int> &st, bool ascending) {
    stack<int> aux;

    while (!st.empty()) {
        int cur = st.top();
        st.pop();

        // Place cur into aux such that aux stays sorted
        while (!aux.empty() &&
               (ascending ? aux.top() > cur : aux.top() < cur)) {
            st.push(aux.top());
            aux.pop();
        }
        aux.push(cur);
    }

    // Move back to original stack; this keeps required order
    while (!aux.empty()) {
        st.push(aux.top());
        aux.pop();
    }
}

void printStack(const stack<int> &st) {
    stack<int> tmp = st;          // safe copy just for printing
    bool first = true;
    while (!tmp.empty()) {
        if (!first) cout << ' ';
        first = false;
        cout << tmp.top();
        tmp.pop();
    }
    cout << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;

    vector<int> original(N);
    for (int i = 0; i < N; ++i) cin >> original[i];

    // Build initial stack: a1 bottom ... aN top
    stack<int> st;
    for (int x : original) st.push(x);

    // 1) Sort ascending using one extra stack
    sortStack(st, /*ascending=*/true);
    printStack(st);

    // 2) Restore original order (using the saved array, not extra stacks)
    while (!st.empty()) st.pop();
    for (int x : original) st.push(x);

    // 3) Sort again with different comparison (descending)
    sortStack(st, /*ascending=*/false);
    printStack(st);

    return 0;
}
