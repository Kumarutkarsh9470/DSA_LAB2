#include <bits/stdc++.h>
using namespace std;

/*
    q46 – Compressed serialization of a binary tree.

    Encoding format (token stream):

      N
        -> null

      P <size> v1 v2 ... v<size>
        -> perfect (complete) binary subtree of `size` nodes.
           Structure is implicit: nodes are in level-order.

      I <value> <left-subtree> <right-subtree>
        -> irregular node (subtree not perfect).
           `value` is the node's value; children are serialized
           recursively with the same grammar.

    Input format:

        n
        value0 left0 right0
        value1 left1 right1
        ...
        value(n-1) left(n-1) right(n-1)

        * 0-based indexing, -1 for no child, node 0 is root.

    Output:

        m
        token_1 token_2 ... token_m
*/

struct NodeIdx {
    long long val;
    int left;
    int right;
};

vector<NodeIdx> tree;

// Per-node subtree info
vector<int> subSize;
vector<int> subHeight;
vector<char> isPerfectSub;

// ---------- 1. Analyze subtrees to find perfect ones ----------

tuple<int,int,bool> dfs_info(int u) {
    if (u == -1) {
        // size = 0, height = 0, perfect
        return make_tuple(0, 0, true);
    }

    int lsz, lh, rsz, rh;
    bool lp, rp;

    // left child
    {
        tuple<int,int,bool> t = dfs_info(tree[u].left);
        lsz = get<0>(t);
        lh  = get<1>(t);
        lp  = get<2>(t);
    }

    // right child
    {
        tuple<int,int,bool> t = dfs_info(tree[u].right);
        rsz = get<0>(t);
        rh  = get<1>(t);
        rp  = get<2>(t);
    }

    int h = 1 + max(lh, rh);
    int sz = 1 + lsz + rsz;

    bool perfect = lp && rp && (lh == rh);
    if (perfect) {
        long long expected = (1LL << h) - 1; // size of perfect tree height h
        if ((long long)sz != expected) perfect = false;
    }

    subSize[u] = sz;
    subHeight[u] = h;
    isPerfectSub[u] = perfect ? 1 : 0;

    return make_tuple(sz, h, perfect);
}

// ---------- 2. Encoding ----------

vector<string> tokens;

void collect_level_order(int root, int expectedSize, vector<long long> &vals) {
    queue<int> q;
    q.push(root);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        vals.push_back(tree[u].val);
        if (tree[u].left != -1) q.push(tree[u].left);
        if (tree[u].right != -1) q.push(tree[u].right);
    }
    (void)expectedSize; // for debug, not strictly needed
}

void encode(int u) {
    if (u == -1) {
        tokens.push_back("N");
        return;
    }

    if (isPerfectSub[u]) {
        int sz = subSize[u];
        tokens.push_back("P");
        tokens.push_back(to_string(sz));

        vector<long long> vals;
        vals.reserve(sz);
        collect_level_order(u, sz, vals);

        for (size_t i = 0; i < vals.size(); ++i) {
            tokens.push_back(to_string(vals[i]));
        }
        return;
    }

    // Irregular node
    tokens.push_back("I");
    tokens.push_back(to_string(tree[u].val));
    encode(tree[u].left);
    encode(tree[u].right);
}

// ---------- 3. Decoding (pointer-based tree, for completeness) ----------

struct TreeNode {
    long long val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(long long v) : val(v), left(NULL), right(NULL) {}
};

TreeNode* decode_rec(const vector<string> &tok, int &pos) {
    if (pos >= (int)tok.size()) return NULL;

    string t = tok[pos++];

    if (t == "N") {
        return NULL;
    } else if (t == "I") {
        long long v = atoll(tok[pos++].c_str());
        TreeNode *root = new TreeNode(v);
        root->left  = decode_rec(tok, pos);
        root->right = decode_rec(tok, pos);
        return root;
    } else if (t == "P") {
        int sz = atoi(tok[pos++].c_str());
        vector<long long> vals(sz);
        for (int i = 0; i < sz; ++i) {
            vals[i] = atoll(tok[pos++].c_str());
        }
        if (sz == 0) return NULL;

        vector<TreeNode*> nodes(sz, NULL);
        for (int i = 0; i < sz; ++i) {
            nodes[i] = new TreeNode(vals[i]);
        }
        for (int i = 0; i < sz; ++i) {
            int l = 2 * i + 1;
            int r = 2 * i + 2;
            if (l < sz) nodes[i]->left = nodes[l];
            if (r < sz) nodes[i]->right = nodes[r];
        }
        return nodes[0];
    } else {
        return NULL; // malformed
    }
}

// ---------- 4. Main ----------

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    if (!(cin >> n) || n <= 0) return 0;

    tree.resize(n);
    for (int i = 0; i < n; ++i) {
        long long v;
        int l, r;
        cin >> v >> l >> r;
        tree[i] = (NodeIdx){v, l, r};
    }

    subSize.assign(n, 0);
    subHeight.assign(n, 0);
    isPerfectSub.assign(n, 0);

    dfs_info(0);      // fill metadata
    encode(0);        // produce token stream

    cout << tokens.size() << "\n";
    for (size_t i = 0; i < tokens.size(); ++i) {
        if (i) cout << ' ';
        cout << tokens[i];
    }
    cout << "\n";

    return 0;
}
