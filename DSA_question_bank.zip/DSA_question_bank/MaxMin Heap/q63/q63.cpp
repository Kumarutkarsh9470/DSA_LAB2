#include <bits/stdc++.h>
using namespace std;

/*
   q63: Max-Heap with Range-Add (i,j,delta) via Lazy Propagation

   Implement with **implicit max-treap**:
       - Treap node position = index in heap array
       - Stores:
            val  = heap element
            prior = random priority
            sz    = subtree size
            mx    = subtree maximum value
            add   = lazy propagation (delta to be applied)
       - Supports:
            insert(x)        O(log n)
            extractMax()     O(log n)
            addToRange(i,j,d)  O(log n)
*/

struct Node {
    long long val;      // value stored
    long long mx;       // subtree max
    long long add;      // lazy add
    int sz;             // subtree size
    int prior;          // heap priority
    Node *l, *r;

    Node(long long v) {
        val = v;
        mx = v;
        add = 0;
        sz = 1;
        prior = (rand() << 16) ^ rand();
        l = r = nullptr;
    }
};

int getsz(Node* t) { return t ? t->sz : 0; }
long long getmx(Node* t) { return t ? t->mx : LLONG_MIN; }

void push(Node* t) {
    if (!t || t->add == 0) return;

    t->val += t->add;
    t->mx += t->add;

    if (t->l) t->l->add += t->add;
    if (t->r) t->r->add += t->add;

    t->add = 0;
}

void pull(Node* t) {
    if (!t) return;
    push(t->l);
    push(t->r);
    t->sz = 1 + getsz(t->l) + getsz(t->r);
    t->mx = max(t->val, max(getmx(t->l), getmx(t->r)));
}

/*
   Implicit treap indexed by position.
   split(t, a, b, k):
        left subtree size = k
*/
void split(Node* t, Node*& a, Node*& b, int k) {
    if (!t) { a = b = nullptr; return; }
    push(t);

    int leftSize = getsz(t->l);
    if (leftSize >= k) {
        split(t->l, a, t->l, k);
        b = t;
    } else {
        split(t->r, t->r, b, k - leftSize - 1);
        a = t;
    }
    pull(t);
}

Node* merge(Node* a, Node* b) {
    if (!a) return b;
    if (!b) return a;

    push(a);
    push(b);

    if (a->prior > b->prior) {
        a->r = merge(a->r, b);
        pull(a);
        return a;
    } else {
        b->l = merge(a, b->l);
        pull(b);
        return b;
    }
}

/*
   Insert x at end → position = size+1
*/
Node* insert(Node* root, long long x) {
    Node *L, *R;
    split(root, L, R, getsz(root));
    Node* n = new Node(x);
    return merge(merge(L, n), R);
}

/*
   extractMax: we need to find the max in the treap, delete it, return it.

   Find max by descending into subtree with max value.
*/
long long extractMax(Node*& t) {
    if (!t) return LLONG_MIN;
    push(t);

    long long leftMax = getmx(t->l);
    long long rightMax = getmx(t->r);

    if (t->val >= leftMax && t->val >= rightMax) {
        // remove this root
        long long res = t->val;
        Node* tmp = merge(t->l, t->r);
        delete t;
        t = tmp;
        return res;
    }

    if (leftMax >= rightMax) {
        long long ans = extractMax(t->l);
        pull(t);
        return ans;
    } else {
        long long ans = extractMax(t->r);
        pull(t);
        return ans;
    }
}

/*
   addToRange(i, j, delta):
       - split into A | B | C
         B = range [i, j]
*/
Node* addToRange(Node* root, int i, int j, long long delta) {
    Node *A, *B, *C;
    split(root, A, B, i - 1);
    split(B, B, C, j - i + 1);

    if (B) B->add += delta;

    return merge(merge(A, B), C);
}

/*
   Debug optional: inorder traversal
*/

// Input format:
// Q
// operations:
// 1 x → insert x
// 2   → extractMax → print value or -1 if empty
// 3 i j d → addToRange(i,j,d)
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    srand(time(NULL));

    int Q;
    cin >> Q;

    Node* root = nullptr;

    while (Q--) {
        int type;
        cin >> type;

        if (type == 1) {
            long long x;
            cin >> x;
            root = insert(root, x);
        }

        else if (type == 2) {
            if (!root) {
                cout << -1 << "\n";
            } else {
                long long ans = extractMax(root);
                cout << ans << "\n";
            }
        }

        else if (type == 3) {
            int i, j;
            long long d;
            cin >> i >> j >> d;
            if (i > j) swap(i, j);
            root = addToRange(root, i, j, d);
        }
    }

    return 0;
}
