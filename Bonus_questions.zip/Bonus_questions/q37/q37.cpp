#include <bits/stdc++.h>
using namespace std;

/*
    N queues represent different job types.
    Each job has:
        - type (queue index)      : 0 .. N-1
        - processing time p
        - deadline d

    Switching from a job of type A to a job of type B (A != B) incurs
    an additional overhead cost C added to the schedule time.

    Goal: build a schedule that *heuristically* minimizes the maximum
    lateness   L_max = max_j ( completionTime_j - deadline_j ).

    We use an Earliest-Deadline-First (EDD) strategy:
        - sort all jobs by non-decreasing deadline
        - process in that order, inserting switch overhead C whenever
          the type differs from the previous job.

    Input
    -----
        N M C
        (N = number of types, M = number of jobs, C = switch overhead)

        Then M lines:
            type_i  deadline_i  proc_i

        where type_i in [0, N-1].

    Output
    ------
        First line : maximum lateness (can be negative if all meet deadlines)
        Second line: job execution order as zero-based job indices (0..M-1)

    Note
    ----
        Job indices refer to their position in the input (0-based).
*/

struct Job {
    int id;         // original index
    int type;       // queue / type id
    long long d;    // deadline
    long long p;    // processing time
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    long long C;
    if (!(cin >> N >> M >> C)) return 0;

    vector<Job> jobs(M);
    for (int i = 0; i < M; ++i) {
        jobs[i].id = i;
        cin >> jobs[i].type >> jobs[i].d >> jobs[i].p;
    }

    // Earliest-deadline-first order
    sort(jobs.begin(), jobs.end(),
         [](const Job& a, const Job& b) {
             if (a.d != b.d) return a.d < b.d;
             return a.id < b.id;          // tie-break by input order
         });

    long long t = 0;            // current time
    long long Lmax = LLONG_MIN;
    int lastType = -1;

    vector<int> order;
    order.reserve(M);

    for (const Job& job : jobs) {
        if (lastType != -1 && lastType != job.type) {
            t += C;             // switching overhead
        }
        t += job.p;
        long long lateness = t - job.d;
        if (lateness > Lmax) Lmax = lateness;
        lastType = job.type;
        order.push_back(job.id);
    }

    if (M == 0) Lmax = 0;       // no jobs -> no lateness

    cout << Lmax << "\n";
    for (int i = 0; i < (int)order.size(); ++i) {
        if (i) cout << ' ';
        cout << order[i];
    }
    cout << "\n";

    return 0;
}
