#include <bits/stdc++.h>
using namespace std;

/*
    q56.cpp

    Merge two BSTs into a single **balanced** BST in O(N1 + N2) time
    using only O(h1 + h2) extra space (recursion stack).

    Strategy
    --------
    1. Each input tree is a BST.
    2. Convert each BST into a sorted doubly linked list (DLL) in-place
       using inorder traversal:
           - left  -> prev
           - right -> next
       This uses O(h) recursion stack per tree.
    3. Merge the two sorted DLLs in O(N1 + N2) time.
    4. Convert the merged sorted DLL back into a balanced BST in O(N)
       using the standard "sorted list to BST" recursive method.
    5. Output:
           - number of nodes in merged tree
           - height of balanced BST
           - inorder traversal of the merged balanced BST

    Input format for each BST (1-based indices):
        n
        val1 left1 right1
        ...
        valn leftn rightn

        vali  : integer key
        lefti : index of left child  (0 if NULL)
        righti: index of right child (0 if NULL)

    Overall input:
        n1
        ... n1 lines ...
        n2
        ... n2 lines ...

    Root of each tree is the unique node that never appears as a child.
*/

struct Node {
    long long key;
    Node *left;   // also used as prev in DLL
    Node *right;  // also used as next in DLL
    Node(long long k = 0) : key(k), left(NULL), right(NULL) {}
};

// ---------- Utilities to build pointer trees from array form ----------

Node* buildTree(int n, vector<long long>& val,
                vector<int>& L, vector<int>& R) {
    if (n == 0) return NULL;
    vector<Node*> nodes(n + 1, NULL);
    for (int i = 1; i <= n; ++i) nodes[i] = new Node(val[i]);

    vector<int> isChild(n + 1, 0);
    for (int i = 1; i <= n; ++i) {
        if (L[i] != 0) {
            nodes[i]->left = nodes[L[i]];
            isChild[L[i]] = 1;
        }
        if (R[i] != 0) {
            nodes[i]->right = nodes[R[i]];
            isChild[R[i]] = 1;
        }
    }
    int rootIdx = 1;
    for (int i = 1; i <= n; ++i)
        if (!isChild[i]) { rootIdx = i; break; }

    return nodes[rootIdx];
}

// ---------- Convert BST to sorted doubly linked list ----------

void bstToDLL(Node* root, Node*& head, Node*& prev, int& count) {
    if (!root) return;
    bstToDLL(root->left, head, prev, count);

    // link current node
    if (!head) head = root;
    root->left = prev;
    if (prev) prev->right = root;
    prev = root;
    count++;

    bstToDLL(root->right, head, prev, count);
}

Node* bstToDLLWrapper(Node* root, int& count) {
    Node* head = NULL;
    Node* prev = NULL;
    count = 0;
    bstToDLL(root, head, prev, count);
    if (prev) prev->right = NULL; // tail->next = NULL
    return head;
}

// ---------- Merge two sorted DLLs ----------

Node* mergeDLL(Node* a, Node* b) {
    if (!a) return b;
    if (!b) return a;

    Node* head = NULL;
    Node* tail = NULL;

    while (a && b) {
        Node* pick;
        if (a->key <= b->key) {
            pick = a;
            a = a->right;
        } else {
            pick = b;
            b = b->right;
        }
        pick->left = tail;
        pick->right = NULL;
        if (!head) head = pick;
        else tail->right = pick;
        tail = pick;
    }

    Node* rest = (a ? a : b);
    while (rest) {
        Node* nxt = rest->right;
        rest->left = tail;
        rest->right = NULL;
        if (!head) head = rest;
        else tail->right = rest;
        tail = rest;
        rest = nxt;
    }

    return head;
}

// ---------- Convert sorted DLL to balanced BST ----------

Node* sortedDLLToBST(Node*& head, int n) {
    if (n <= 0 || !head) return NULL;

    // build left subtree
    Node* leftSub = sortedDLLToBST(head, n / 2);

    // head now points to root
    Node* root = head;
    root->left = leftSub;

    // advance head
    head = head->right;

    // build right subtree with remaining nodes
    root->right = sortedDLLToBST(head, n - n / 2 - 1);

    return root;
}

// ---------- Helpers ----------

int height(Node* root) {
    if (!root) return 0;
    int hl = height(root->left);
    int hr = height(root->right);
    return 1 + (hl > hr ? hl : hr);
}

void inorder(Node* root, vector<long long>& out) {
    if (!root) return;
    inorder(root->left, out);
    out.push_back(root->key);
    inorder(root->right, out);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n1;
    if (!(cin >> n1)) return 0;

    vector<long long> v1(n1 + 1);
    vector<int> L1(n1 + 1), R1(n1 + 1);
    for (int i = 1; i <= n1; ++i) {
        cin >> v1[i] >> L1[i] >> R1[i];
    }

    int n2;
    cin >> n2;
    vector<long long> v2(n2 + 1);
    vector<int> L2(n2 + 1), R2(n2 + 1);
    for (int i = 1; i <= n2; ++i) {
        cin >> v2[i] >> L2[i] >> R2[i];
    }

    Node* root1 = buildTree(n1, v1, L1, R1);
    Node* root2 = buildTree(n2, v2, L2, R2);

    int c1 = 0, c2 = 0;
    Node* head1 = bstToDLLWrapper(root1, c1);
    Node* head2 = bstToDLLWrapper(root2, c2);

    Node* mergedDLL = mergeDLL(head1, head2);
    int total = c1 + c2;

    Node* headRef = mergedDLL;
    Node* mergedRoot = sortedDLLToBST(headRef, total);

    int h = height(mergedRoot);
    vector<long long> in;
    inorder(mergedRoot, in);

    cout << total << "\n";    // number of nodes in merged BST
    cout << h << "\n";        // height of balanced BST
    for (size_t i = 0; i < in.size(); ++i) {
        if (i) cout << ' ';
        cout << in[i];
    }
    cout << "\n";

    return 0;
}
