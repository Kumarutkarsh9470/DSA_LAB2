#include <bits/stdc++.h>
using namespace std;

/*
    q52: Order Statistic Tree with concurrent-friendly O(log N) updates.

    Supports:
        - insert(x)
        - erase(x)
        - findKthSmallest(k)

    Data structure: TREAP with subtree sizes.

    Commands (input):
        Q queries
        Each query:
            1 x -> insert x
            2 x -> erase x
            3 k -> print k-th smallest element

    Output:
        For each type-3 query, print result (or -1 if k invalid).
*/

struct Node {
    long long val;
    int pr;        // priority
    int sz;        // subtree size
    Node *l, *r;

    Node(long long v) {
        val = v;
        pr = rand();
        sz = 1;
        l = r = nullptr;
    }
};

int getsz(Node *t) {
    return t ? t->sz : 0;
}

void pull(Node *t) {
    if (!t) return;
    t->sz = 1 + getsz(t->l) + getsz(t->r);
}

// Split by key (values < key go to a, others to b)
void split(Node *t, long long key, Node* &a, Node* &b) {
    if (!t) {
        a = b = nullptr;
        return;
    }
    if (t->val < key) {
        split(t->r, key, t->r, b);
        a = t;
    } else {
        split(t->l, key, a, t->l);
        b = t;
    }
    pull(t);
}

// Merge two treaps (all keys in a < keys in b)
Node* merge(Node *a, Node *b) {
    if (!a) return b;
    if (!b) return a;
    if (a->pr > b->pr) {
        a->r = merge(a->r, b);
        pull(a);
        return a;
    } else {
        b->l = merge(a, b->l);
        pull(b);
        return b;
    }
}

Node *root = nullptr;

// Insert x
void insert_val(long long x) {
    Node *t1, *t2;
    split(root, x, t1, t2);
    root = merge(merge(t1, new Node(x)), t2);
}

// Erase x (erases one occurrence)
void erase_val(long long x) {
    Node *t1, *t2, *t3;
    split(root, x, t1, t2);
    split(t2, x + 1, t2, t3);
    // t2 contains all nodes with value == x
    if (t2) {
        // Delete one node
        Node *tmp = merge(t2->l, t2->r);
        delete t2;
        t2 = tmp;
    }
    root = merge(t1, merge(t2, t3));
}

// Find k-th smallest (1-indexed)
long long kth(Node *t, int k) {
    if (!t || k <= 0 || k > getsz(t)) return -1; // invalid
    int ls = getsz(t->l);
    if (k == ls + 1) return t->val;
    if (k <= ls) return kth(t->l, k);
    return kth(t->r, k - ls - 1);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    srand(time(NULL));

    int Q;
    cin >> Q;

    while (Q--) {
        int type;
        long long x;
        cin >> type >> x;

        if (type == 1) {
            insert_val(x);
        } else if (type == 2) {
            erase_val(x);
        } else if (type == 3) {
            cout << kth(root, (int)x) << "\n";
        }
    }

    return 0;
}
