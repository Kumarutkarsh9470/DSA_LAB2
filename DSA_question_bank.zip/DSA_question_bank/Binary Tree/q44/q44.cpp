#include <bits/stdc++.h>
using namespace std;

/*
    Problem:
      Perform boundary traversal (left boundary, leaves, right boundary)
      of a binary tree.

      Eliminate duplicates intelligently:
        - If a node belongs to multiple "boundaries",
          include it only in the *first* boundary it
          belongs to in the standard order:
            1) Root / Left boundary
            2) Leaves
            3) Right boundary

      Assumed input format:
        n
        value0 left0 right0
        value1 left1 right1
        ...
        value(n-1) left(n-1) right(n-1)

        * nodes are indexed 0..n-1
        * -1 for left/right means "no child"
        * node 0 is the root

      Output:
        The boundary traversal values on a single line separated by spaces.
*/

struct Node {
    int val;
    int left;
    int right;
};

vector<Node> tree;
vector<int> result;
vector<bool> used; // used[i] = true if node i already added to result

bool isLeaf(int idx) {
    if (idx == -1) return false;
    return tree[idx].left == -1 && tree[idx].right == -1;
}

void addIfUnused(int idx) {
    if (idx == -1) return;
    if (!used[idx]) {
        result.push_back(tree[idx].val);
        used[idx] = true;
    }
}

// Left boundary excluding leaves and root
void addLeftBoundary(int root) {
    int cur = tree[root].left;
    while (cur != -1) {
        if (!isLeaf(cur)) {
            addIfUnused(cur);
        }
        if (tree[cur].left != -1)
            cur = tree[cur].left;
        else
            cur = tree[cur].right;
    }
}

// Leaves (in-order over whole tree)
void addLeaves(int idx) {
    if (idx == -1) return;
    if (isLeaf(idx)) {
        addIfUnused(idx);
        return;
    }
    addLeaves(tree[idx].left);
    addLeaves(tree[idx].right);
}

// Right boundary excluding leaves and root, but added bottom-up
void addRightBoundary(int root) {
    int cur = tree[root].right;
    vector<int> tmp;
    while (cur != -1) {
        if (!isLeaf(cur)) {
            if (!used[cur]) tmp.push_back(cur);
        }
        if (tree[cur].right != -1)
            cur = tree[cur].right;
        else
            cur = tree[cur].left;
    }
    // add in reverse (bottom-up)
    for (int i = (int)tmp.size() - 1; i >= 0; --i) {
        addIfUnused(tmp[i]);
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0) {
        return 0;
    }

    tree.resize(n);
    for (int i = 0; i < n; ++i) {
        int v, l, r;
        cin >> v >> l >> r;
        tree[i] = {v, l, r};
    }

    used.assign(n, false);
    result.clear();

    int root = 0;

    // 1. Root (if it exists)
    addIfUnused(root);

    // 2. Left boundary
    addLeftBoundary(root);

    // 3. Leaves
    addLeaves(root);

    // 4. Right boundary
    addRightBoundary(root);

    // Output
    for (size_t i = 0; i < result.size(); ++i) {
        if (i) cout << ' ';
        cout << result[i];
    }
    cout << '\n';

    return 0;
}
