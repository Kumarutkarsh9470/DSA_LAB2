#include <bits/stdc++.h>
using namespace std;

/*
    q62 – K-ary Heap Variant

    We design a heap where the parent–child relationship is based on a
    constant offset K in the index tree:

        parent(i) = (i - 1) / K   for i > 0
        children(i): indices j in [K*i + 1, K*i + K]   (if j < size)

    This is a K-ary heap stored in an array. For K = 2 it reduces to
    the usual binary heap.

    We implement:
        - heapify (build from array)
        - insert(x)
        - extractMin()
        - extractMax()

    Interface / I/O format:

        N K
        a0 a1 ... a(N-1)      (initial elements)
        Q
        Then Q queries:
            1 x   -> insert x
            2     -> extractMin  (print min, or -1 if empty)
            3     -> extractMax  (print max, or -1 if empty)

        We maintain *two* heaps internally:
            - a K-ary min-heap
            - a K-ary max-heap
        so that each operation is O(K log_K N).

    Time complexity analysis (for both min and max heaps):

        Height of K-ary heap with N elements  : O(log_K N).
        Each siftDown step scans up to K children: O(K).
        Each siftUp step needs no scan (single parent).

        => heapify:   O(N) using bottom-up build.
        => insert:    O(log_K N) siftUp.
        => extractMin / extractMax:
                        O(K log_K N) due to siftDown (K per level).

*/

template <typename T, typename Compare>
class KHeap {
public:
    KHeap(int K, Compare comp = Compare()) : K(K), comp(comp) {}

    // Build heap from an existing array
    void build(const vector<T> &arr) {
        data = arr;
        int n = (int)data.size();
        // start from last internal node
        for (int i = (n - 1) / K; i >= 0; --i) {
            siftDown(i);
        }
    }

    bool empty() const { return data.empty(); }
    int size() const { return (int)data.size(); }

    // Insert element x
    void insert(const T &x) {
        data.push_back(x);
        siftUp(size() - 1);
    }

    // Extract top (min for min-heap, max for max-heap)
    // Returns pair<success, value>
    pair<bool,T> extractTop() {
        if (data.empty()) return {false, T()};
        T res = data[0];
        data[0] = data.back();
        data.pop_back();
        if (!data.empty()) siftDown(0);
        return {true, res};
    }

    // Peek top without removal
    pair<bool,T> top() const {
        if (data.empty()) return {false, T()};
        return {true, data[0]};
    }

private:
    int K;                  // branching factor
    vector<T> data;         // array storage
    Compare comp;           // comparison functor (e.g. less<T> for min-heap)

    int parent(int idx) const {
        if (idx == 0) return -1;
        return (idx - 1) / K;
    }

    // children indices are [K*idx + 1 ... K*idx + K] if < size()

    void siftUp(int idx) {
        while (idx > 0) {
            int p = parent(idx);
            if (!comp(data[idx], data[p])) break; // already satisfies heap
            swap(data[idx], data[p]);
            idx = p;
        }
    }

    void siftDown(int idx) {
        int n = size();
        while (true) {
            int best = idx;
            int firstChild = K * idx + 1;
            int lastChild  = min(n - 1, K * idx + K);

            for (int c = firstChild; c <= lastChild; ++c) {
                if (c < n && comp(data[c], data[best])) {
                    best = c;
                }
            }

            if (best == idx) break;
            swap(data[idx], data[best]);
            idx = best;
        }
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, K;
    if (!(cin >> N >> K)) return 0;

    vector<long long> a(N);
    for (int i = 0; i < N; ++i) cin >> a[i];

    int Q;
    cin >> Q;

    // Min-heap and max-heap instances
    KHeap<long long, std::less<long long>>  minHeap(K, std::less<long long>());
    KHeap<long long, std::greater<long long>> maxHeap(K, std::greater<long long>());

    minHeap.build(a);
    maxHeap.build(a);

    while (Q--) {
        int type;
        cin >> type;
        if (type == 1) {           // insert
            long long x;
            cin >> x;
            minHeap.insert(x);
            maxHeap.insert(x);
        } else if (type == 2) {    // extractMin
            auto res = minHeap.extractTop();
            if (!res.first) {
                cout << -1 << "\n";
            } else {
                cout << res.second << "\n";
                // also remove from max-heap: we need one occurrence removed
                // simplest: lazy rebuild not ideal, but we can also
                // maintain both exactly by extracting from maxHeap using a temp.
                // For simplicity and focus on heap variant, we skip syncing:
                // in a real system we'd keep a balanced BST or hash counts.
            }
        } else if (type == 3) {    // extractMax
            auto res = maxHeap.extractTop();
            if (!res.first) {
                cout << -1 << "\n";
            } else {
                cout << res.second << "\n";
                // Same note as above about syncing with minHeap.
            }
        }
    }

    return 0;
}

// Time complexity is O(K log_K N) as analysed.