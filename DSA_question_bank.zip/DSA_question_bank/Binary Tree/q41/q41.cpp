#include <bits/stdc++.h>
using namespace std;

/*
   Problem:
   Serialize a binary tree in vertical order (by horizontal distance from root).
   When nodes overlap at the same horizontal and vertical coordinates, order them by:
     1) left child before right child
     2) then by node creation time

   Assumed input format:
     n
     value0 leftIndex0 rightIndex0
     value1 leftIndex1 rightIndex1
     ...
     value(n-1) leftIndex(n-1) rightIndex(n-1)

   Indices are 0-based. -1 means "no child".
   Node 0 is considered the root and node creation time is its index (0..n-1).

   Output:
     The serialized sequence of node values in the required order,
     printed on a single line separated by spaces.
*/

struct Node {
    int val;
    int left;
    int right;
};

struct Entry {
    int x;          // horizontal distance from root
    int y;          // depth (root = 0)
    int isLeft;     // 0 for left child, 1 for right child, 0 for root
    int creation;   // node creation time (index)
    int val;        // node value
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) {
        return 0;   // no input
    }

    if (n <= 0) {
        return 0;
    }

    vector<Node> nodes(n);
    for (int i = 0; i < n; ++i) {
        int v, l, r;
        cin >> v >> l >> r;
        nodes[i] = {v, l, r};
    }

    // BFS to assign coordinates (x, y) and left/right info
    vector<Entry> entries;
    entries.reserve(n);

    queue<pair<int, pair<int,int>>> q; // node index, {x, y}
    vector<int> isLeft(n, 0);          // 0: left (or root), 1: right

    // root: index 0
    q.push({0, {0, 0}});
    isLeft[0] = 0;

    vector<bool> visited(n, false);

    while (!q.empty()) {
        auto cur = q.front(); q.pop();
        int idx = cur.first;
        int x = cur.second.first;
        int y = cur.second.second;

        if (idx < 0 || idx >= n) continue;
        if (visited[idx]) continue;
        visited[idx] = true;

        // record this node
        Entry e;
        e.x = x;
        e.y = y;
        e.isLeft = isLeft[idx];
        e.creation = idx;        // index used as creation time
        e.val = nodes[idx].val;
        entries.push_back(e);

        // push children
        if (nodes[idx].left != -1) {
            int ch = nodes[idx].left;
            if (!visited[ch]) {
                isLeft[ch] = 0; // left child
                q.push({ch, {x - 1, y + 1}});
            }
        }
        if (nodes[idx].right != -1) {
            int ch = nodes[idx].right;
            if (!visited[ch]) {
                isLeft[ch] = 1; // right child
                q.push({ch, {x + 1, y + 1}});
            }
        }
    }

    // Sort according to rules:
    // 1. horizontal distance x (ascending)
    // 2. depth y (ascending)
    // 3. left child before right child
    // 4. node creation time (ascending)
    sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
        if (a.x != b.x) return a.x < b.x;
        if (a.y != b.y) return a.y < b.y;
        if (a.isLeft != b.isLeft) return a.isLeft < b.isLeft;
        return a.creation < b.creation;
    });

    // Output serialized sequence
    for (size_t i = 0; i < entries.size(); ++i) {
        if (i) cout << ' ';
        cout << entries[i].val;
    }
    cout << '\n';

    return 0;
}
