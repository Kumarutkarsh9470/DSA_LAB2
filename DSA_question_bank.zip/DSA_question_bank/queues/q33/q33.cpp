#include <bits/stdc++.h>
using namespace std;

/*
   Sliding window with per-element TTL and O(log K) operations.

   Data structures
   ---------------
   We maintain:

   - currentTime : current window time.

   - nodes[id] : information about each inserted element:
        value, expireTime, active flag.

   - min-heap (by expireTime) storing element IDs:
        used to expire elements quickly when time advances.

   - max-heap (by value) storing element IDs:
        used to answer GETMAX queries.

   Lazy deletion:
     An element can be marked inactive; heaps may still contain it.
     Before using the top of a heap we pop inactive/expired entries.
*/

struct Item {
    long long value;
    long long expireTime;
    bool active;
    Item(long long v = 0, long long e = 0, bool a = false)
        : value(v), expireTime(e), active(a) {}
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int Q;
    if (!(cin >> Q)) return 0;

    long long currentTime = 0;

    vector<Item> nodes;    // id -> item

    // Min-heap: earliest expiration first
    struct ExpCmp {
        const vector<Item>* items;
        bool operator()(int a, int b) const {
            return (*items)[a].expireTime > (*items)[b].expireTime;
        }
    };
    ExpCmp expCmp;
    expCmp.items = &nodes;
    priority_queue<int, vector<int>, ExpCmp> minHeap(expCmp);

    // Max-heap: largest value first
    struct ValCmp {
        const vector<Item>* items;
        bool operator()(int a, int b) const {
            const Item &ia = (*items)[a], &ib = (*items)[b];
            if (ia.value == ib.value) return a > b; // tie-break by id
            return ia.value < ib.value;
        }
    };
    ValCmp valCmp;
    valCmp.items = &nodes;
    priority_queue<int, vector<int>, ValCmp> maxHeap(valCmp);

    auto expireOld = [&]() {
        // Expire all elements whose expireTime <= currentTime
        while (!minHeap.empty()) {
            int id = minHeap.top();
            const Item &it = nodes[id];
            if (!it.active || it.expireTime > currentTime) break;
            // this item is active but expired now
            nodes[id].active = false;
            minHeap.pop();
        }
    };

    cout.setf(ios::fixed);
    cout << setprecision(0);

    while (Q--) {
        string cmd;
        cin >> cmd;

        if (cmd == "ADD") {
            long long v, ttl;
            cin >> v >> ttl;
            if (ttl < 0) ttl = 0;

            long long expireTime = currentTime + ttl;
            int id = (int)nodes.size();
            nodes.emplace_back(v, expireTime, true);

            minHeap.push(id);
            maxHeap.push(id);

            cout << "OK\n";
        } else if (cmd == "SLIDE") {
            long long dt;
            cin >> dt;
            if (dt < 0) dt = 0;
            currentTime += dt;
            expireOld();
            cout << "OK\n";
        } else if (cmd == "GETMAX") {
            // Ensure expirations are up to date
            expireOld();

            // Remove inactive or expired elements from max-heap
            while (!maxHeap.empty()) {
                int id = maxHeap.top();
                const Item &it = nodes[id];
                if (!it.active || it.expireTime <= currentTime) {
                    maxHeap.pop();
                } else break;
            }

            if (maxHeap.empty()) {
                cout << "EMPTY\n";
            } else {
                int id = maxHeap.top();
                cout << nodes[id].value << "\n";
            }
        } else {
            // Unknown command, consume rest of line and report error
            string rest;
            getline(cin, rest);
            cout << "ERR\n";
        }
    }

    return 0;
}
