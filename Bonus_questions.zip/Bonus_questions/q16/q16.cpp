#include <bits/stdc++.h>
using namespace std;

struct Node {
    int val;
    Node *next;
    Node(int v) : val(v), next(nullptr) {}
};

// Build list from vector
Node* buildList(const vector<int> &a) {
    if (a.empty()) return nullptr;
    Node *head = new Node(a[0]);
    Node *cur = head;
    for (size_t i = 1; i < a.size(); ++i) {
        cur->next = new Node(a[i]);
        cur = cur->next;
    }
    return head;
}

// Print list
void printList(Node *head) {
    bool first = true;
    while (head) {
        if (!first) cout << ' ';
        first = false;
        cout << head->val;
        head = head->next;
    }
    cout << '\n';
}

// Reverse sublist [L, R] (1-based, inclusive) in-place.
// O(1) extra space, single pass over the list for this operation.
void reverseSegment(Node *&head, int L, int R) {
    if (!head || L == R) return;
    if (L > R) swap(L, R);

    Node dummy(0);
    dummy.next = head;
    Node *prev = &dummy;

    // move prev to (L-1)-th node
    for (int i = 1; i < L; ++i) {
        if (!prev->next) {  // L beyond list length
            head = dummy.next;
            return;
        }
        prev = prev->next;
    }

    Node *segmentHeadPrev = prev;
    Node *curr = prev->next;           // L-th node
    Node *subTail = curr;

    // standard in-place reversal of length (R-L+1)
    Node *next = nullptr;
    Node *prevNode = nullptr;
    for (int i = L; i <= R && curr; ++i) {
        next = curr->next;
        curr->next = prevNode;
        prevNode = curr;
        curr = next;
    }

    // Connect back
    segmentHeadPrev->next = prevNode;  // new head of reversed part
    subTail->next = curr;              // tail points to node after R

    head = dummy.next;
}

// Free list memory
void freeList(Node *head) {
    while (head) {
        Node *tmp = head->next;
        delete head;
        head = tmp;
    }
}

/*
   Assumed input format:

   N
   a1 a2 ... aN
   M
   L1 R1
   L2 R2
   ...
   LM RM

   All indices are 1-based.
   For each pair (Li, Ri) we reverse that segment on the *current* list.
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    if (!(cin >> N)) return 0;
    vector<int> a(N);
    for (int i = 0; i < N; ++i) cin >> a[i];

    Node *head = buildList(a);

    int M;
    cin >> M;
    for (int i = 0; i < M; ++i) {
        int L, R;
        cin >> L >> R;
        reverseSegment(head, L, R);
    }

    printList(head);
    freeList(head);
    return 0;
}
